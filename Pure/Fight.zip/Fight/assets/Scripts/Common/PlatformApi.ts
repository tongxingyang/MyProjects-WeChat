export default class PlatformApi {

    static showVideo(cb?: Function) {
        cb && cb()
    }

    static doVibrate(isLong: boolean = false) {
        
    }
}

