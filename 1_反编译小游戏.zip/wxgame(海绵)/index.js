window.screenOrientation = "sensor_landscape", loadLib("libs/min/laya.core.min.js"), 
loadLib("libs/min/laya.ani.min.js"), loadLib("libs/min/laya.ui.min.js"), loadLib("libs/min/laya.d3.min.js"), 
loadLib("libs/min/laya.physics3D.min.js"), loadLib("js/bundle.js");