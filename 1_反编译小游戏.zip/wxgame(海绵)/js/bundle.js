/*
 * 加密工具已经升级了一个版本，目前为 jsjiami.com.v5 ，主要加强了算法，以及防破解【绝对不可逆】配置，耶稣也无法100%还原，我说的。;
 * 已经打算把这个工具基础功能一直免费下去。还希望支持我。
 * 另外 jsjiami.com.v5 已经强制加入校验，注释可以去掉，但是 jsjiami.com.v5 不能去掉（如果你开通了VIP，可以手动去掉），其他都没有任何绑定。
 * 誓死不会加入任何后门，jsjiami.com JS 加密的使命就是为了保护你们的Javascript 。
 * 警告：如果您恶意去掉 jsjiami.com.v5 那么我们将不会保护您的JavaScript代码。请遵守规则
 * 新版本: https://www.jsjiami.com/ 支持批量加密，支持大文件加密，拥有更多加密。 */
var encode_version = "jsjiami.com.v5", tsoqk = "__0xc19de", __0xc19de = [ "wrvDqlrCl8Kbw4lMYGdjBw==", "wp/DjcOcXiPDmxU9w7Fe", "D1pGwpU=", "RsKlw4VCOx5yw5YcFVoIOsKqbMO0J8OCwoBS", "w7zDgcO3UhHCsg==", "TQlUEMKdwrU8", "wrzDvjjDuQkVEnlH", "w7zCqmpGQw==", "wrc1wrvDs8OXYMOcNFPCgTdyRMOV", "VxXChFHCtQ==", "RgNBMMKxwq45RwrCkg==", "w47DvmnCtTE=", "woZVwrYT", "MAoxfnsuIQrDs8O1wqvCiUXDp8Kwwp7DkcOifsOj", "JcOrfsO6GWc=", "wrzCphXChzk=", "ZzTCiWnCvMO0QUAPw65q", "S8OKw7PCs8K0w6LCoAzDmg==", "Iwo2Qzoa", "w6JWFSIoNMKbI0U=", "wq7ChhcYwpDCq8Knw5Usw4I=", "w5nCrRkowpU=", "w7bDncO7RyfCtsKew40Kw4g=", "woI6csOJwpI=", "wpXCn8OYFMK5bnXDhsOowog=", "YMOrIwVXDsKnPndnw7hn", "WT/Co3XCjsOobF0N", "csKewrbCtBI1SMOGIg==", "Ny0XO8Ok", "wprCmMOcE8KCSnPDhcO/woLDq0XCrw==", "w67CmlJsXMKOwq9x", "wo3Dv33CkMKV", "wpzDvXbCmMKIw5hzfA==", "Y8O8OClADsKkAQ==", "w55nW8KLw5k=", "w6BMFCQM", "wpBlw4xWw4BUw57DjA==", "w7nDkcKJSMOlWkPCvsK2", "dMKHwpQ/", "wq/Do3jCjMKJw6h0Zmx5", "w4nCji0/wpPCv8OAwoo=", "LMOPWsOvNQ==", "wq8UInHDig==", "w5nDmsKQwrvDpw==", "wqPCtSI/wq0=", "w4UWw6LCiVw=", "ZcOnMjkdLMK2H3tVw5k9CTA=", "JSvCpTdgEjBlw5YZw5HClQFPXghj", "w6DDlsKoVsK5c0jCpsKRwqJyw7/CuwLDinvCqA==", "wqZ2HT1f", "wqFTDCYbRGBlQMOQJzRTwrovNMOYwpDDng==", "fihSJsKd", "w5MAw7PCnEw=", "w4Msw7/ClF8=", "Jh/CszbDhA==", "w4xDw5YQdA==", "UDzDncKICzBjw7PDvBbCtsKfHMO6LHhSw60=", "XQVEIMKU", "w7FMCDUALMKVLl9R", "XMKvw5hT", "wqAmbw==", "eMKnwpnCiT4=", "GVnDu8Kfw6NCQlI1w7o=", "w6DDrFjDrsKEw7zCsGt1woRYw5vCtFUWwpRfTsKRwps=", "QzLCr2/CuMOSYkAc", "GgEPw7E8", "DRAMw7A=", "wqUkLWnDl8OLw4JGwobDksOaFQ==", "Ljxmwr8XwqbDthEoLMORBTLDvcOUMcOW", "Zg1ZNcOPwoU=", "w51nUsKaw4M=", "N09BwrzDsA==", "FsOxYsOoBGHDsw==", "LgwUw7cyw6Nn", "w7PDkcKsQ8O6Xg==", "w5LDmsKvVMOxa0DCvMK2wqE=", "Lip3wrIJwrc=", "NcO6esO3CE/Dr8KhGg==", "w6UXw5HCqnE=", "GUbCqSjDkMKFw7rChCTDnA==", "wrXClwbCjRrDgcO9a8KOw5k=", "wobDj8KMChw=", "IigTOcO4Ew==", "wqjCjwoswpvCiQ==", "RsOJw7vCsMKNw5I=", "w5B0wrRBwqXCsw==", "w4jDj0A=", "Gxwdw6spw7RHCcO3wo7CqzPDt8KFw6rDosO9", "V8K4w4ZZZi1Aw5gcKFw5O8KFMcOoKg==", "w4ILNA0P", "RsO6PiJB", "bjlBE8KY", "wrJUCDNYRkVtR8OgOBRdwqY+aw==", "wojDgMORbyXDgC8Xw7JTKsKX", "wrlNwqoOw7rCpMOuw6MSw4jCjSB9eEvDuA==", "woUkLWnDl8OLw4JGwobDksOaFcKwck7CjQ==", "w60EJS0reA==", "w53DnMKgwoHDuwjCv1MPw49BwqBsbyTDuA==", "w6nCjjkTworCrMOQwpzDplMbw7XCqcOyJg==", "eMKHwpwpw5/Chg==", "w4rDlcK3woDDpiDCvRIHw51Cwos=", "OivCkBvDv8OVw4DChcOiwqjDsU5bwo7CtA==", "cTrDnMKODjYvw6HDhQHCoMK4HMOlMQ==", "wpnCmcOrEsKgS3XDjcOjwqvDt1fDucOZRA==", "w5XDvUfDu8OYw7nCsWx+wppaw5DCu1ddwpU=", "YsK0EEbCn8O3", "QcOMw77CssKAw7XCnR/DkcKmHTg2wq4T", "BUPDmcKCw7l3SFAXw7BCI2vChw==", "BUvCmCLDm8KNw57CjAzDlsKIQMK4FQ==", "azw6w5kh", "wqc9fsO1wod7IcO8wrjCiA==", "dMKEwrPCowAbR8OOIw==", "woVlw5c=", "w5IzNwIF", "XxjColbClw==", "WRjCmmPClA==", "EBXCjTHDlw==", "54i25p2I5Y6a776IMcOz5LyO5a+w5p6N5b+Z56mZ772r6L2A6Ky45pa25o6M5oqC5Lmx55ik5ben5L69", "WAvDq2PChQ==", "57ip6K2WwpBJ6LSh6L2UVcOm5Lq356qd", "RX7DrsKMw6M+aFk/w7pbaG3Cj8O+Sg0=", "MGVwwq8=", "w5Bowq1KwqLCmGzCh8OowozDvVx5wqPDpXU=", "57uC6K2I6KyK5rCJ5Y2i6YOiw58lfCkC5peS5o+x", "w7nDksO7Xw==", "w61LYg==", "w4fDrUDCtcO+w4PCung+wrNaw4vCgEM=", "woZtWcKKw44R", "6Ky+5rKh5aWS6LWu", "w7o5J3/DjMKHw51twoTDmcOB", "6Kyj57+z5ri05ouU5pSk5o645aWQ6LSY", "w7sBcMOqwpYHAcO2wrjCiznCsMObeDh+wpvCkMKQKsO/OmRbw6Iq", "55i95b+M5aSq6La+", "w7rDvGHCvjbCuRkSwpJwdMOYGlHCnEFC", "6KeB6aGL5biO5ZGu5YSJ6ZaL", "5by75Yuc5YuR5Lmt", "6YSZ57yn55yU6KWB6aGi5qyJ5pSy", "wpfDhsOgdSjDhg==", "wpN/w4JDw5diw5jDnMKewoEww7w=", "JSvCpC8q", "wrXDpVTCvjsDesKcRMONU8KP", "w6YKWmk=", "5YuW5Li65aWu6La1772r6K606Ya26K+J", "wqjCmwPCuxfDjsOCYcK+w5XDo8OuRg==", "55iy5o2R5aWF6LeN", "57OY57qA5o2/56eb772h", "5Yuz5LiQ5aeK5LujSuaKp+WIlA==", "w7ECw5nCoWITCsO4w6XDhsKswqDCucOucixC", "5YiB5Lmx5YmB576A", "woZVwrYTw57CrsOzw44ww4vClSLlpIjotK/lm7Tosow=", "wpzDmMKCA+eDgOWFjOaKm+WIvQ==", "w63DlsO+VgTCpMKV", "w4nDmcOrwofDqjzCpxIqw49AwoBNfi7DpBvDm00=", "wogqwqjDvsOwcA==", "FyrCvg==", "w6lCw6c+QGh5wr3DhcORw6vDjwE=", "DEVCwp/CkwfCqxATwrbCrGrCnMKObDrDiMO7wqPDog==", "wqpdw6bCng9GwoxqQsOCw4fDoR9Gw7hneA==", "Py3CoSRgOD4/w74Gw44=", "WMK+FFfCh8O9w6A=", "ZRhIMcKOw7UQDSrCgAfDhlBqwqXDmxHCh8Kwwogzwqdew64zDsOXw4dSw7zDt8O9YcKkwrg/", "wrTChcOSFMKxV3DDiw==", "w5rCp8K3wo7CjsKT", "w6dNEw==", "wpbCmBXChhrCn8KANQ==", "Y8Obw79JW0dURQ==", "QgVUC8KfwqA0RgfCiCHDgGRx", "w5ZWAzUQKMOTGE5KP30zw69JOMODw6vCtFZZwpDDujLDmmBBwow0VgIP", "w4sTKCYpeQ4Fw6EWZg==", "wozDksOL", "NA4r", "QsKfwrTCswsQTMOZGAPDmg==", "BC3CsiQbMyli", "w77DncO1XwA=", "6ZaM5aal6LaA6Lq65aWW6LWm5LmW", "wqBbBTo=", "csKbwqLCpxI=", "V8ONw7HCiMKTw7XCmhfDjA==", "dSosw54nwpfDmRR6DhbCvcKy", "w4ALKS0ybwwCwrRUCE/DgDMP", "wqscw6I8wqPDtw==", "wrzDvj7DtDA7KGlSw4vDrcOww6Nn", "CxsqbyZdDVXCucOqwqnClUrDkcO9wojDnMOiT8OEwqJhAMKZMCNBwpbDqMKFXjY8XcKwNsOowpozw79bw49zw6DChsOgPBU=", "w7TCnyIZwo3DqsO+w4vCn3oIw7/CocOOK2nDhxd7MsOtb8KwwpJIZsOsLRoOw6Enw6HCmcOvIcKhw7E0B0wcKW7CnTTCrMKy", "w5PCniUYwprCgcOWwp/Dk2kKw6o=", "dzDCp2TCksOiZ0oLw7M=", "wr5ODDw=", "5LuX6aO65oK15raRwpPDnm9h", "Ewsfw6Ecw6F5Dw==", "UjTCrG7Cr8OlUl8Jw7R3w7Uhw6tBw5zCq2hjw65mMcK4wrjCpAXCnsO1acOXw4DCtMKI", "wrItOX/DrsOaw55nwpDDgw==", "wrjDpFPCojsZAsO4", "57uA5p+R5rmv5omB55q255q55a6H", "w7LDkcKowpY=", "MiTCqxvDr8OJw5HDhcO4wo3DqnBMwonDvl3ClXs=", "w6nDtHjCtzE=", "w7zDoF/DuMOEw4jDrmh+wqNPw5HCtw==", "wq8zwqo=", "KFnDtMKyw5R9SFQw", "5ayD562Z6L6D5Yi755mQ5Yut5qyI", "CTB4wo8HwrPDhhk=", "54G56ZWh5o6D6I+K", "QD7Co2/CqQ==", "wpjCksOK", "woLCn8OUBMO8UHXDhsOo", "5LiI5Lmv55iU5ayu", "54+G5L+r5Za75q+0eR00w54H54GZ5YaF", "wqPDu3HCmsKIwolN", "w7vDnsKjQMOxXlPDvcKGwoRHw4vCnFHCg2rCqcOETRc=", "w67Dvn7CsiTCok56wpF6TsOjAxrCgkoLKyM=", "BE9Bwo7Dmw==", "B0tOwp7DuQ/CshxMwq7DsQ==", "wp/DicOFeQnDmyw8w6VFbA==", "LAAvbwEg", "wrw7wrfDssORXA==", "wq5bw7PCuE9KwqFX", "RMOPwqsRXEJcFcKbfXVIGzMYw6rDrXI=", "YXXDtHg=", "wrw9a8O3woASbcK2wrXCiT7DusKDZzprwrXCmsOQf8KkZVBLw4h3wrp0w4fDqQzChcKzw4F4OnJGQ0I=", "wpcMwqrDocOy", "wofDjXPClMKv", "XhlmE8KV", "bhRMA8K6", "w4JawrF1wpk=", "w7fDmsOmcQrCr8Klw6pe", "BkTDscKIw5JpUVgpw6s=", "wp7CnsOJNcK9QEnDq8K/", "w7XDisK/dMOf", "wp7CmMOQEsKHcQ==", "Y8O8OC1XGMKkJ1c=", "UB3Dg8KyKQ==", "wq7Cgg4uwrDCp8Kjw5Mww5HCuQ==", "ZAjChVvCvw==", "w57Dol7Dm8Oj", "UCsrw4c3woLCkV5vUBLDo8KyeVhdw7/CicO6Ymprw4Y1w71d", "w7zClMKvwoPCuw==", "wp/CmcOUAw==", "w5HDmcKrwprDhis=", "wqnChBHChhbDiw==", "csKzFQ==", "XyHCr2/CtMOk", "w5vDlcKxwr/DrjrCvV8Fw6FdwpF3ciXDuS3Dt2rChA==", "w4nCjiwZwo3CrMOWwovDuVgPw6k=", "w5Bowq1vwq8=", "w43CjjgPwpbCscOd", "w4liX8KLw4Vf", "wrpVDTRY", "bsK0B03Ch8O3w6vDkcOoBA==", "w7zDm8OzXQvCssKcw7wGw54=", "wqgywrvDpcOhSsOXIA==", "Ji3CpwzDqMO5w4DCjg==", "w6kaNCYj", "wprDqmvCjMKTw5Ju", "ISrCoh/DtMO5w4/Cg8O+wpfDqnBMwojCtUPCng==", "wqctdMOxwpZaMcOwwrnCgw==", "w6teQMKGw44=", "UMOfw7tEVT4KHsOZCyodDWdNw73DqQ==", "wpXDgcOGdTzDkTM0w6VQMsKvwrNy", "w7nDj8KoT8O/Xw==", "5Yi35aan5Yy25aWl6LeZw63orqrloYnlhIPmu5nmibHDrkfku6zljIrDmgTCvcKcwo4z", "XMOHw7tJVxM=", "NcOxesOpCF3DqcKh", "A0JCwpXDkhLCrixXwr4=", "w5/DnMKswpbDoTs=", "dMK+GlLClsOgw6rDp8OuDg==", "Q8OEw6bCtg==", "wopNwrITw73CosOxw7gew44=", "w55hUsKPw5J0wp/Dhh3DvhfCrDXDi8OLwoU5", "ZcKLwqPCpw==", "QzLCr2/CuA==", "YcOrMBFGAsK6Fw==", "VDDCvmA=", "b8KMwpoUw4fCisO6NA==", "w6/DuH3CrjHCpRU=", "XSk6w5kww6vDihB6", "wo7DoGHCvMKWw5RjZA==", "w4nCrsKhwpnCgMK+w4bCiMONHsOoOjNaUlNV", "VsOFw6xITA==", "XTjCpGjCrcOyYkgaw6Zpw7Ukw6Y=", "wqlCw6LClElW", "JyDCoSHDrsOOw4jChMOiwoHDsnBWwo8=", "woLCmMOZFsKrZ3rDi8O/wpTDrGnDrsOfRRAr", "w6UHw5vCu3ELEMOww6TDiw==", "w7LCphA+wrs=", "MS3CuBM7Oy0=", "w6VJR8Ktw7s=", "ERQIw6oyw6Q=", "QjTCrV7CvsOobEEGw6Jow7Ukw6Y=", "w4jDn8KhwpLDthDCtVUfw51Zwrptfi7DpBs=", "w73DpErDvcOOw4PCgGN1", "w6TDmsKqfsOiUkzCtw==", "w6fDrUDDrMOOw4LCrGN+wrk=", "w5DDn8Ki", "DAEcw7E+w7Ng", "wo9qw4PCu3A=", "acKewqPCthVIBsKEK1zCjkcbXVTCgsKBwow+wprCvMKq", "wqYsbsOywpZbNg==", "wq/Dol/CqMKT", "wqBdw7XCl0FGwqFMIw==", "HhgMfjE=", "w6zDh8OzRxDCpA==", "w5PDmE7Dk8O+", "NMO8aMOrAmzDs8KgK8O3eRg=", "wrAsfsOrwqRBNsOxwp7CmSTCp8Kmei56wrfCkcKNKQ==", "w6pdw6U5", "w4/ChgQ4wqs=", "PQsDw7A+w65gR8OGwpnCvgI=", "w5zDvkDDk8Ov", "w5nCo8Kqwp4=", "LU/CtRXDhA==", "w7nCjndzfw==", "w67DuHjCiTHCpxRYwoNjY8OVARvCiV0=", "w7J3wrNSwq7ClXnDnsOVwprDoxY=", "wo3Dv2nCk8KTw55he2llB3DDmQwRwoHCi0/Dt8OHR8OBwp8pwonDj8OjCC5hbR1OfQ==", "w4J9wrNC", "woDDoH4=", "w7bDgMKowoXDmw==", "VsKlw5daQzBnw5MxMk0dBsKqMcO3K8OJwp1S", "eTocw7Me", "VDbDgcKFFDM=", "wpfDmsKDAxzDhcOCw4bDtsKm", "NyTCqBDDqMOUw6DCjsOpwpw=", "woF7w49zw5Nfw4PDmsKP", "VMKHwo4/", "FC14wqMR", "TMOnOT1G", "wprDicOGcinDkRU3", "ISUUMMOzN8K1w6fCgUs=", "NcOxdMOsI3fDrQ==", "GVTDqcKZw7J8", "f8KIwpMlw5bCkcOeNQ==", "ISUUMMOzN8K1w6c=", "w6IKw53CqGY=", "wrzDvjDDoCE2FQ==", "w7DDncOBWwrCoA==", "XcKuw75fcDw=", "wpnCmcO1HsK2XQ==", "w7jDpkTDqsOtw4XCsQ==", "L8OqSMOzAnU=", "PSfCuDQNOzd/w7EEw73CqSUb", "UMOfw79JWRImFsODJiAC", "D0RwwpPDkwA=", "XsKvw5E=", "woZLwqAVw7zCsMKwwoo=", "wrIpwonDv8OrYg==", "w6zDm8O9RCfCtsKew40Kw4g=", "TDHDp8KIHyE=", "wrzDvjg=", "csKHwrUiw5fChsK6fA==", "wpHDhsOBaA7DgjI9w7JD", "w5JqwrhHwr/Cnk/CksOvwo3DtgFSwrQ=", "csKTwqTCsgMf", "wpvDpnfCm8KVw4pXZmR+AQ==", "woPDoUvCmsKJw5R6ag==", "w6XDi8K0TcOz", "IyF/wrcNwqY=", "bsKdwoQnw5Y=", "wqNVGQ==", "wonCuS3CjBI=", "w4jCkjkIwprCsw==", "QyXCs23CuA==", "KAokfg==", "wpA0N37Diw==", "w7TDnsKjT8OzSW7CvMKfwqJrw44=", "wr9TDTQ=", "w5rCqQEYwpM=", "wrnDhcOgbTU=", "UMKhw5hYcStaw58cPg==", "wrLDsDHDvgIxMng=", "w74Kw5TCqFYYDcO3w67Dlw==", "wp/ChMOuH8K9Tw==", "wrUlc8OFwpJGLMO8wqQ=", "JQMuSDUHLgLDpA==", "AktNwpXDmQXCixdbwqI=", "wqRTw6nClEVAwrV6", "wpTClsOTGcK3Sl3Dhg==", "woXCn8OSAA==", "BFjDtw==", "Dk9bwo/DvhbCrB1bwqjCl2LClcKC", "HkTDt8KIw6U=", "w4l7RMKcw79CwpTDih0=", "wqcpMmjDm8Obw5lWworDncOK", "w7DCjUV/bMKKwrJswoUiwowgFVE=", "w5/ChXV6Vw==", "VzbDgsKECQ==", "wrc8bcO1wqdBL8O8wqQ=", "T8OMw7bCssKhw7vCnRfDncKz", "wr06TMOvwpxf", "J13DqsKqw64=", "wpnDhMOEXi3DjTI2w6U=", "wrgsccOgwodA", "HwgBw4Y6w656D8Og", "w5B0wrFkwqrClWPClsOz", "w7TDnsKjT8OzSWDCtg==", "w7bCgVlu", "wppNwrwKw53CssOw", "MDDCpSE7Pxtww7oYw4zCsg==", "w4nCtMKhwpvCn8KSw6rCgMOXM8OiJQ==", "w7zDsWDCmTXCuA9YwoI=", "fcO7Og==", "wrYoccOpwpZaA8O9", "Jg4sZDEbAQM=", "w6dMw645S2pCwrY=", "RMOew7BDUQAzHsOJPC0=", "e8OrPilaHw==", "w4V3wq0=", "RcKBwr7ClCg=", "wqY1J27Dm8OF", "NC0UOsO5MsK0w6bCjVQuCQ==", "woFAwroaw7vCsw==", "w4XCqMKBwojCmcKYw5o=", "RgNH", "wrVbBz9RUUhs", "w5jDpW/CvyE=", "BkLDvQ==", "asKhw6x0Qw==", "Ky0eOw==", "w7/DvGLCtTHCpCBZ", "w77DgsKqwoTDvCrCoQ==", "w7bDqEXDtMOOw4LCt294wrBTw4o=", "w4vCtsK0wrPCjw==", "asKzH03CusOW", "YMKawr7CkxQe", "dUFyJGQ=", "wrg1wrTDscOtcg==", "IjdTwqgRwrfDlxwsLg==", "w57Ckz4Zwo3CsMOSwpXDvV8Hw6/CicOZ", "w5RgwqlDwrnClWzCn8OFwoLDpxJAwrXDuG3CuDpGU8Oh", "w7HDsV/Dv8OZw57CvmZCwrJJw4jCv0JtwpVQ", "woBWwocp", "wr5JKzBaTWR6dsO9MDNZwqw=", "w7ZUw7MjS3U=", "wqFXw7PCqVlBwoB7AsOhw4LDvRc7w7FnfA==", "wpnDjsKMDhE=", "wrrClwIswpA=", "FgEEw6Mzw7Q=", "dMKjAlDClsO/", "wp5Mwr0Zw7zCsMOVw4Iew43CkDM=", "H1bCvj/DvMKFw5HChA==", "w7XDuULDj8OZw5w=", "w7jDlsOmegvCpA==", "wpbCig04woE=", "wq7ChhcYwozCrMKnw5kvw6zDpMKEw4bCqcOZfgw=", "wpUkV8O2woo=", "csOaw5ZWRw==", "w5nCmSsSwps=", "w4dhUsKLw4c=", "w7jDlsOmfwTCosKew4AHw7VvMg9vQww9eBNG", "w6XDi8KsRsOzckU=", "OCdzwr4A", "YMK/BWrClsOmw67DocOzC09gw5s4", "w7HDlsOmRArCpcKbw7cWw4p6", "OjHChTg7Pyt/w7Ua", "XScrw5I2w5bDnx1DSRXCpMOIDw==", "w5jChyMZwpHCqsOlwpzDgkUAw6nCrg==", "QcKjw5NYcQ==", "JjHCpTIGND9+", "SizDsMKPHjM=", "w5TDgsKzwoHDpw==", "FS0NWQM=", "w6BVw7QyXHZqwr7DpsOCw7rDnSFDw7vDgcOAw6A3YsKs", "TcKvwrUCw4Y=", "JMO4aMO+KHrDtMKgDcO8YADDmE8tw7wQw77ChQ==", "w6rDmcO4fik=", "IjQKMsO/JsKdw7fCjVwoUsKrwrbChQY=", "H17Dv8Kfw55/R1g=", "w6APJSsYfgQYwrpPMg==", "w6kaNAYj", "Y8ODw7BsaA==", "wpzDicOcfQ==", "w5/Dn8KhwpY=", "wq7CkRXCjBrDnQ==", "w53Cp8K2wpQ=", "VsKYPnfCpA==", "FDXCmDMq", "UcKvw5JT", "wodswoQsw7w=", "w4RrwrhUwofClGrCmsOv", "woU4OlHDqA==", "wrdHw6LCiFk=", "wr5UHzhARnNXTMOx", "w5t7U8Kcw5I=", "w6UXw5HCqnEwBw==", "PzfCoSMn", "wp/ChMOpIw==", "dsKSwrTCqQIX", "w77DncO9XRzCusKfw5Ycw7lwIgM=", "w7cNw5/Co20UDMOsw7jDpsKmwrfCtA==", "wrDDsMOBTys=", "wpvClsOFKMKxV2nDjMO5", "UsOWw7fCpcKvw7XClBDDlg==", "Py3CpykhBT9ww70awonDvXVDTUEtFsOvw61WQ8OndcOfw7Atw5vCkMOuw5nChU0Fw7Y=", "TzDDiMKIFRsvw6vDpgrCpg==", "a8K1Fk3CncONw7rDocO0Dm8=", "XD7CrWjCsw==", "w6nCkF5kSsKO", "CULDvsKI", "QDDDi8KE", "wrI0wqzDvsOwcMOMG1vChg==", "SA1TMcKuwqQsVwPCkgo=", "cxDDvMK1", "woMVJ3nDmg==", "bsKdwo8iw53ChMO+N3E=", "w7RKFDU=", "w6MQw5XCv10XBcO2", "IsO4b8O6", "wro8MXTDl8OM", "wrVXw7TCiUldwppBBMONw5U=", "eQlUecK/wq4ySQ/ChA==", "woR2w5dQ", "FVlGwonDtRnCpBw=", "ZsKoFEU=", "wqXDojrDoi4tHXM=", "wqJTw7PCmw==", "dMKawqIlw5bClA==", "w7rDkMKq", "w7nDvHjCug==", "WwPCpkvCtQ==", "Kx8nZD0N", "w6PDjMKoU8OfVUfCvQ==", "BVXCviPDnMKP", "wrUle8OUwpZGJsOWwqbCiD7CvsKQ", "wo3Dm8ONbgXDjTo8", "D1pGwpXDlRM=", "wp3CgBUowpo=", "w5vDlcKxwqDDqjvCp1UDw4k=", "XcO+w4l2UQ==", "w5VZw64ceA==", "woXCg8OPHsK8Xw==", "QSTCr3PCpA==", "ISfCpiU9KDxjw50Yw4/Crw==", "wrZKGRhQ", "w53DgMK1wrrDqw==", "wq/ChzHCkAvDisOCasKLw5A=", "wqPCjADCjQ3DgcORaMKnw5XDoMOiMgA=", "w6XDnMKoT8Oz", "w6ZBw6kyQGxdwrfDkMOQw6fDkxw=", "wqvCghAuwrDCp8Knw5kww4vDq8KOw7vCn8ORZQrCkcOb", "woVvw5dUw4Bfw4zDk8KuwoExw7nChRNhwo41", "GW9xwpLDkg==", "w6sFKikueg==", "wr87wq7Dtg==", "Rz7Dm8KA", "ecKIwokq", "NCHCmQjDpMOCw4zChcOFwqA=", "wqfCkCvCih7DgcOeYcKYw7XDig==", "Jytx", "w47Cp8Kwwps=", "CyMPSy0=", "cMKZw4J/XA==", "wrRSCD9aRm1XTMOx", "bsKKwpglw5Y=", "NCfCtBMqLi14w7oR", "w5nCssK2wpPChcKQw4HCh8OA", "wrYobMOiwqFNM8OswrPCniQ=", "Lis+w5A=", "w4Jswq9PwqXCnGTClcO4", "wqrCjA0twpzCuA==", "fMKDw4RScg==", "w7zDnMO8VQzCsA==", "w4ZKw6w+Rw==", "wpLClsOJFg==", "J8O9RMOtBGbDpcKqNsOW", "DkTCryw=", "UsOTw4FRVxMBGMOkDA==", "RcOew7pCUT4g", "wrUtQMOxwppMJ8O2wp/CqQ==", "RBzCgVDCjg==", "BUfCsSjDlsKf", "w7NEBDE=", "w4tqacKYw4JPwpzDgCbDiQ==", "w6vDtGjCvjvCnyU=", "wrAoa8Om", "w53DlMKawoXDpivCtlMkw6o=", "NyPCtCE=", "C0HChC/DlMKFw5nCjjLDsMKt", "w7bDqEXDtMOOw4LClk4=", "wpHDmsKZDA==", "wp/Dp3bCiMKuw5JhfHQ=", "TRbDuMKwFA==", "wqvDjcOcMQ/DjDM4w75U", "55ul5b695oit5YqUFA==", "NCvCqRDDtMOLw4bCn8O/wqfDsUta", "w5fCnisfwpc=", "wrXClxHChho=", "wp/Du2vClsKUw5ppaXk=", "woPChMOYBcKbVnrDjQ==", "FBE1w5Y6", "w45vQsKP", "PjdzwqIswrzDgx0=", "w77DmsKsRcOJWE7CvcK4wqRv", "wqbDnsKZQDrDmMOkw4nDusK7", "w7fDlsOzVzrCtMKfw4wEw5N6", "e8O+HSlR", "VDA4", "X8OYw7k=", "f8KIwo4uw6HChsOmJG0qBQ==", "wqk/wqvDosOhZsOK", "wpjCoSwYwqI=", "WS82w6I2w5Q=", "w5TDlcKkwpfDkCzCvFMGw4dI", "w7RJGTUKL8KqL1lKOWcv", "wrQ8JFPDmg==", "d8OvIy8=", "w4TCp2tsbA==", "wqLClQDCiQ==", "XMKJw6Fnew==", "w75pQMKtw4Y=", "w7nCjUlJQcKTwpVswoY/", "w73DsWbDnMOe", "wqtfwpI+w7Y=", "5b+15b245rWv6Iif55G6", "w7zCh0VUR8KFwrpt", "wrcmccOhwppP", "w5TCmy8SwqDCu8OLwonDn0Qd", "wpXCmMOTEcK7Xw==", "wopKwr0bw7rCoA==", "D1pGwpXDoxTCqhZNwq4=", "BV3Dv8KDw4h2QFo+w4BVLmrChsO4", "w4V+U8KAw7RfwpzDgh/DigLCniM=", "w7zDnMO/QwTCpcKVw7UKw4hsLwlu", "w6zDisOhRwDCug==", "TsKtwrYdw5bCkcOkOGc3", "wobDi8KBBA0=", "w7sCw4g=", "w7LCjVNsWsKD", "w7oGw57CqmAR", "woXDjsKeBQ==", "ccKMwpMsw4fCiw==", "VMKsw5lZZg==", "wpjCvsOqJsK9", "w4xiWcKBw5k=", "w5lmWcKZw79EwpjDnBs=", "wromccOi", "w59Rwop3wqQ=", "BGTDjcK8w7g=", "w7ZFw68gbXdlwrTDi8ORw6M=", "56Gd6KyT5o2O6Ya1", "wqnDo0jCoRkbM8OQBQ==", "w7XDkMKjR8O/SUw=", "w73CiVNoS8KH", "wr3CgsO+I8K9", "wo5Awqcqw6vCisO4w4kCw7rClzQ=", "w63Ci09uS8KFwotrwoQkwrA=", "wp/Du3jCmMKf", "wqwzwr7Do8Os", "w6lIw6Yj", "w7QMw4TCuXsU", "wqXCjAQ=", "wr3CkQoswpLCusKhw7sB", "wobCucOWO8Kb", "w7wDKSo1", "wqpdw6jCig==", "RcOew7xVXwMBMcOYJg==", "C05iwp/Dvw==", "wrUle8OUwodJJcO8", "MF5NwrDDqg==", "wrYjOnzDl8OP", "wo9nw4Zfw61Qw4HDm8KiwoE1w6rCjhVHwog4Mw==", "w4XCqMKXwo7CisKFw5w=", "w5B0wrl1wr/CmmrClg==", "SMOLw5fCucKH", "MC3CriYmPQ==", "bsKawrLCqDkTRcOPGFbCnwxGGx/CgMKJwog=", "C0HDvsK+w6NwRlI=", "w7nDkcKIT8Oy", "MRwneB0HJgg=", "NCnCojHDo8O0w5zChMOiwo3DsEg=", "U8Ksw5JlYDh0w54=", "w6cEFjopcwIZwrY=", "UDQdw4QP", "RMOKw7zCscKKw70=", "w7nDkcKfVMO4VUjCvMK0", "TDYyw5I2", "woN7w4ZQw4Bww4HDkw==", "w7TDnsKjT8OzSWjClg==", "w7HDuGLCvCDCvg==", "wqvCgg0lwpDCrcKSw5g=", "w7VEHj4BKcK1Dg==", "UMOYw7BBVxA=", "Wj4xw5kqw53DjC58RR3Cv8OkOAh0w6LCkMK5ZA==", "w6ZCw64xR38=", "wqYsfMO1wpZJNsO8wonCgyXCug==", "BUvCmSzDm8KFw5LCmQXDi8KbS8Kv", "woXDvFvCnsKUw5NlfVNiBijDhEU=", "JEfDk8Kpw48=", "AkTDvsKIw5VwT1k+w60=", "wpbDlMKDCxDDkA==", "w5TCmy8SwqDCvMOGwo3DhFkHw5nCrcOyPmnDtgdU", "worDicOGVSLDlw==", "w6dMw645S2pqwrbDvcOAw6LDlRlFw6LDqMOGw70UdcKywrtoeVrDhsONw6PCkg==", "LRwBYjEINA==", "HA/CmSQi", "w6LDlsKgRMOk", "L8OqWMOzCGPDtMKRFsO/ZA==", "CULDtMKLw752", "w73DksO8XQDCpcKRw4cww5lzLwVrch4JYBRLDMKFBjLCgQTDtMKf", "wrYsecOowoFNHcOpwrfCniPCiMKYdjBjwqzCoMKfKA==", "w55LAyQ=", "w6dIw6Y4XH1MwrPDj8OGw5vDtQ==", "w78Qw7PCuGYwDcO6w7nDgMKowqDCtA==", "RcOEw7zCucKGw6jCvhbDjsKkZz01", "UMKhw5hYcStew5QPI20CJA==", "EFnDqsKpw6M=", "OSV4wpkLwqY=", "wrjDqknCuDEGJMOZBsKX", "w6oLKiEibyYYwqdDA23DlQ==", "f8KIwpMlw5bCkcOaPn48JcONw68=", "w6zDh8OzVAA=", "dcKMwpQsw5vClw==", "wpQXwoPDs8Op", "WRhBM8KZ", "wrLDrk7CsTwA", "czbDl8K4", "SBlUIMKTwq8CVR7CgBrDuHBhwq/DgivCrMKbwooy", "w7fDpkXDvMOCw5c=", "wotQwqcJw7zCqcOCw4oYw5zCnRhMenXDu8K9w7Yz", "Py17wrUX", "w7vDp0jDvw==", "w5HDpEDDncO9", "NyTCqBDDqMOUw6rChsOvwo3DtXtWwobCtQ==", "w4jDmcKowpbDvQ==", "wrPDpC3DojMqFnlC", "w7HChl5u", "aMKWBHTCug==", "w40LNyo=", "w7TCphMYwpI=", "w63CnFxsSw==", "Wj4xw5khw4rDlhRnRxPCuQ==", "aDYnw64=", "wp3DoMO9RDo=", "w7TDnsKjT8OzSVLCusK8wro=", "TsK0AlA=", "w4/DmMKqwoTDjS7CvVIIw5w=", "cMOmMi1ZPcK+Fntv", "wrDCnRDCjRDDpsO0", "HRYIw6Uvw6VGD8OlwoHCvAPDvcKrw4/DpMO3w7jDj0PChQ==", "fsKbwpgqw4fChsOFNH84A8OGw7rCgcO/QDUiw7LCvCU=", "wqIge8OiwpxhBg==", "wo7DgcOMeSPDojg=", "w7kNw7XCv2YWEQ==", "CEtQwq3DlRPCpxw=", "HQwIw6cww5Z9DsO3wo8=", "CA0Jw6E0w4Fw", "w513wro=", "5Y2y5Yul5LuI", "w5J3wrNAwqLCnA==", "VMONw7PCpcKG", "w7LCvhg0wo8=", "w75WLyMMOsKOL3RYNA==", "w5lmV8Kcw44=", "wp9MwrcYw7zCl8Oxw4YOw4PCliA=", "wrrCiww8wqHCsMKyw482", "wqbDuDvDtQgTF31JwoLDpcO2", "ccKzFUHCnMOTw70=", "IiQ4eRo=", "wq/ChzHChhvDisOU", "wr06WsOpwpdNJg==", "w6FMFDULC8KQK1JQPm8=", "YMOew5Vibw==", "ZcOnMytdO8K7E2dpw750", "w7sCKzgTcgoEwqU=", "A0tNwpjDmRvCgR9XwrnCqG7CnA==", "d8KDwrPCowkzTQ==", "wpnCmcO+G8K9S3k=", "RDnCr28=", "wqnDo0jCoQ==", "wrnDqlPCtTw=", "w74Cw4PCm30dBsO2", "KAAl", "wo1QwpUqw5Q=", "bsKBwpw5w5Y=", "w5rDh8KjwqLDpw==", "w6oPIiA1eA==", "QcK0w5dEYAp7w5oLIw==", "wqPDpDzDswIwCE5VwpzDqsOjw64=", "w73CiVNoS8KHwp9uwokzwrMsHA==", "w6TDgVjDr8O8", "w4lhWMKIw4JM", "QMOfw79VWyQQEsOdeQ==", "w5l7VcKNw45YworDvQrDugLCgSI=", "w63CgFx5S8K4wqhnwpBh", "Szc+w4Uhw7nDjgFDRQjCvsOgLAU=", "wovDqm3CrMKSw5xyaklkDzA=", "QcKow5dEcQZ6w5UfKQ==", "w4zCqsKrwpXCmQ==", "cMOhOShbDA==", "w5DDlcKrwpTDuyc=", "w6XDl8KsU8OzZEjCvMK1wqI=", "DQwMw7Y+w599BMO0wo8=", "FENXwpfDmQ==", "Iil3wrcAwqE=", "b8Oiw6LCkMKQ", "wrckLHDDqg==", "A0vCrSTDgcKOw4XCtCnDncOU", "QMKtIHLCgQ==", "csKCwrbCtAMtQMOFIVw=", "wrPChxHCmjbDgcOWaw==", "SMOVw7fCucKKw74=", "dMOvOit8CsK6Fw==", "wpvDnDHDnQA=", "YMOqc8O6H2fDn8KsG8KvMQ==", "w5PCijkqwpbCusOWwpY=", "wq9Bw5jCiUhTwoZ7MMOJw4g=", "wppNwrwKw4XCrsO5w4IY", "wr7DjXTCtC4=", "5Ymm5LqB5YWQ6ZSW5pqC56WN6KSE6aOi", "w7oPNzoqeA==", "SDtqAcKL", "w7/DkcKkVcOFU0DCoMK2", "w50Nw6XCvmQ=", "woXDs8KeGC4=", "CxQJw6Uvw6VHAsOzwpLCqyrDvcKhw6w=", "w6fDoUTDrcO4w5jCvnh0wppew5DCrw==", "TDHDvMKJFDM=", "KsO2fA==", "CXTCjiHDrw==", "wqguwrvDpcOwRsOWJUDChw==", "wpN/w4JDw5dyw4zDk8KRwoYiw6zCiw==", "dMKuEFbCh8OBw7HDr8OzBQ==", "YMO7NC1XGMKkIHt3w7FhGQ==", "EgsK", "W8KEw5FmRw==", "w6fDvUrDqMOfw6PCt2tjwrI=", "MsOwdsO+Hw==", "wrTCkQfCnRLDig==", "wrIodsOrwqBAI8OrwrM=", "VcOWw7dLbR8FBcOI", "wpPDmsKEASrDn8Oqw5DDtg==", "a8K1Fg==", "OivCjhfDqcOD", "w7jDpkw=", "XMK4wpoBw4o=", "w4/DhMKkwoHDuxzCu10fw4s=", "w5TChQIVwpvCuw==", "w5vDlcKxwqHDqjjCsk4J", "5Y2b6KeR6aCy", "wqRSBiZiSmVtSg==", "wqLDsDHDmQk3", "wrh0w7B7w5Y=", "wprDi8KIAybDlsOvw73Dv8K/wqge", "wrbCgC7CmzI=", "w6cEFycoag==", "DEVE", "ccOMw4bCpsKp", "UDzDisKPHg==", "w77DlsKpRMOUWk/CvMK2wr8=", "wqTClRrChhrDncODbMKFw4s=", "D0RrwpLDmBI=", "TMK4FnTChg==", "w4N9dcKbw5liwpfDjB3DqALCgCM=", "OVfDr8K9w5A=", "wqTDuDLDtRU=", "wopQwqEPw4fCrsOww4IF", "ccOvOSBXGcKUHn1pw7tHFC7Cpw==", "w57DkcKrwp3Dqj3Cslgyw5hMwoxyeRTDqRLDp2fCjGwKw6cMwoQ=", "w7rChy4VwpHCucOhwpzDk1kbw6I=", "5YKu5a6/6amE54OE54Cq5YS85oqN5Yi45Lm35q6L", "CVlgwpPDmRbCtg==", "w5hrwp5Owq7CmnnCp8Oowo7Dtg==", "wpR+w45Uw4A=", "wqXCgQbCmivDhsOdYcKY", "w7/DjMKOScOzWlU=", "w5XDg8KGwpvDqi7Cpw==", "w5cPw5TCpHoeMcO8w6jDisK7wrc=", "wqVfGT5GV054F8OUMyA=", "w4tiUsK9w45Fwp3DqhnDqA3Chw==", "wqdew6PCqUVcwpBbGcONw4LDrw==", "w4vCqsKgwqnCn8KWw4/ChA==", "BUPDiMKYw7l/SFk8", "wr3DqkrCsxoVOsOU", "w6NKHzwX", "wqRSCCNRYGBkScO3PidX", "6Kyx5Yuy5Luf5YuY5Lmy5ZKj55i0576g", "5p+A5q6u5Yif5LmU5pSa5pe177yM6K+45YiG5Lqh5YmZ5YSp5Lm3576F", "QcOJw73CuMKR", "wpvCqAkvwpI=", "worDicOGeCPDjg==", "YsKFwrnCoA8V", "Py17wrU=", "fsKGwpMtw5rChA==", "DQwMw7Y+w594BcO8wofCkRPDscKiw7w=", "woN4w41Xw5tW", "w6ULw5HCv3EmD8O2w6XDgsKWwqfCuMOqdQ==", "wqVdw6nCnElV", "w6zDm8OzQQDCiMKcw4wBw51AMg9tSA==", "wqQ7cMOlwpJKK8O1wr/CmSk=", "KCt4wrYMwrU=", "WQRBJsKZwp4xTQjChiHDk2pkwqU=", "w7XDkMKjR8O/XA==", "wrVaw6bCiEVtwphxAcOPw7PDrxEFw60=", "wrbChhvCih7DjcOZaMKDw4jDtw==", "woZ7w4xew4A=", "QMKhw5hSezQ=", "w6QFIw==", "wpZrDhtN", "w5fDqMKGwpbDqA==", "wqpWw6p9w4A=", "BkrCvA==", "wptJGgd1", "wrVaw6jCjWNdwpp4BsOaw4E=", "w67DqG/CuDHCpRJvwpVgSsOCBA==", "w7nDn8ODfRQ=", "5Yu+5LiD5YqY5764", "w5fChC0=", "w73DocKiwrnDtg==", "UDfDgMKWOCsiw6LDuhbCvw==", "wqJRLDdY", "csKfwrTCpQMBWsO5IkTCiBtM", "wrzDp3bCmCU=", "5YqQ5LiU5Yu9576F", "w5lmV8Kcw455wpjDmwbDog==", "csOmw7ltRw==", "w4nDsHzCgzI=", "wrnCoiYswp8=", "w4FpXMK5w5k=", "w63CgFJ8bcKEwrJkwokiwrU=", "w7ZFw6ElSw==", "DREOw6c+w7NnOMO3wpfCrxXDvA==", "wprCncOsP8KW", "w6LDtcK0UcO9", "wr8NUcOLwpQ=", "WQRBJsKZwpM8Vg/Cjg==", "wrw/wq7DhMOhdsORKlbDkw==", "fChGDcK4", "w7BABAQNNsKZ", "f8KMwpskw4HChg==", "VzTCvlXCtMOtaA==", "WsKhw6JMVw==", "QBnCuXTCig==", "wotKwqs+w7/CrsO+w4w=", "OyTCsBfDqsOHw53Cj8OYwovDk0ZRwoLCgF/ClHslGA0=", "wrrCkDImwrQ=", "wqjClQLCgRjDjsOEYcK1w4jDt8O7Hg==", "RA1WPcKbwqApRzLCjjPDjm1gwpDDhxvCv8KAwoY6", "w57Dn8K9wqDDuy7Cpw==", "wr0kfsOgwpZbHcOwwrI=", "CVlmwoPDiBLCsB1fwrY=", "IRc2byYHIQvDlMOJwrDCv1/Do8Oq", "IUZHwpLDkhDCkBZdwrXCsW8=", "LkFbwovDmw==", "w7vDlcOZSy8=", "w7PDnMO1", "BzPCrzHDtA==", "ZcK1CXfCh8Ozw60=", "w75IETcBKMKjI08=", "W8Kzw7NOYDxhw5UYKg==", "w7PDh8K5RMOkVUDCvsKRwqJyw7nChlHCkA==", "wrMsa8OOwp1b", "RsK2FU3CncO1w4vDq8OiD2l9", "5oqd56O2w5IHwrdWUcOLw6PCjsOfV8Oww5nlpJHotZvlmpDosIc=", "w4/CvsKwwp/CmcKZw4nCjcO7MsO/BDdXQw==", "wpPChcOPGMKg", "w7nCjUlHT8KewrJhwogfwqg9EVvDrcK+w5FewoXCug==", "w7rDi8OmVhfCucKRw48iw5NxLy9E", "wopJwroYw73Cs8OLw4IFw5nCkShX", "dMK5FErClg==", "M8OqfsOpJGzDpsKq", "Vy86w5ktw5w=", "dMKyEFbClsONw7DDqg==", "w6fDqk7DtMOO", "w4nDg8KgwoHDhiHCtVM=", "w7bDgMONXQDCoA==", "w7TDsG3CvDHCpQ==", "wpIJAA==", "L8OsVMOOHA==", "w77Ds8KaS8OC", "w4ZhUQ==", "LysMRjM=", "w5jChCcMwp7CrMOWwq/DlUQaw6/Cr8Oz", "w63CjUlAS8KOwqxRwoMiwr0sFnvDrQ==", "dDA8w5Yow6vDih58QRzCqA==", "WRhSPcKSwqY0RB8=", "Igo2aTwlLwTDt8OKwozCjV/Dow==", "w5HDsm/CujjChRVSwoJ2TMOV", "w5Z9wqlvwr/CnmA=", "GSrCpR/DocO1w53ChcO+woXDuUo=", "wo5Awqc0w6fCosOw", "YcOrOiFEDsKbHX1hw7xXHDfCow==", "wo/Do3zCnsKI", "wqYoccOOwp1c", "w7LDpUTDtcOZ", "w4/DlmbCvzM=", "w5vDlcKxwqHDriHCt1MAw69fwpd/ZA7DphvDo2HCiUcN", "wpJIw4TCjGM=", "DAUDw6A0w60=", "wovDh8OaaA==", "ISPCriQgNw==", "MQ14wrQAwqrDsR0ZLcOE", "w6UTw5zCpHcc", "H0vCqCXDnMKNw4M=", "5beA57iP5aay5Lq457266aCv", "UCVOMMKZwrkJTSTCjgrDk2xk", "wpTDjcOGezjDiw==", "wqPDoTPDuQQm", "w6YWw4PCpQ==", "RsKpw5tTUjZhw5YYMg==", "wrnDpBDDhRY=", "wqHCkQDCvBbDgsOV", "R8O0FDhx", "wpHCksOJOsK9VmjDig==", "JinCrx3DqA==", "wp/DjcOcWC3Dlzk=", "WQBJN8KZ", "GUHDs8KOw7I=", "MCgTPcOz", "QxlvAcKN", "Xzorw6Qhw5vDkR9qUw==", "NcO1csO4CA==", "MiDCsjjDuMOKw4XCs8OpwoXDrA==", "DQEOw6s1w6RSBcOgwo3CrxM=", "LSh5wr8X", "XjMww5g2", "U8KcwobCsig=", "wrzDhFXCsxI=", "w64GKyA1", "wqDChyHCmBM=", "ejYpw68T", "w6UPw5nCrnE=", "woF7w6bClWY=", "w7sGLSwi", "wqRWADJR", "Q8KDwqHCnjE=", "BMOwbcODOg==", "w5QKw4bClUM=", "w6xeYcKow4Y=", "wpN7w4pSw5c=", "w7EGw4TCnnEaDMO3w68=", "wo9JwrwSw6E=", "wr3DrlPCgj0ZMg==", "Iwo2Xj0EJQ==", "w53CgiYIwprCrMOgwo3Dgg==", "wrJFw7VGw6Q=", "QjTCum3CvMOjaA==", "wq/Cjwwkwoc=", "w5rCqcKz", "VA/Dg8KPLg==", "HkrCiDnDh8KCw5nCjA==", "wrrClgE4woHCrcK6w5Il", "XgNzIMKOwqgzRQ==", "PyPCszQGND10w6w5w48=", "wqJlw4xGw4FUw58=", "w78DKisoag==", "KVjDqcKZw7h8aFM+w6c=", "USwcw4I3w4zDkRxdSBTCug==", "woXCjsOOA8K3VQ==", "esKMwokYw4rCkMOjNGUQH8OEw7DCtsOQRzI=", "YwJTIA==", "wo/DuDHDoxM=", "wpHDhsOBaA==", "EDfCszQgNxV4w6cC", "wpgvwqnDo8OreMO3IFfCmg==", "TsOWw5HCosKQw67CnBTDq8KpXCU=", "wovDjcOLcyLDhy8=", "YsKfwqXClQMRRsOFIw==", "w7PDlsO8VBHCvw==", "KVDCqDnDmsKGw7vCgjPDjQ==", "wplQwqAV", "wrzDuUbCuzE4OMOeGQ==", "XsKvw5lGUix9", "bsKpMlHCgMOmw7bDo8OSCHRu", "MDfCshMqOTZ/w7A=", "dcKDwrrCoxQ=", "wrEpOG7Dnw==", "Fz45KMOV", "wrrChgAkwpvCu8Kg", "wovDgMOHaw/Dli8nw7hc", "wrrCmhA/wpDCsg==", "VDbDgcKFFDMbw63DtxDCug==", "dMOrIxlKJsKyHGtQw79g", "Cgsd", "wrXDpWvCuTUQ", "w7zDhsOhRwrCusKxw4c=", "wqchcMOwwr1dLw==", "S8OKw7U=", "wrVaw6jCjWNHwodqAMOF", "w57DqH/CrzvCuy1UwoNj", "wrkpOn3DisOA", "wpgvwqnDo8OreMOyLUHClg==", "eyosw4Mrw5XDtxVrWA==", "NjDCtQrDosOLw6jCjg==", "Szcww4A=", "w7sCKzgJaAY=", "w6xew4MiXWxkwr/DscOLw6HDiw==", "wq/DumrCi8KVw5BMZnN+", "a8K/H0PCh8O6", "wp7CnsOZEsKRTW/DlsOiwoo=", "wrvDncObaCPDjhA6w6RF", "KAosbSAB", "w7Jtwq5SwqTClkHCmsOywpc=", "fsKcwo4/w5zCjsOWNQ==", "w6xew5M/QW8=", "wq7CnRDCjQ==", "w7HDmsK5dsOudkTCvMKmwp1lw5k=", "dMOrIwNXBcKiMGt0w6R8EwHCrQnCm8OAfVQsUcOdT8Orwq7ChDXCmwzDnQ==", "wqgjwqnDo8OheA==", "w4/Dk8K3wpbDqiHChFUJw5pF", "QyXCq2bCuA==", "w6jDmsO2Rw0=", "wrgsecOz", "NyrCsgrDosOL", "M0lGwpXDmQ==", "wrRXw6DCuUxTwodt", "MsO8aMOvQkXDocKoGsOBYgnDpE8=", "A1hGwprDiBLCgRtXwrbCp3nCncKJ", "JcOrfsO6GWfDg8KtFsO+ZR7Dr0Q=", "wr3DvSjDnig=", "woFTw6rCn3NRwpFwCsO9w6U=", "w5fCvCgLwrc=", "w77Dr2nCuiDCsyJVwpl7T8OCBRE=", "w7RXFTEQPsK/IkJVNHokw6I=", "w7XDjcKoQMOiXnfCu8K2wro=", "ZsOnASdXHA==", "XRDCrWXCqw==", "woDCjTUMwq8=", "woDDoHjCm8OVw59nIWp6Dg==", "wpHCrQfCkjY=", "w6jDl2XCnTY=", "LcOFw41nwoPDj8KnfTk=", "w5LCijwXwp0=", "w7/Cswc0wqU=", "woVKwrIZwrzCq8Oyw4AYwoTCiCle", "w6R0XsK/w6g=", "w7jDpkrDvsKEw4TCp348wr1Qw4TCvR5Iwolb", "CAAjbgcKJQnDs8OzwoE=", "w6XDmMOGfRc=", "JivDrjQqKS0/w5gZw4jCpBsdFRJ1fsKb", "wqTDtCzDpA==", "wpjDqmrCiw==", "wocqbcOuwoNc", "wovDicOeeQjDgigy", "w5PDnMOxUgnChMKEw4wdw5t4Iw==", "wp/Dqm3CtsKOw5ht", "wrzDicOcfQ==", "w7BABBkQPsKR", "GQUAw6EVw6F5Dw==", "w4QFJy4rTh8YwqNHMGc=", "wrw/wq7DnsOwcMOT", "ZsKLwrrCoygTRMOO", "d8OWw6pG", "wo3Dq33CvMKIw5xzZw==", "WAlNO8KKwqQRTQXCgBLDo2J9wqE=", "wpc1wrnDtsOoRsOKK0DCgzt2", "w7V5wqlH", "wr07W8Omwro=", "w7LCmBodworCrcOW", "aizDvMKVGjY4", "e8Kzw6VDdzp2w4gK", "wrMocsOiwrBcMMO1wro=", "w7PCt1pqQ8KOwpN0woUi", "w5ZCw7U5SlVqwrzDg8OEw6vDjg==", "wqHCkQDCoRHDnA==", "OgUZw6U=", "woDDqm/CmsKW", "OUrCriPDkcKmw5bChSHDnsKMVg==", "V8OJw7PCrsKww7XChhfDnA==", "w4tiUsKhw4VuwpfDiw==", "WcKIwokq", "w6zCunZKZA==", "wpAoa8Om", "wp7DnT7Dqg4=", "wroiN38=", "ESYWcyQM", "DUzDt8KIw4JY", "esKpw5JT", "wpnDvyzDpA==", "w6ULw5/CulocG8Otw57DrA==", "wqQoasO0wpZvI8O0wrM=", "GV7Di8KAw5Y=", "w7hrwo5SwqrCiXk=", "w5bDgMOCUhDCpMKV", "wrzDiMK+GRjDhcO/", "AjdGwrEQwqHDgA==", "XMOZw5xTUDERGcOOPCwfEw==", "Wi1lM8KW", "bsKIwr3CiwcC", "wo91w4lww4BDw6DDnsKN", "DQExfg==", "w7TDs3/Crw==", "SjHDnMKV", "dMKHwo4/", "dMK/BWbCnMOq", "woF0w5dYw4RU", "woZHwrk8w6HCtcOQw4YH", "JSV7wrU=", "wo5Awqctw7zCqMOx", "IcO8bw==", "XDTCpGbCqcOo", "UzDDnw==", "wqbCgQkGwpTCrw==", "dMOrIw==", "wrg2wrXDucOh", "wqfClwDCgQnDig==", "ISfCoy85PytBw7sZw4U=", "fMKKwokiw4XChg==", "woLDrnTCmg==", "wrwiMH/DhsOnw5c=", "w4nDm8KoUsOiVFg=", "w6tMw60y", "esKMwok=", "wrU7wrfDsg==", "wodyw5c=", "RA1NMQ==", "w4jDn8Kqwp/DgS7Cvlke", "w6/Dn8OzSgDCpQ==", "w4bChcKcwpHCvg==", "w4ZYw6MiQ3puwqDDvcKTwr0=", "w5XDhsKhSMO4X0TCoMOjw707", "IMO1dMO0Hw==", "wqrDtQbDmyQ=", "wojCthvCmQU=", "ZD7Cp2DCqcOv", "MAo6WjUdKA==", "wrgmfsOjwr5HJsO8wrrCng==", "w7BABBEIN8KxJU9cPF0zw6Bf", "wr5UACVgRnl8UMOnOg==", "w7rDkMKsRcOzSQ==", "A1hGwprDiBI=", "wr3DmsKDCRXDksO5", "w5bChC4ZwpPCrQ==", "wqpXw6nCnVRa", "KsO2esO/CHA=", "wp/DjcOcUSPDhzk/w4JDM8KywqNYwoJVw7o=", "GizCszQ=", "GUDCrw/DmsKT", "Hy9/wpgR", "Iwo2WjsGLA==", "IcO8b8OWAmbDpcKpPMO+bgLDr2glw4cUw6DClA==", "I0vCqDk=", "esKMwokGw5zCh8OyPV0rHcOgw6bCq8OIRDQ=", "wrrDpUM=", "w7HDmsK5YMO6V2zCvcK3wqhmw7/CgFzClw==", "NCfCtAEjNhR+w7ATw4XCjikTFQ8=", "FyfCvhfDqQ==", "w4zDhcK2wps=", "GH/DkcKsw50=", "wpdFw41Fw5M=", "w68PMA4rcSYYwrVDO0zDhC0Cwqs=", "RD7CpW3Ck8OhYEob", "VDoxw5Aww5A=", "w6bDisK+SQ==", "wpHDhsOBaBjDhiQnw6JDOg==", "dMKHwpQ/w6fChsOvJX0rFA==", "wrZHw7TCkg==", "HX/DtMKZw7Y=", "DEzCtyjDpcKKw4PCgw==", "Z8OrLx5TH8K/", "wqrCmxXCjBrDnQ==", "woHCgg0vwpnCusKh", "wrApP07DjA==", "wrbDpEbCsjEG", "DUDCrx/DkMKY", "w5jDhn3DoMOi", "wr0zwrbDssOUdMOKLA==", "w55rTsK+w4pfwpE=", "BAZQMw==", "GwYseQ==", "DCvCrjM=", "wrZMwr0O", "wr3DjhnDuQknOHRZwofDr8Oiw4hyEV3CoF4=", "OyTCqxs=", "DhEew6w=", "fcO7Og1aAsK7Fmxlw74=", "Dh4hewA=", "JhtQwrkLwrbDphokLsOQIh/DjsOpP8OVw6U=", "wrfDtCvDkw8qF3hxwp8=", "w7bDsGfCmiI=", "wrBfHRJbTnFnS8OwMTA=", "KhovSTwALAPDpMODwqY=", "woPCkgA6wqE=", "wo7ChhcIwprCssKjw5Msw4DDpMKWw5o=", "EcORXsOZGQ==", "bcKcwo4j", "wrTDvkrClTwdO8OVG8KFEA==", "w41Ow5YDXQ==", "MiDCsj3DpcOPw4XCjsONwpA=", "wr/DjcOcXyPDjiw8w7lUMcKEwqk=", "ZsKPwqPClRIAasOEK1zCmz1HPQ7Ckw==", "b8OGw4TCg8KQ", "WhlTPA==", "w5fDkMOcVwI=", "w4ZIwrFIwp4=", "bxPDocKHHg==", "FSEZKsO5N8OI", "IjdAwrkBwrfDig==", "w78Nw5nCuQ==", "w7/DvH7CqT3CsxNpwolnTg==", "QT7DncKTEiE+w4DDthTCpsKj", "HDHCoxPDhMOi", "woRKwrcYw78=", "wqs1wqnDvsOwfMORKg==", "UcK/ElDCnMOgwqo=", "V8OKw6HCjw==", "w6YMw4PClw==", "ZMKlw5VCeysg", "w6TDkMK5QMOO", "eRZVBMK7", "Qj7CvmDChA==", "w5jCqcKwwpvCsQ==", "NzYbMMOlI8KTw7HCiQ==", "csKPwqPCkQkARcOPC1zCmhpRPA/ClcKEwpk=", "wovDi8OJcCnDuw==", "E0lCwpfDmS4=", "dMKawqsiw5fChsO4", "OkXDo8Kew75yUnQ0w7NPLmrChsOl", "wrbCnA3CmxbDjMOD", "KjcuLMO/IsKbw6bClg==", "w6XCq8KhwrDCpg==", "PiPCtA==", "w7APw5/ComY=", "SsOAw6HCv8Kxw7/CnR3DncKzViA=", "w6ULMCo1dAob", "XsOWw6o=", "w6zDkMOzXwDCjQ==", "RMK9wqTCkTw=", "CETCqT/DnMKOw4XCvznDicKM", "w57CtMKlwpTCmMKRw4fCk8OU", "wr9AwrAJw7zCtcKu", "w7nCj1RHZw==", "wp/DjcOcVSLDkA==", "PDLCpS4QLjx8w6Qxw4jCrS0=", "JDfCtCEm", "NyTCtAzDpMODw5vCvsO1wpTDuw==", "w67Ch05iWsKCwrNs", "AyDCpQrDosOUwpo=", "w7VCw7MP", "w63Dsn/Cgg==", "w4zDn8K2wqk=", "fsKIwpAuw4HCgg==", "w7PCh1luQg==", "wqFXw7PCuUhbwph6LcORw6LDuhUN", "FiTCqxvDv8OH", "w7XDnsKgRMOkWg==", "U8Kjw4JfYjw=", "wrYtOX/DjMOJw6FtwpA=", "w7zDksO/VhfCtg==", "wqQmbMOuwodBLcO3", "w7zDn8O9XQA=", "wo/DrnTCmsKIw5xSYHQ=", "wopEwr4Yw6HCpg==", "HlfCuiPDhsKNw5jCmS0=", "wrnDp0jCuDE=", "wrvDtDvDpQ==", "Ch4O", "wr3DrlPClTwdO8OVK8KZMMODShs=", "wp3CksOZAg==", "TzDDjMKAFxQjw7fDuhDCu8KkGw==", "wqvClQDCjQ3DhsORaA==", "dcK/H0DClsOgw4jDu8OkFX4=", "wqLChgc+wrbCs8K8w5In", "wp7DnsKJGA==", "DUjDrsKuw794TVMZw6ZtJmPChg==", "w5DClcKPwpnCqQ==", "ICFywqU=", "wrclcMOpwpY=", "wr8se8OywrBELcO3wrM=", "wqrCmxfCiRPDv8Ofd8KDw4jDp8OkFQ==", "w6d9wr5SwqTCiT4=", "WcKlw5JD", "wro+wr7DlMOsfMOSIA==", "esKOwpQHw7o=", "YMK/BW3CncOh", "HQsDw6Iyw6c=", "wqvCmxDCjRM=", "wpLDnsKZLhHDnsOnw4bDkcKnwpIaw6HCoQ==", "NCbCshfDu8OD", "ZsKPwqPChQ4bRcOPBUrCpwhFCg==", "TMKDwqLCghc=", "IicON8OgIA==", "Q8O/w61SaQ==", "asOjw6pFWQ==", "w7QCw4LCv30cEcONw7LDlcKs", "w6bDt8KCwrjDvw==", "UAh5H8K/", "wpTClsOPBcK7XW7DtsO0wpfDvQ==", "TcKmwrkcw5A=", "w6zCsis2wrU=", "woEBacOSwqE=", "w7JQHygO", "HAUfw7Yyw6VmPsOrwpDCqw==", "aDM+w5khwojCjkI=", "w4jCp8K2wojCgsKSw5rCtcOALcOi", "w7kTw5XCo0sNBsO0w7vDosKowr7CtA==", "w6cEET8jfB8S", "TxzDt8KKLg==", "w7VEAiINPsKOHlJJNQ==", "M3nDrsKPw7A=", "wqjDrkTCuSIRJQ==", "w5x3wrlDwqc=", "w7JLETIIPsKY", "GELDrsKMw6N4TlkYw75OInzCgg==", "w77DvGHCvibCtw==", "TC0+w5k3w57DkQNj", "w6NXET4XPcKTOEY=", "w4vChDkVwovCt8Ocwpc=", "w7REHTUWOg==", "w4/CmSsSwozCuMOcwovDnQ==", "w4N3wqlHwr/CkmLCncOEwpbDvxZh", "w6IRw5HCo2cfDMOrw6Y=", "YcOhIy9GAsK4HFt1w7x2Dw==", "wrUqa8OuwoVN", "wpXClsOQEsKgWQ==", "wojDh8ObdTjDijM9", "wpbDmsKACAvDlg==", "wrJAw6bClFNUwptsAg==", "ScKewpguw50=", "wrcocsOiwoFJEsO2wqU=", "RMOEw7/CssKRw7vCoxbDiw==", "A0tOwp7DjhY=", "wr3CkQIlwobCucK8w44v", "QD7CuWjCqcOpYkE=", "ScKLwrnCogoXWw==", "Wy06w5Yww50=", "w5/DnMKgwpLDvQ==", "Wz4yw5I2w5nDrB56", "wqXClRnCjQ3DjsOia8Ke", "fsKIwpAuw4HCgsOFPnw=", "wo7ClRrCjBPDisOC", "w4VqwrxIwrjCnWLCgcOs", "QMKvw4JXYDB8w5U8M1UIJg==", "w7R5wq5D", "wrczwrTDssOlZ8OwK1zChw==", "eDDCpGXCscOlfw==", "wrjDuHzCmsKU", "w755U8KLw4U=", "wp47wqnDsg==", "NinCqRDDqA==", "w7dCw7Q2WnFkwrzDp8OWw6LDmQA=", "wrPDvTDDvgI=", "wqLCgMOYEsK8", "wqxEwqAY", "wox+w41Uw5NDw6PDkMKTwoE=", "w5/DgsKgwpLDuyo=", "FzMfO8O4", "bCg6w5Iq", "wrcocsOiwoFJ", "ChYMw6oow6Z7GMO/", "YsOEw6HCsg==", "woVMwr0Yw7LCtcOTw4gZw48=", "AyV4wrQJwrfDlw==", "dyjDisKEFQ==", "w7zDn8O3Uhc=", "MCPCrSU9Ow==", "wrg7wrfDssO2dA==", "Xh5BOsKPwqcyUAs=", "OytlwrkRwrvDihw=", "wqrCgg4uwofCvg==", "wqNICD9HRW56SA==", "J8O6b8OyG2c=", "ZS9mBcKT", "wpPDjcOMaQ/DjzM9w7I=", "wrfDrlTCvgYROcOVDMKSG8OQ", "w7nDqF/Dv8OZw5nCvmY=", "fMKFwp8uw5fCjMODNHAtBMOQw7o=", "wpLDnsKZORzDj8O/w5fDocK7", "a8Opw5zCscKG", "FwwwYyQd", "DQErfg==", "Q0xBw47DnUfDsg==", "IigKNsO3", "HkDCozk=", "QsKvw4U=", "RMKLwqTCow==", "BkTDtMKIw7Zjb1g1w7o=", "c8KzHEHCgQ==", "d8K4w59C", "JDN4wrUX", "w6bDrEbDtcOdw5XCjG99wrE=", "FAAtZg==", "w55vwrNDwrk=", "EQopw60ow6F2BsO3", "wprDjMKDCAs=", "w5hrW8KBw51OwqrDigPDqw==", "Q8OhOCI=", "wofDnsKOAg/DksO5", "wpvDqUHCisKw", "wro7On/DjA==", "VMK/BXDCmsOiw6o=", "SUvDvMKLw7F3Rw==", "LhYIw6I6w6I=", "AFbCtCM=", "wqHCkQDCuhrDnA==", "LiAzRjs=", "w7rCqcKrwpY=", "NCfCtAk7PzRTw601w5vCpSkKFTplRQ==", "UTXCrkLCtcOpYUs=", "wqHCkQDCqxDDgsOAa8KEw5nDoMO/", "wql5w4pF", "w4fDqlnDs8Obw4Q=", "wqbCgQk=", "wqVTw6rCn1JT", "UTDDm8KADy0jw6rDkAXCv8KuB8Or", "MSsOP8OiLMKTw63Cq1Es", "w5hrwpxTwr/ClE7CnMOzwpHDthBn", "w75WJCUWNcKuL11cInsk", "NiTCqxvDv8OHw6bCjMOqwrw=", "wqVTw6rCn1JTwrt4CcOx", "A1bCmCXDlMKFw5DCjg==", "w5hrwptUwqTClXk=", "L8OqTsOrCWPDtMKg", "KcO3WsOsDGnDpQ==", "fxxENcKIwqQ=", "WTwrw54yw50=", "L8O3csOvLnbDssKp", "EQYH", "w4xhWsKCw4RcwrbDjQU=", "wrnDogvDpRUtKXlGwo7DucOiw68=", "WsOEw59SShgnGMOfOiATCQ==", "wpnCmcO7BcK9Vmg=", "LRwEeDsHNA==", "wrXDpWXCtzcf", "Kjc8LMO5K8KI", "wpxVwrccw6fCosONw4gEw4PCjC5WZA==", "w7HCilc=", "wpDCmMORG8K9T1PDgMOn", "e8KGwpEnw5zClMOYM2I=", "GkrCqCTDgcKCw5jChQ==", "w4nDlsOxRwrCpcOD", "TD3DhQ==", "MysJN8OiLMKTw60=", "JCZ8", "w4jDgsKkwp3DvCnCvE4A", "Hl/Du8KDw6R3TkU2", "w4F3wq5Pwr/CkmLCnQ==", "wo/DrnTCmsKIw5xGYGxmBig=", "Vj7Cpm3CssO3Qk0C", "OifCrA==", "RCPCq2/CrsOmYl0F", "wpB4w5BYw4ZYw4LDkQ==", "wpnDnsKfHQ==", "wrzDtC3DoA==", "KcO7cQ==", "w6/DnMOhWhHCvsKfw40=", "w4bCo8K2woo=", "Z8O8NiBBDcK4AHM=", "Fxcuw6w6w65zDw==", "w53ChCYQwpDCqcO8wpvDmg==", "wozDmsOJcj/DhTMhw7o=", "wox4w4BQw55hw4LDjMKUwpAqw6DCjjg=", "Jw4vbyYIDwHDsMO/", "YcK1HUjCnMOlw5bDrMOr", "OSrCpR/DocO2w4bCmcOlwpDDt0BR", "woIsfMOzwpxacQ==", "wo/DrnTCmsKIw5xPaWZS", "w7REHTUWOsKzLE1g", "w5J5wrBDwrnCmkLClcOnwrk=", "SDM+w44Hw5nDkxR8QTrCo8Oo", "w7/DjMKYUcOyWlXCtw==", "wox4w4Q=", "VzfDhsKSVSIjw6jDvwvCpcKEF8OgcSJUw79iw6VRw4vDi8K0wpo=", "c8KoEErCgMO0w7bDvMOs", "X8OYw71GUiULA8OMPCwfE05dw6XDqWIL", "c8OSw7fCssKN", "MyrCqhLDosORw6bCiMOm", "DErCtyHDmsKcw7jCiSo=", "R8OFw79JTRELBcOA", "Py3CoyEjCDZlw7UCw4DCryY7BRB1WcKL", "XsKpw5hTdStdw5QXIw==", "wqTDrnfCm8KWw5hy", "wrnDuULCtyAR", "w7LDs3zCtzXCryJcwp1yWcORIRHChWpLOw==", "woZLwqMRw7LCvsOew4Yaw4/CiiZ4ZEPDisK6w78=", "KwEyZjUQAwbDu8ODwrrCjWrDrMO3wqjDnMOjMMOywqVsCsKYFSNDwozDosKcZT05HcKlKMKmwoQsw7hNw5hsw6o=", "w5d3wrFKwqTCjELCkcOr", "w6vDgcOzXRbCscKfw5EC", "wqrCmxfCiRPDvcOfcMKLw4jDp8OkFQHDvATCrsO6wp4=", "wrPDuT7DvgAmL31CwozDrsOl", "ZMKyEErClMO3w43Dr8OzB35tw7gt", "wqDCkCAjwpTCscK0w5kWw4TDuMKFw4zCjg==", "w5LCmB8MwpvCv8OHwpw=", "woMpN27DkcOawoI=", "FSEZKsO5N8OP", "w7DDkcO4", "dcKYwrbCqBUURsOZKg==", "w5zCjj46wpDCrMOEwpjDglI=", "f8OhMA==", "RDrDm8KnFDY7w6XDoQDDqA==", "w6UWw5LCuWYYAMOt", "wq8owrvDucO3c8ORNl8=", "BSfCozQgKGo=", "wrsjJnfDn8OEw5h4woY=", "fcOhJSNTB8K+CHs=", "wq7ChhckwpPCucKVw5Mww5LDq8KQw43DgA==", "ZcOSw71TUQVW", "w5jDn8Kx", "PEDCuDnDmsKZwoU=", "ScOTw4pNSA==", "wobDmMKMARjDhcOHw4fDvcK5wqgT", "wobDtDzDpAgxSQ==", "w7zCo8Knwo7ChMKFwpo=", "wqDDj8KEAQo=", "HkrCmiPDksKHw5I=", "HwcCw7c=", "woF1w5A=", "wr3DmMK7OQo=", "ZsK4Ag==", "Iy7CoTkMOzR0w6YXw6jCriE=", "woEKTMOPwpU=", "UsOVw7bCtsKXw7/CsBjDlcKkQTM=", "IjdDwqABwrPDkRc=", "w7LDv2Y=", "FFhCwpXDjxHCrQFT", "w5hhQsKPw59CwpbDgSrDuA/CljQ=", "TsOWw5TCpcKMw7TChw==", "w7JOGDsN", "wrw/b8O+woQ=", "wqpdw6TCm0xgwptqDsOcw4XDtBYtw71lesKHFA==", "KzIKJ8Oh", "RTDDg8KNFDMDw6bDuQ==", "w7HDsm/CujjChA5JwpFjQsOfDjrCmUNALQk=", "w5vDnsK5ScODT0jCvg==", "w7jCh1FnQcKcwpNgwoo=", "S8OKw7HCtsKPw4jCnA3DmcK1Wj0rwoQIw7VQEMKp", "w4nDgMKhwpLDuyrCh10fw4lIwpFdfCbDrwzDrw==", "KAAhazg7LxPDt8OSwqHCg0XDh8OrwoHDl8O1SQ==", "w6rCmlxlXcKNwrNwwo0=", "BkrCuCzDmcK5w5jCnyHDjcKAS8KzNHHCmz3DusKo", "wqTDoz7DvhQlFG5d", "w7PDnMOxUgnChcKfw5cOw452KQhFWBMLcyQ=", "wpBQIjBg", "EgsOw6U3w5J7HsOzwpTCpwjDtsKKw6zDocO2w6/DuQ==", "wppbHTlhV2hk", "wrx+Jx1T", "NCfCtQ==", "wqXCjcOIJ8KV", "w7FKHDwLLMKzKEE=", "wpjDvXjCkcKJw5tvfW0=", "XsKlw4RG", "w750dcKYw6g=", "wrpVHzR3QmxtV8O0", "w7PDrkLDlsOi", "w7LDpkfDtsOEw4fCkGh7", "JSsWMsO5MsKzw6HCjg==", "wpnDlMKK", "wrTDusORVQY=", "U8OXw7PCucKQw7zCnAvDlQ==", "a8K1EkXCn8OAw7bDusOgFHJ2w4UYQ3RNEAw=", "aMKZwoPCsxQce8OOMVbCmxpN", "FhIdw70s", "BhvCqyEu", "wr/DszU=", "w6nDr23CtSfCsA5Pwp0=", "FgwEw6wV", "RsK/wrnCjCk=", "woTDp3DCl8K0", "w71UwpNAwq4=", "wr1SwrYYw70=", "wpvDhMONfT4=", "woTDpjrDtQk=", "w5bCiVNvQsKOwq4=", "woLChcOcGcKhXnPDkMOg", "wrFVBT1bVE5qTw==", "S8KMwp4/w5zCkcKk", "wq12wr0Ew6Y=", "wrbDoz7DvQIFF31X", "VcOYw7JLUQArFcOH", "w63DnMOmUhHCsg==", "w7jCmlxmS8KtwrBjwoc=", "Z8KGwrjCqRQ=", "wqBDwqQRw7I=", "JxogYzcgLijDo8OS", "w6JvWMKKw4dOwos=", "w6fDvUTDqsOow5HCsm9jwrZ2w5HCrFU=", "U8KtFEHCnQ==", "MC7CpSE9", "w6ZMw60yXHk=", "wrRdw7PCm1RbwptwLMOJw4HDvgoJ", "QcOYw6pGSh4LGcOuKSgVD2o=", "csOtIydEDg==", "JQw2YyIM", "wpR2w5FWw5dF", "BUvCiDnDlMKfw5LCri7DjcKMVg==", "wprDlcK+GRjDg8Ouw7fDo8K6wr0Pw6k=", "w4XCqMKXwo7CisKDw43CpMOBNMOz", "w6ICw4LCqnEN", "QD3Cq3jCk8OldVspw6lt", "w4xJw6wy", "w63CnFxlSg==", "PUzDtsKG", "wofCnQHCoic=", "aBcc", "wpfDtTvDhRU=", "w5LDq8KMbsO5", "woYvJnPDjsOcwoJG", "Nx8nbzA=", "w5XDg8KWwofDoD8=", "wpB4w41Yw4Zww5/DjQ==", "UzPDjsKYHjYNw7bDoQ==", "CVDCqR3DmcKKw47CjjI=", "GxswazoaLAbDosOD", "QwJJIA==", "w5ceNi40", "TCjDgcKECQ==", "w558V8KAw5hNwpbDnQI=", "aMKtH0HCgQ==", "w5Z9wqllwqPCkmHCl8ODwprDnRJ+wrU=", "wobCm8OcDsK3Siw=", "wojDncObdA==", "YMKJwqPCrxAX", "w5PDh8KrwpbDvQ==", "d8K7A0HCncOm", "w7nDqFs=", "wp5UGiU=", "YMK7HEHCsMOmw6vDosOt", "w75WIyQLKw==", "w4J9wqllwr7CiV3Cn8OgwprDtgE=", "w5/Dm8KhRA==", "w4jCjj4/worCrMOjwpXDkU8Mw7Q=", "RMOQw6DCh8KPw7vCihzDig==", "wpfDlMKJFDXDksO9w4fDvw==", "w5jCnjgswpPCv8OKwpzDgg==", "UcK1w4RmeDhqw54L", "w5HDmsK5YsO5VlHCvcK9wqhkw54=", "wpvDpU7CuzUAOMOD", "w7XDisK/ccO6WljCt8Kh", "JCEOH8O4LMKRw6LCkFw0LsK1wqTCng0=", "w6/Cp8Kw", "bcKjw4NEQCtyw5UK", "w7LCh15qQsK7wrNxwokkwrEmFg==", "w7xrVcKaw4RZw4o=", "w7XCpcKxwojCv8KFw4nCj8OK", "RgNDNcKQwpMyVgfClRfDiG1MwrXDmRHCqg==", "Nk9Awo/DkwXDsQ==", "w4LDvnnCqQDCpABTwoM=", "NcO8b8OMAnDDrMKhM8O9ch/Ds3k/w6gZw6g=", "w4DDmsKuVcO5SRI=", "wpnDmsKeGTvDmMOvw5s=", "wpXCgsOPJ8K+WWXDh8O/", "wrktJ27DvMOHw5V7", "woDDrmrCi8K4w5Jkdg==", "woHDicKMAwrDkcOkw5DDvg==", "XsKhw4VCVjZ3w4I=", "w7zDhsOgYwnCtsKJw4Yd", "w4l7RMK+w4dKwoDDih0=", "wojDh8OGdTjDoi4h", "SDAxw54ww7nDjAM=", "woXDlMKEAw0=", "w6ZYw7IHQnlywrfDkA==", "woZLwoAJw7LCtcOpw6AWw4fCnQ==", "w65swq9HwqXCiGHCksO1woY=", "w6zDg8O3VgE=", "w7DDncOhRwrCp8K9w4wZw58=", "w4nDi8K/QMO4SE3Cs8Knwqg=", "NVnDqMKMw7liTVYvw7o=", "c8KPwqTCoxI=", "wqRdw6PCg2xXwoJ7Aw==", "w7sPMAwybzsbwrBfMnA=", "wqs2wrvDrsOFe8OX", "WsOEw41TUQc=", "Gww3eBUHKQ==", "CV/DtcKew6RXQFM+", "MDfCshM7Oy10", "JSnCpwfDg8ODw5HCnsONworDtw==", "w4PDqEfDsQ==", "YsKIw7U=", "w7DDu0TDqsO7w7jCnA==", "wqrClhEYwoHCvsKnw5k=", "fz4xw5A=", "w7vDgcO9QyLCtsKew4Y=", "w7zDt8KpcsO1", "wo9gw41Uw4A=", "wrc7wqPDssO2", "w7BCGRwt", "w5jDnsKKwqLDvg==", "w7HDksO/Vg==", "wo52w45U", "wpwiJ24=", "w5zCiicZwrzCqsOBwpXDnA==", "Nwo2Yj0dBQHDsMODwqvCmA==", "woVkw6d4w58=", "w4bDlMKcwrjDjA==", "EAUAw6E=", "cTEsw4M=", "JCUXO8OVMcKOw6/CiA==", "GUDCryXDnMKfw7LCjSbDnMKKUA==", "MMKqT8O0OzA=", "w7LDqmLCviY=", "w6dKAzkQMsKTJA==", "ccOhMzd+DsKhF3I=", "w7VKFCkoPsKKL0c=", "BiUO", "w5B7wqlPwr3Cng==", "wohZHCNgUWBmVg==", "wrPClsOOEg==", "wrklOn/Dn8Oaw79two3DlQ==", "W8OvOSpeDsKl", "VMOAw6bClMKWw6jCoxXDmcK4ViA=", "Q8Obw79efxkN", "w5HDqF8=", "egRiMMKQ", "w4oYKywkcgce", "w595wrBD", "w5fDvEjDr8OGw5LCunhOw6cI", "w5TDs3/Crw==", "esKIwpAuw7DCl8OlPWQ=", "dMK/BUzCmsOmw5zDqMOnBXht", "XcOzw5d9Vg==", "wqbClA0uwoc=", "AiplwqQ=", "QMOEw7/CssKgw67CgRXDlA==", "wqEJPT5iEQ==", "fMO5OStA", "f8KGwpkyw7/ChsOhNGQ=", "WjA7w44Iw53DiBRi", "wprDh8OMZQDDhio2w7s=", "NAMjcxUHKQ==", "dsOWw6o=", "w6paw64yXA==", "XMOAw7BCTA==", "wqfDi8OdbhjDkT09w6Q=", "fT4sw5I=", "T8K7H0DCn8O3w6s=", "OCFiwpMQwqDDtR4sO8ORIw==", "Oyh3wqkkwrzDjA==", "wpEoaw==", "w67ChFxyb8KFwrU=", "w7rCjsKH", "TQlUHcKSwrI=", "ZsKPwqPCiwkWTMOHBF/ChgdNLRXCusKJwpF1", "w4V5WMKLw5k=", "w6YLw5PCnXsXCsOt", "w7/CjFlIRsKCwrBm", "wrLChhXChgzDicOfdsKH", "woVKwrAcw7/Cl8Oyw5Qew57CkShX", "GcO6bsOpOXDDocKrDA==", "wpMoccOg", "wpzDoHfClsKOw7xyfQ==", "woxyw41Ww4ZZ", "TQlUGcKTwqU4TiXCjRHDiWZLwrnDuxXCtcKX", "BVrDtMKIw6U=", "w5rCjy4/wpfCt8Ofwp0=", "wrhNBzRG", "wrHDsivDuREm", "wovDqm3CvMKIw5xzZw==", "w6LDjcKsT8OlXU7CoMK+", "wplKwqAUw6fCrsOyw4k=", "aTDDnMKCDg==", "ecOYw61ESw==", "wpXDsCzDtQ==", "bcKDwrnCowcAZ8OEKVY=", "w5zDqEXDvsOHw5XCrQ==", "wqVAw6LCm1RX", "wqdRw7PCk1ZX", "OivCkw7DqcOHw53Cjw==", "wrIpwonDo8OrZQ==", "woQuwqjDtsO3", "RsKyw5dYZzVyw48c", "eMORw6DCtsKNw6nCnxjDjMKk", "di/Di8KADyE=", "PMO9T8OxGw==", "wrLDh8Obfzk=", "D8O3aMOv", "bsKcwp4ow5bCkMOkAWcq", "wqfDnMOafT8=", "w7nCiVBubcKfwq5uwow=", "woREwqM5w7rCtA==", "w53Dp1jDrg==", "woXDmAvDqRcm", "YMK7HEHCpsOb", "VcKhw5tTRCt8w54KNQ==", "CAUBw7E+", "woxdw7TCmVU=", "WsOgJDo=", "w61rQsK7w6I=", "w68LKSoSVA==", "w5bCiiQ=", "LAcrYho=", "wqXCgQbCuwvDjsOEYQ==", "ZcKYwrjCtjY6ag==", "ccOCw4XCgMKr", "dMOvOit9HcKyAA==", "wr9jw5FQw4E=", "w6YMw4PCpGAQDMO3", "RcOrNDpdGcOk", "w6TCnzgdwow=", "KAAhazg5LxTDv8OSwqHCg0U=", "ccOAw7HCo8KMw6jDgA==", "wo5Awqc0w73CtA==", "wql5w5BF", "JiDCsj3DrMOLw4zCmMOt", "w6bDpl/Du8Ofw5XCj2Zwwq5ew4w=", "wp0nbMOz", "wo5Ewr4Yw5DCs8Ovw4sb", "bcKFwpwyw7LCjcO+", "OgUDw6c+", "w4nChD4dwovCu8OjwpXDkU8Mw7Q=", "w5/DhcK3wqPDoy7Cqlkf", "dsOWw61C", "cD4xw5Mow53DjA==", "wrPDozrDsRMm", "LCV7wrUqwqTDgAA=", "wrnDpEnCsD0T", "w7rDvGHCvhvCoARP", "B0tOwp7DswHCpwE=", "XMOZw61TUQcpGMObLQ==", "NXcuMcOAdw==", "w4jCjV5/QcKZw6g=", "w5zCr8Khwo3Cm8KYw5rClQ==", "w4FqwrJMwq7CmHnCmsOuwo3DhRp2wqfDh3rCqTp6WQ==", "bjo8w4Mrw4rCjA==", "wpLChcOSB8KCcF8=", "NUbCrj/DocKZw5bChTM=", "w4zDnMKkworDjiHCug==", "w71vWsKF", "wpHClsOQEsKBW3nDjMOo", "wohGwqcUw6XCog==", "w7DDu0TDqsOsw5HCsW8=", "woXDl8KMFDjDmcOi", "UcKxw7F+Yg==", "DgsDw60vw4FmGA==", "w5rCqcKqwpPCn8K2w5rCkw==", "LCFiwpMNwrvDiRYMNg==", "w7fDnMK5SMOgXg==", "w4dfw68gXX15", "wrFbw6nCnk9F", "ACHCsik/Lg==", "IktRwonDlRLCsDJMwqM=", "w6XDj8KoRMOy", "bsKpPEvChsOhw7zDisOuF3U=", "w5NIw6MjQWo5", "VT4vw7Mtw4s=", "w6EZFzsmbx8=", "OivChwnDrMONw4w=", "F3HDsD/Cv8Ok", "cxkmw6UD", "wq9cw67Cjg==", "wox4w4JVw79Qw53DvMKSwoolw6bChw==", "fD4rw5Y=", "BkjDrMKIw7s=", "Zz7Dm8KA", "w6QPMior", "w5DDlcKzwpbDow==", "XD7Cq2XCisO4XloK", "w73Dp0LDrsO7w5zCvnN0wqU=", "w6xDw6kj", "RAlXB8KfwqQzRw==", "w7DDhMO8Vhc=", "AU5HwrjDlB7Crhc=", "w7ZBFBMMMsKQLg==", "wrTDrlDChTcROcOU", "wrQhNnPDm8OGw4VPwozDlMOK", "wpnDhcOKdSnDjSgQw7hdMMKC", "w7zCo8Knwo7ChMKFwps=", "AsOwacO+DnbDqcKqEcOeaAvDol4=", "CUrCtyLDhw==", "fAlDIMKTwrNu", "wpElJn/DncOcw5htwo3DvMOGFcKcdA==", "WsOZw6pCUAQNA8OU", "UsOTw7pkVh4IEw==", "Q8KzA0HCkMOmw7DDocOvLHJ+w4Mp", "LkzCqSjDlsKfw57ChC7DtcKAQ8K1BQ==", "w77DsmDCtCY=", "V8KPwrTCsgkAGg==", "woLCnQbCjRzDm8OZa8KEw7DDp8OsEzA=", "w6xDw7QyQGtiwqbDmw==", "w67Cr8K2wp/CiMKDw4HCjsOXEcOuMCtC", "dDjCuGTCvsO0ZEAGw4ttw40lw7Y=", "wqRSCDVbVEVhVsOhPipfwq0=", "w5nDtH7CvjfCoghSwp5bQsOXCAs=", "WTs7w7Qsw5HDkhU=", "wr/Dv2vClsKOw5gzSw==", "w6ZMw60yXHlZwr3DjcOX", "wpJ4w5dQw4ZYw4LDkcK4wpEvw6rCkg==", "wozDrkTCojsGZA==", "BiV/wr4mwrPDiBc/Iw==", "f8Khw59YVzh+w54LJw==", "w5REHTUWOg==", "ZMK7HEHCgcOzw4vDocOuFA==", "wrZeDRJcSm1s", "fTDCo2/CnsOhYEoaw6Y=", "woTCggolwrbCvsK+w5kww4Q=", "w7x5wrRIwojCmmDClsOzwoI=", "wqA7fsOpwoBOLcOrwrs=", "wrXDicOBcg/DgjE2w6VQ", "UMObw7tGTDEIFsOK", "wr/DoHXClsKew75vY294", "wpY7wrPDucOHdMOTIUDCgw==", "wrnDp0LCtyY3OMOdBsKS", "Bm/DjcKDw4Y=", "wrHDv0LChRo=", "HiPCqS4MOzR0w6YX", "w4/CqMKlwpjCh8KSw6DCpcOr", "RjHDjsKDFyEKw6vDtA==", "w7vDsmvCmDvCug5P", "wobDtDzDpAgxSA==", "wotjw4Ziw7w=", "w4xhUcK9w59KwovDmw==", "w6/Dn8OzSgDCpcKjw5M=", "wrU/wq3DhMOncMOQIQ==", "KiBywpMNwrvDiRY=", "Xzorw74qw4s=", "w41rQsKjw4RPwpzDgyzDoQzCnSPDqsOXwqU9wqBE", "w7gGJTYibw==", "w6dJESkBKcKvOg==", "wpRlw4Jfw4FXw4LDjcKQ", "WgBBLcKZwrMOUg==", "Q8Obw79eWwU3Bw==", "w5jCqcKwwpvCn8Kew4fCj8O8KMOrMjE=", "w47Dn8KxwpLDuybCvFIow5tBwoBs", "w7bDncO7RybCo8KCw48=", "wo/DrnTCmsKIw5xSYG9+", "MB0jZCcPLxXDuw==", "d8K1Ak3Ch8O7w7bDoA==", "wrPDsDLDtRUiKXNfwp8=", "w6TDpljDs8Ofw5nCsGQ=", "w5piV8KXw6hfwovDgw==", "w7/CjFlIQcKGwqxtwo41wrY9", "w73Dp0LDrsOuw5bCuW9ywqM=", "w6QFJSsUaAkHwrBFPGPDgiU=", "ZRhIMcKOw7UQEA==", "OizCqTQfNjhow7EE", "w7/DkcKkVcOGV0DCq8K2wr8=", "w6QFJSsibw==", "Jx0nayAM", "bCvDh8KECXABwrbCvCjCs8KyFMOZPDNIw7tTw5RYw4DDgMO2w6PDnB3Ds0TCm3ElAsK4w6VDLCXDm8K2w5xDwosaIyNaw6s=", "fcK0w55TZm1ewolWClgUNcKcIcOiKsOCwrF1dMKVwqLDv8KxwocfClvDpxHCgMOdw5o2wrnDl8KKw655DRcDfsOiw6YDwr0=", "w61AICoO", "w4ALKisreBk=", "wrtVCDVRUQ==", "wpHCksOJJcK3Sw==", "w6kJMCYxeA==", "w6YPw5HCtFcNEcO1", "WT/Co3U=", "w4ZhV8KKw6ZKwonDrADDowXCmiE=", "BwhYwrYA", "w4ZowpItwrw=", "wrgJw4PCono=", "MyU9wqs=", "w7HDsm3CvzHCpA==", "UcKyw5NXYDw=", "wpXChcOYFsKmXQ==", "w5PCh1luQsKlwr1vwoU=", "QMOUw7tJWzoFBw==", "MibCpAMnMzV1", "OizCqTQ=", "QjvDi8KiFCk8w6vDvQHCvMK/", "woLDjsKZDBA=", "e8KAwpMiw4DCi8OYM2I=", "w7piV8KAw44bw4nCng==", "EktNwp/Dkxo=", "OknCuiPDkMObwofDmg==", "wo/Dvl7Ct8KM", "wpnCjwIlwpDDr8Ojwo8=", "ZsKPwqPCjwgB", "wp/DjcOcUSPDhzk/w5RdMMKewr9Uwpp2w77CsMKt", "w7cHw5TCjnwQD8O9", "wrIpIFnDkcOFw4Ftwo3DlcOBBg==", "wro+wr7DlMOreMOOK1zChzJn", "w7/DkcKkVQ==", "wr3CksOEJ8K9UXLDlsOJwobDrFc=", "UcKhw5tTZjhBw5QWMg==", "w7wYJSE0ewQFwrw=", "wqdVGjhASm5m", "wqPDnsKOGRbDhcK4", "TMK/CHTCnMO7w7fDusOFAW94", "w4F3wq5/", "w6rDlcKmwofDoD3DoA==", "wo3CkQ3CuBDDhsOecMKuw53DusOq", "wplKwqAl", "HiDCvy7DosOPw4fCnsOIwoXDqk4=", "WMOrLh5dAsK5Blphw6Ry", "wrbCmwfCsg==", "Rw1QEMKVwrI=", "V8KGwo4ow4Y=", "Q8OYw619", "w6HCo8K9wqrChMKew4bClcO9PMOzNg==", "Y8OhJBQ=", "QyTCqWLCuMOzfn8Hw7Q=", "D2BtwoPDng==", "w6bDk8KsWMOzSXLCog==", "Y8OiNjdXGcKEAg==", "YMOtMiBXCcKw", "w5vDlcKxwrrDoTw=", "wpLDnsKZIBbDk8Ouw47DkMKywrMVw6nChh12wog8woc=", "wobDvynDkzE=", "QD3Cq3jCuMOyXl8=", "JQsmSTwALAM=", "WDjCvkTCu8OmaEwc", "wrgmfMOmwp94LcOqwr/CmTnCuMKa", "w7zDoF/Dn8ONw5bCumll", "AkTDrsKow7F3RFQvw49CNXo=", "w5lxwqljwq3CnWjCkMO1", "OSzCvBc=", "wrZTw7XCjklRwph7PMORw5/Drx0F", "w7jDu2rCvjfCoiJcwplTSsOZ", "ZcOiw5nCssKz", "w67DvmnCtTHCmwBN", "wrEvecOiwpBcAcO4wr/CqTHCvg==", "JiIcO8O1McK/w6LCjXcnFA==", "w7XDql/Ds8Odw5U=", "w7sPMAwmcA4FwrA=", "w68PMAwocBsYwr9DOXY=", "w6QMw4TCrGAQDMO3w4jDhMKkwrbCo8Om", "Zw1JOsK/wqAwRxTCgA==", "wppAwqc+w7LCrsOZw4Ye", "wqYpIFnDn8OBw7Vjwoo=", "woxDwrUYw7DCs8Oew4Yew67CmS4=", "w4ttQsKHw51O", "NiTCpiUsLhpww70yw4jCqQ==", "ZjTCqXXCssOyPg==", "RTbDgcKICCwDw6bDuQ==", "JzDCoS48PDZjw7k=", "wrnCjBAiwoHCtsK8w5I=", "aRx0E8KO", "DQEZw6wyw7RRDMO0woXCrRM=", "wrQvIHPDiMON", "wr0lIF/DmMOOw5Rhwpc=", "dcKAwokOw5XChcOyMnwJEMOQw6s=", "wrnCjwIy", "wpvDh8OEcz7Doi4h", "w6UXw5HCv2A6DMO1w6TDl8KKwrzCv8O0ZCxFMQ==", "FENOwp7Djg==", "w79MBBUCPcKZKV9pMXo1", "TDHDusKRHyU4w6E=", "VMOSw6puUAQ=", "JcO2dcO9BGU=", "VTbDi8KEFAYtw7bDoQ3Ct8K5", "PS1ywrUKwpDDhAA/K8ORIw==", "wrZdw7TCk1Rbwptw", "ZcOnMytdIsK0HXA=", "w5fCjkpnTw==", "w53Dr1zDtsOK", "wqnDv0bCsTE=", "w77DmsKkRsO+Tw==", "MgYmbzsgIwjDuA==", "PS1ywrUKwpvDhh0j", "QzLCq23CuMOZ", "woxnw4Vww6c=", "JgvCrhM2", "IDbCoScq", "acKPwr7CoQ4G", "JSvCsyktNjw=", "w6nDmsO2VgrClcKRw5Edw5N6NA==", "w6U1Nzsmbx8wwrBLMg==", "w75WIyQFKcKI", "GEjDvcKEw6RlREUew6lGKXo=", "wqQlfsO+wrBcMMO1", "w6pDw5MjT2p/wpXDg8OOw6s=", "RMOEw7zCtMKGw7bCtg/DncKvRw==", "woBWwoAJw7LCtcOp", "wqDDvT7DqSQ3CXA=", "OivCtQrDosOWw6TChcO6woE=", "wqYsbMOiwoc=", "NS0eO8O5DMKfw6zCig==", "w5fCjiQbwovCtg==", "wr/CigcuwprClsKww5Ms", "wrc/wrTDsMOwfQ==", "ej4tw4Utw53DjDB8WQ==", "wqHDvsOpeR0=", "Iwo2STwALAPDl8OS", "ZsKPwqPChQkfWcOEKVbChx0=", "wqPDsjrDvgIOGmw=", "wrw/wq7DlMOreMOOK1zChzJn", "wqk/wrnDuMOycMOM", "MiDCsjfDo8OV", "w6QGw5PComIcEcOUw6TDgcKswr8=", "wrrCgAYlwpDCksKyw4w=", "wr3DrlPClTwdO8OVKMKU", "wrTCkRnChwnDisOzbMKDw5DDqsO5Hio=", "wqhHw6rCuUhbwph6HcONw4I=", "wojDhMOJZSnDkQ8j", "wrrDqnrCi8KVw48z", "ICUXO8OkJMKuw6zCi0c=", "b8KGwokqw4fCisO4P00sHcOHw60=", "bcKFwpwyw7DCl8OlPQ==", "wqVfGjRA", "wpNbHTA=", "LyEMO8O6", "w6koDysr", "wrLClsOJFg==", "wr/DrUHCszcAFMOQAMKkH8OL", "bhDDusKyPhsIw4vDhCo=", "w5bChD8PwprCisOKwonDlQ==", "ARknZCA=", "w7HDv8KQwqDDihDCnnM7w6s=", "wqguwrvDsMOh", "wqHDgEzCrMK/w6JVXw==", "QcK0w5dRcQ==", "dRAKw6QBw6fDsSRa", "RQpG", "w6/CsMKhwpTCnw==", "f8KPw6NlUQZew7QvAw==", "wpvCmMOIBMK3bGXDksOo", "DRAMw6M+", "EQIL", "w5MVw5XCo2A=", "w4jCnysbwpo=", "woPDqX8=", "DjJzwr4R", "fsO4w4t0eygrIsO5", "wrgjIWnDm8O8w4hywoY=", "wrHDm8O4fTnDkDk=", "UMKmwqgYw7bCvMOTHl8X", "w65rwqlHwrnCj1nCnMO0woDDuyNn", "w5l6V8KJw45z", "w7seJSgiRA==", "w5bDgMOBRwTCpcKE", "IjdFwqQEwqDDkQ==", "wobDj8KMHw3DsMOqw4/Dtg==", "wrZew6bCg2NGwoZy", "w6/Dn8OzSiTCucKZ", "wr/CrsOOAsKT", "KURQwo8=", "wp3DrlPCgx0=", "JCUXO8ODDA==", "w4vChysFwqvCt8OD", "wqMlJ3PDnMOEw5Q=", "wovDqm3CtsKUw44=", "wrvDp0PCmTonI8OQG8KU", "wrzDtCnDtQs=", "w7/Dk3zDlMOz", "wot9w5LCqWVtwrlROcOt", "wq/ChznChwrDnMOVQMKFw4vDoA==", "WybCkEfCuA==", "JjHCpxnDqMO+", "NV7DrsKMw6VldVguw7xLF3o=", "SDM+w44Hw4zDjB0=", "Dgsew60vw6l7BA==", "wr06JGPDiQ==", "w4F0wrxfwojCj3/Cnw==", "GcOtacO6Hg==", "dcKYwrbCqBUeSMOfIg==", "w4FAEyQLKcOP", "wqDCkC4kwoDCrMK2w7Etw5PDrw==", "w7XCtcKwwpvCmcKDw7zCjsOMPsOvBzc=", "NMO2bsO1CQ==", "QcK0w5dRcQE=", "J2rCjh7DsMK0w7jCvhQ=", "wrPDuGrCuSEHMsO1BsKXEA==", "wpzDiMKgAgzDhMOuw6/DvMKowrk=", "w6TDpUrDo8Oow4TCrWY=", "wplGw7XCm05Bwph/G8ON", "wrIpIFPDkMOb", "JSvCpCUgGDhjw6Yfw4zCsg==", "wrw/wq7DnsOqZg==", "wpYobcO1wppNMMOYwqTClA==", "MMOwf8O+AkDDocK3DcO7ZB4=", "wpLDnsKZLhbDmsO7w43DvcK7wrIP", "wrIpwozDvsOgcMOR", "OzFlwrg=", "RmLCnm7Ci8Ky", "AyDCpQrDosOUwp0=", "wpgtPXTDvcOJw5xnwpHDkQ==", "w4zDgsKqwpnDqizCpw==", "wrbChhvCghrDjMOEbcKFw5LDmMOiHjPDhAnCv8O6wq7CuQ==", "wrTCkRfChwnDisOCTcKJw5PDoA==", "w4YMw5/CoQ==", "w6bDrEjDtcOdw5XCrQ==", "w5sPMBsubRg=", "w4/DgcO3VQTCtQ==", "w71WHz4=", "wrgmfsOjwpZa", "w68PMB0ibg==", "w5vCqMKFwr3CrQ==", "wrB4w4xd", "wrzDvl/CrwI=", "w4EENzs=", "RsKPwqPCky8=", "csOsw4bCrsKTw78=", "w7HDnsKgRMODcg==", "KxgsbyY=", "RcKoHlPCgMO3w6s=", "w55rRcKa", "w63Cp8Kpwp/CuMKUw43Cj8OcCMOO", "wrPCnTrCnRI=", "Pi1bwrEV", "wovDgMOHawXDhyQ=", "NCPCrSUQKit+w7cTw5rCsw==", "QsKgwpM4w4c=", "wr3DqkrCswsEJcOeCsKFDcOR", "w68PMAYpbg==", "KMO8Y8OvMnLDocK2DMONYw3DqUEDw6Abw6nClAI=", "w7BEw44iQw==", "Ni03P8Om", "w7nCjUlCQMKY", "JwAsbD0O", "aMKqFErCrMO1w6vDp8OlInp3w4UzU2o=", "wqXDoWrCiw==", "wq/Cmh3CnA==", "JQsdbSYAJCXDt8OIwqbCiVnDi8Oa", "w6Jfw6kzbHllwrzDjMOGw7zDowBDw6/DhcOAw6EKT8K0wo11eQ==", "wrItOX/DvcOcw4Nuwo8=", "wrVRw6nCn1cBwpA=", "wplJwrIEw5HCoA==", "wpTDh8OJeBvDmw8mw7UDf8KWwrt/wo8=", "BkLDu8KJw4RkQ0c6w7xIJmnChg==", "MxEew604", "woYjIXTDmsOlw5BswoLDl8OKAA==", "NsO1esOiIHfDs8KsHA==", "WR0Uw5Mo", "w4dIwqNO", "worDinbCkBw=", "wqvDh8OdcijDrj09w7ZWOsKC", "w4F0wrxfwobCjn7CmsOi", "LkTCryw=", "XsKlw4BTeA==", "CcOIw6LDpA==", "VMK1BErCl8Ofw7jDoMOgB35r", "w5rCgsKGwpDCkQ==", "dDDCvmA=", "w7tABjUI", "wqDCjQo/wrbCtsKnw4U=", "wrVfDz5GRl54RMOmLBtQwqE2bsKCwrvDiA3DuMKcAis=", "JgokZSYMHxfDt8OVwrvCs0fDq8OzwoTDhsOYccOi", "SwpUMcKOwoY8TwPCtDc=", "w5Z9wqlvwqXCiA==", "wqA/MWjDt8OGw5dt", "w7/Cmlhq", "5bq25Lu/5bic5baV", "wrBfHRhaUA==", "Uz7CpGfCtMOn", "KSFwwr8XwrfDugIsMcOHDjHDnsOKN8OMw59pwqRTM8OgADDDlj3DisOY", "wrI0wr7DssO8WsOY", "B09XwrLDkgQ=", "WzAxw5Etw58=", "woJyw4Vew4BUw7LDj8Kcwpcww5DCjAhZwpUtGGjCg0bDgFzCq8K7wovCl8KZwqo=", "HAELw6spw6VLGsOzwpPCvTjDtMKmw7TDpMOnw4LDhXrCkcOSwqQV", "VzTCvkjCs8Oz", "w4jCo8KiwpXCmcKSw7fCkcOYLsO0CC9fWk5Ew7nCnFjDscK2wpjDnSkmfSw7Fg==", "WsOZw7pCRjgC", "UcOSw7hITBI7B8OMOzYvEWJFw6DDuE8zw5lYwqhGwpTDjsKGwpXCjAPDvA==", "wpTCksObGMKgXUPDksOswpTDq2nDscOVTRc6W00/", "w4TCqnRFYQ==", "w7BABBkKKA==", "CUrCtSvDnMKM", "TsOWw43CsMKHw67CrAzDi8KkQQ==", "w6JIw7QeQGs=", "w7RKHjYNPA==", "Jy17wrkRwo3DghY5HcOHMjjDmcOCAcONw7Npwq4=", "wo/DoHfCmcKTw5o=", "Kx8nZAsIJDjDusOHwrzCiQ==", "wqFXw7PCs05B", "A0VNwp3DlRA=", "w7vDuU7DtMO0w5LCqn5lwrhVw6HCt19OwoJjXsKP", "csKZwpglw6zChsOvIWcrBQ==", "worDohPDujY=", "f8OnOidGNMKwFmpfw6NwGC3CpyPClMOWcVs=", "CEjDvMKCw6V0fkc6w6xQGGLCisO6QBIWw4VI", "woDDpnTClsKOw6Jna3RVGjzDhE8DwqnCnRDDtMOJ", "w5h2wrlDwrPCtGs=", "wr3DrlPCnzoH", "wqXCig4iwoHCgMK0w5g2w7rDucKBw4zClMOFTw7CkMOKKg==", "w7/DuGrCtCbCsz5NwpFkWMOvDBbCgUZRADFw", "w6fDoUTDrcOlw5XCp35Ewp4=", "VsKzwrbCjCw=", "BEDCoxjDvA==", "YMK7HEHCrMOiw6vDocOiBWhq", "wqgywrXDoMONccOG", "w67DtWPCrB3Cshk=", "XcKUNFTCnA==", "DUzDt8KIw4hhU1g4w7pQNA==", "Ji3CqQnDhMOCw5E=", "wrlfEQR9", "w47DumfDsMO6", "wqfChhsewrw=", "wrBbBDRhag==", "HCvCtQo=", "w7ZDBDUWHMKdJ05sGQ==", "wpvDnsKVODA=", "ZRjCnnjCrcOl", "w4LCqcKpwp/CvsK+", "W8KZwpvCrDc=", "w7PDrF/Dk8OFw4M=", "c8KMwoU/w6zCk8O2InsGE8ODw7zCjsO2QD8jw7jChQ==", "w41vW8KLw7RbwovDgAzDqBDCgA==", "GU3CtDrDvMKPw48=", "w6bDg8KJwpnDng==", "KMO8Y8OOJA==", "w5PDnsKKwoPDqiHCkFQIw51Z", "w7LChTkI", "wrcpMnXDjMONw7Zjwo7DlcO6Ow==", "XcOSw6Zydw==", "w6ZYRsKYw50=", "w7HDsms=", "w48PMBoO", "XjTCslTClA==", "w43CgFJ8", "w6RNHycqPsKEPn5w", "w7LDs1/CrzXCpBV6wpF6Tg==", "w63CgFJ8Z8KPwqQ=", "wqgywrXDoMOKcMOGMGfCqw==", "wrzDlcKeGQ==", "DAvCrjM7", "w4zDm8O9RCLCtsKdw4Y5w5N6MQ==", "wpIpIE/Dtw==", "P2TDjsKUw6d0", "w7jDksO/ViDCr8KAw4wdw44u", "QMK/BXHCug==", "azcww4A=", "DUDCrwTDm8KY", "MiHCoy86NC1Ow6QXw47CpRcdERJzTsK+wo8IEsKzK8KJwpJwwoE=", "woF0w4Bew4dfw5nDoMKNwoUkw6rCvwJVwpI6ImHCpFXDg0fCvMKPwrfCncKX", "NAoOSyM=", "NcOxdMOsIWvDq8KgM8O7chg=", "w4JIw7QCZw==", "wpTDgcODeQnDmyw8w6VF", "cTrDiMK0Mg==", "wpI0wqnDow==", "w4nDmcKIwpLDvw==", "YMOrIw==", "wpxMwp4cw6M=", "Iwo2", "w7nDj8KoT8OJWEnCt8Kgwrk=", "dcKlw4JjXQ==", "M0JMwow=", "woPDv3zCkcKlw55oanN+", "w5Bkw5QuXn0=", "wpXCnBvCnw==", "wppNwrwKw53CosOlw5Miw6M=", "QMOtJSdCHw==", "WSLCiXTCrsO0YkI=", "KioTKsODDA==", "w6XDl8KiVsOXX3XCq8Kjwqg=", "wpnDplfCisKX", "wr3DvinDtSU3FQ==", "w6PCqMK3wo4=", "csKCwrjCsSgXUcOfEno=", "W8Kzw7VDZy18w5Y=", "wr/Dp3bCiA==", "wrLDnsKZODA=", "wo/DgnPCryQR", "w7XDnsK2woc=", "wqvDqm3CqsKz", "w7HDtGfCvhHCrhFSwoJj", "w7lxwrlD", "NcOxdMOsLGbDlMK8D8O3", "wrVaw6jCjWJTwppwCsOa", "wo/CmgfCnA==", "wpHCksOJPsK8Sw==", "wrctOnTDm8Oaw7xtwpXDlcO7HcKE", "XsOYw6hCfAMK", "wqlCw6LClH9VwoZ3C8Oqw43DtRYGw617", "w4N9dcKbw5hfwpbDgg==", "NwctfRccMxPDucOL", "w6ADICoEaBgDwr5L", "wp0lMH8=", "w6FMAzkGN8KZ", "wqXCmBHCiQ3DrsOcaMK+w5XDo8Ou", "w7rDuHjCkjrCpQ==", "AkzCvyjDt8KKw5nChSXDiw==", "wqgywrXDoMODdMOTIXDCjSQ=", "w5AHHCcq", "Mk9Ewq7DtQ==", "w4Mqw6TCtGQc", "w75LGSQxEg==", "SsOKw6DCssKkw7vCnhzDusK1XQ==", "wrIpIFnDlsOBw51mwqHDicOhE8KZZQ==", "wqLCtiDCpjs=", "DSc+CcOB", "wrVGw6bCnUU=", "LAorbTwd", "VC85w7YR", "w4/DmsOqag==", "wr/CmcOOAw==", "wqXCn8OSAMKVWXHDh8Obwo7DvUE=", "w6jCgyUL", "XsOYw6xCeRYJEsOvPCs=", "wrBbw7TCk0JewpE=", "QDDDgcKHEiM=", "XMOHw7tJYRIcB8OCOjE=", "dxLCk1HCuQ==", "w73Ch1NtR8KM", "WD7Cp2TCgsOtYl0Nw4Blw4cow4FAw5zCnFxZw6V+McK9wo7DqxE=", "wqpXw6HCjmlGwpFz", "wrw/wq7DlMOsfMOSIHDCmxJyTsOV", "wr/DpjHDtRU=", "w64JBT0h", "wqXChgU/wrzCq8K2w5E=", "wqVTDjlAanVtSA==", "eTDCrlTCvw==", "w7ZZw6EwSw==", "CE9KwpzDlAM=", "w7HDmsK5aMO4SA==", "MENbwqI=", "wrzDtDnDpC43HnE=", "w7gWw53CjnwQD8O9w7nDgMKn", "wrnClhAj", "woDDqn/Ci8Kzw4llYg==", "wptMwrQVw6fCjsOpw4Ia", "VcKlw4J1fDB/w584Mg==", "UcOYw6Z4VxkCGA==", "w7tMAyQtL8KZJw==", "wprCksOTEMKmUA==", "w5xnRcKHw4lHwpw=", "IcO8b8OSA3E=", "bcKDwqTCsi8GTMOG", "w5JTFT4Q", "EA7CiQME", "wqXChg0swoHCtw==", "w6pdw6U5Y3FlwrvDpcOCw6PDmQ==", "wqpbw7TCjmdTwpl7KsOQw5zDtAocw4xoa8KU", "wqBLwqAJ", "w4ULw5/CulMYDsO8w53DjMKswqQ=", "YznCpXY=", "wpHDtMKbJTQ=", "BV3Dv8KDw4h0WUc0w61X", "w7jDoFjDrsOsw5HCsm9Uwq9Lw5HCqER8woZISg==", "JhtkwrELwrbDrAYoLw==", "wozDgcOFeT4=", "wrc1wrXDpw==", "PyfCpjQGLjx8", "w6zCgVpjWsKiwqhnwo0=", "e8Kuw4VC", "wrYsecOowoFNHcOpwrfCniPCiMKYdjBjwqzCoMKbNMOmMlRW", "VDo5w4MNw4zDmxw=", "w4/DmMKqwoTDjivCh0Udw4s=", "LCFiwpkLwqE=", "WRhBJsKIwoY8TwPCowrDiQ==", "w6XDi8KsU8OifEDCv8K2", "NxsjeCAuIQrDs8OkwrzCgg==", "d8K2w5NYYA==", "w5zDv8ObcC4=", "XcKuw6VCdStnw7wYK1w=", "MDAbLMOiAsKdw67CgXEyEw==", "RcOFw5NgXA==", "IkzCvyg=", "w5nCgi0owojCu8OWwpc=", "wrpNwrwK", "Ay1ywrU=", "w7rDvGHCvhfCohNRwpw=", "wolkw6pfw5tFw73Dk8Kcwp0mw70=", "YgVEMQ==", "w5/DkcK+VQ==", "wrXCnBvCnzHDisOIcMK/w7U=", "wo1Iw5FQw5xVw6TDi8KYwok=", "woDDpmrCi8Kow5xuaw==", "VDYsw4MNw4zDmxw=", "wq7ChhcCwpvCrA==", "wpLCkcOfP8KK", "w4bCr8K3wo7CrMKWw4XChMO8JcO3ODFCc0ZEw4c=", "w519wrNBwr/Ckw==", "wrczwqnDo8OWdMOQIA==", "BkTDqcKZw5BwTFIew6dTKHzCl8OTSBIo", "XsKlw5hRYDE=", "woDDpmrCi8Kzw4llYg==", "wqrCnQfCnC3DjsOeYA==", "NBoxYg==", "wox+w5BFw7tFw4jDkg==", "KsO8dcO8GWo=", "w7oKw4PCuUYYDcO9", "wqvCqyDCnxrDisOe", "B3LDicKIw6NYVVI2w49KJA==", "worCkhjCuhg=", "wqPDujbDvg==", "dMKEwpwsw5bCkA==", "w7vDr23CtjE=", "esKMwokIw5vCisO7NUogP8ODw7LCgA==", "HyTCrBIo", "MgIBw5Y8", "wodyw5dyw5pYw4HDm8K/wp0Nw67CjQQ=", "f8ORw7J1WQ==", "w75LBDUWLcKdJg==", "Z8OAw7tCUA==", "wrtTGiV9V2Rl", "XDjCpGTCvMOyQ0AGw6I=", "DA4sbjgMMg==", "IDYfP8OiIA==", "wo8twr/DssOq", "wqXCihA/wrzCq8K2w5E=", "OSzCqBvDrMOUw6fChcOiwoE=", "UMOFw7tGShI=", "Jy1lwqQswqbDgB8=", "esKhw5hSeDxh", "w7bDoEzDjsOcw5XCumQ=", "wqvCmwbCjTjDjsOdYcKow4jDoA==", "TjDDncKEPCUhw6HDkRDCvA==", "e8OWw7BDUhIW", "SQBFNcKO", "wrVfw6bClkxmwoN7CsOG", "w6UFNioAfAYSwpNSOQ==", "EBgnbzo=", "cMKGwo8uw7TCgsO6NEotHw==", "w6/Cp8K3wp8=", "wo5Tw6nCnkxXwoY=", "CVfCvizDgcKO", "wrclesOmwoE=", "w7zCgVpfWcKOwrls", "wol5w4pFw6d4", "w6NgRcKa", "w4NgX8Kaw75i", "wrtfHzRYYG1hVQ==", "wrzDtCnDtQsAF3VA", "wrfDtCvDkw8qF3hywpLDhcOww6du", "wpR+w5M=", "ccKGwrbCvzIbWQ==", "MDAbOcOz", "wp7CksOUEMK6TA==", "LDMUO8Ok", "w4rCrgAywrA=", "DUtN", "wqnCgxrCjQ0=", "GQEZw4czw6l4DsOQwpnCgAbDtcKq", "w7bDhsOafyY=", "ECwVKQ==", "eQRPIw==", "w6LDoFjDs8OJw5zCug==", "wpnDnsKbCBXDtMOnw4vDow==", "wpEtIHs=", "w7BEHTU0KcKTL1hK", "w4rDkcKpwobDqg==", "PiPCrg==", "w7HDuGrCrwDCoQRYwp4=", "K8OGaMOvDHDDtMKCHsO/ZA==", "wrgsecOzwqdfJ8O8wrg=", "w6dJESkwMsKM", "XAVTPcKewq04", "NF1Gwp7Dkg==", "w4BMw7My", "w7RXFTEQPg==", "wqjDokDCviAgIMOUDMKO", "w63DmsO1WxHCg8KHw4YKw5Q=", "WgBBLcKowqgt", "RMKpw4VfdjV2", "ATLCoxvDow==", "NsO1esOiOWvDsA==", "BiUJOw==", "w7PDlsO0RzHCoMKVw4YB", "w5wdISop", "cMOiMi9AKsK7Hg==", "wr0ndsOzwqZh", "bRYLw440w50=", "dMKHwpQ/w6bCqg==", "w4/DmMKqwoTDhivCtkQ=", "KQYmbjgMFS4=", "K8Owf8O/AWfDlcKM", "OCzCohrDocODw7zCow==", "wqdZPTtR", "HAsZw7A0w61BIw==", "NyTCoggX", "w4JrX8KJw4Nf", "NCfCtAkhKQ==", "w4TDoFPDgw==", "w5TCnCQZwo0=", "w7/CoMKqwrLCkw==", "WjArw4Mrw5XDqzg=", "wrBfHRJcSm1sZ8OsESVRwq0=", "acK/CVA=", "woVMwqAJw5TCpsOww4Iyw5LCiChLfm7DrsKgw7o=", "QMOAw6bCnsKNw6k=", "w7VKCA8NNcKaJQ==", "w6QFIyA=", "wqEjJE/Dtw==", "w7rDuHjCmDzCvw1ZwrJuZcORDRo=", "w513wrpJ", "w7PDmsOhRw==", "woRMwrcZw7/CosOIw64=", "w6fCrGpESQ==", "wrbDolTCog==", "NMO8a8O+DHbDmA==", "Sjovw5Ilw4zDpw==", "f8OnJDo=", "wrTCkRrCjBrDncO4ZcKEw5jDosOuCQ==", "w4ZnRcKaw6xKwpTDiirDtRPCnDTDnMOqwooowqw=", "wo5yw5tFw7BFw4M=", "bxpFOsKI", "w5RpORMv", "w5fDmsO2Vg==", "QznCpXbCnMOkWVYYw6I=", "w4ttWcKbw4VfwqbDnw7DqgbCrCTDh8Oawp8zwqB+IsOB", "wqtdw7HCn2JGwpo=", "w57Dn8KxwofDoCLChnU=", "wofDnsKDCRzDhQ==", "exHDhsKoAw==", "PyFuwqQ=", "wrklJ27DucOJw5xnwqbDiMOfHcKGdGvCm8KCXA==", "wrXCnx3Chg==", "TzbDnMKVPCUhw6HDlhzCosKkB8O+GzdSw78=", "w63CgFJ8Z8KPwrl6", "WsOaw79AWwQ=", "wqPDuTDDpy4nHmQ=", "w4zCtMKlwpfCjg==", "BSzCpQ==", "w6ZBw6kndg==", "dDkzw6Uj", "bznDg8KzHA==", "wqfCgQDChy/Dg8ORfQ==", "w7DDlsKpwqHDqA==", "CURXwp7DjgHCox8=", "VzTCvkLCtcOpYUsqw75Kw4sgw6c=", "ZgpMBsKb", "w5jChyMMwqc=", "w7EGw4TCjnwQD8O9w4nDnMKHwrLCvMOi", "S8K8HXbClA==", "CUHDs8Kdw44=", "NDDCshHDncOKw4jCkw==", "dMOrIwdcGA==", "w5PDgMKgwp3DkC7Ct2MLw4dDwoJ7bw==", "LCFiwpMNwrvDiRYPO8O6MDDDkg==", "UzDDhsKPDw==", "A8OvfsO1GQ==", "wrvDpMOhXwc=", "woZVwrYTw57CrsOzw44ww4vClSI=", "BkzCqDnDssKKw5rCjgXDgcKZS8KvBUDClizDqQ==", "eT/CuXU=", "wqnCmjPCiRLDisO/csKPw47DjcOnEifDoivCqsOmwqTCpDM=", "ccOhIzpdBsKCOw==", "Nwoew7A=", "JyDCoAzDqMOVw4HCqMOjwpw=", "ccOnOSo=", "wprCnsOOA8KVWXHDh8OIwp/DqFnDr8OIZB86ZQ==", "Sjo5w4Uhw4vDljNhWA==", "wqnDo0jCoR0QMsOJ", "woXCn8OSAMKbXHnDmg==", "ICrCrzcGPjxp", "wpHCrQoCwo0=", "WQRPI8K1wqU4Wg==", "aDY8", "ZMK2GFTCqw==", "w6JIw7QURnFnwrbDoMOaw4DDnR9D", "QDPDhsKRIg==", "wovDqm3CvMKSw5Rsa0JzJz7DjEQ=", "w7HDmsK5YsO+Uk3CtsKRwrREw4vCn1U=", "X8OoOxxV", "wpzDlcKZCAvDgcOqw44=", "OkzCuA==", "wo/Do3DCj8Ki", "NCfCtAMnMzV1w5YPw6fCoSUb", "wrrCkcORJcK1", "w4vCs8KwwpXCu8Kbw4nCmA==", "woZDwrU8w7/Cqw==", "wpXDpzrDvhM=", "wpnDh27ClR8=", "QsKsFErChw==", "w4RBw6Q+QH9ZwrfDgcOMw7zDmA==", "57mv5p+v5ru95ou855iL55qd5a6DEQTDjULCi+eCp+WHpg==", "VcKlw4J/eio=", "w7LDrWnCtRnCvw9Uwrd2RsOV", "w6RNHyctP8KZMg==", "w6ULw5/CulYYDcO3w67Dlw==", "esOZw61T", "wrVaw6jCjWxbwp97I8OBw5/Drw==", "MSvCriQ=", "57qt5py75rmV5oqL55uf55mS5a2E", "woYkO20=", "wofDnsKeGBXDg8Oew6s=", "GUXDr8KLw7F9RHYpw61CPg==", "OSzCtQrDisOHw4TCj8OJwpzDrkBNwp/ClEzCj30=", "UDfDgMKWMiApw7w=", "csO8JS9L", "bcKDwqTCsiETRMOOAkvCmQZaGyjClcKcwp0=", "w47DlcKjwoHDqjzCuw==", "ISzCqxvDvw==", "ICgfP8OkBMKQw68=", "DENQwo8=", "woVAwqUYw78=", "wovDg8OBcg==", "wobDmsKbCD3DlsO/w4M=", "Iw4vbxcdMgvDug==", "QMKlw4VTYA==", "w41rQsKnw4VY", "w4nCqcKqwpzCgsKQ", "OjXCoxDDksODw5HCmsOjwpbDqg==", "wqPDuTDDpysqCGg=", "w7tMAyQ=", "wpZ+w5BYw5Bdw4g=", "wqFMwrcY", "SQBFNcKOwoAxTg==", "w41Ew6Qy", "CioJKg==", "w47DsnnCtTDCmwBTwpFwTsOC", "WgBBLcKxwrQuSwU=", "DjEJN8O1ag==", "dsKhw4JX", "XDTCvGTCsQ==", "HcOaw64U", "OCx5wqcpwrvDlgY=", "w6QDNzs=", "XsKpw4VC", "wrzDuCzDpA==", "wqVXw6vCllM=", "MSsOP8OiLMKTw60=", "VcKdwrLCowg=", "Ly0JKg==", "w4bCr8Kqwp/CisKFw6bCjsOXOA==", "w4IUw5XCqHo=", "wpTDgcObaA==", "wpJbGjQ=", "RgVOMcKdwrMTTQjChA==", "wqbDmMKfBAnDgw==", "OjHCjiU3Lg==", "w5nCs8KmwrTCnsKa", "w4TDmsKqdMOf", "wr9THRNbW1RBFA==", "GkTCvCjChA==", "wpnCgMOTEsKg", "IcO8b8OYBWvDrMKhPcOrTw3Dp08=", "csOIw7rCp8Kq", "fsKBwpg4w4c=", "w5jCgy8Pwos=", "bsKdwpwsw5Y=", "wprCnsOaH8Km", "Iwo2STwALAPDlMOfwobCjUbDpw==", "wpPCmRzCmDY=", "fhlUEMKM", "DENEwpPDiA==", "QMOAw6bClMKLw7PCnx3DusK4fTMowqQ=", "wpzCjgs7wrw=", "wq8ZwpXDv8ON", "UCvDjsKGHg==", "SzrDhsKGEzA=", "w47CmlJUeMKKwrB3woU=", "SMOSw7zCssKR", "wrnDonHCj8Kz", "MiDCsj3DpcOPw4XCjsOOwp3DkE5Swo4=", "wpnCkQwUwqPCvsK/w4kn", "wp/DjcOcXyTDijA3w5VIEcKRwrdz", "NA4lb2U=", "wpHCksOJNMK6UXDDhsOPwp7DllfDsMOZ", "wrs+ccOiwoE=", "w68PMAwvdAcTwpNfGWPDiCU=", "w67ChiIMwrY=", "wp1ywrgew74=", "w6fDvUrDvcOO", "wqbCjSE/wpvCmcKmw5Ihw5HDo8KNw4c=", "w5VRHg8nN8KVKUA=", "wpYAHVnDtQ==", "OivChRLDpMOFw4LCtcOPwojDt0xU", "w6h8WcKZw5hOwos=", "QyTCqE/CqMOt", "UcKvw5hQfT4=", "wrgywr/DpMOwSsOdKFvCgTdMUMOFwrwZwpY2AsOyAkXCjg==", "LCovLsOyJMKIw6Y=", "wrtTDjlA", "w4ZnUcKGw58=", "wpLCucOFDcKb", "RjDCpnTCuA==", "wpbDl8KEDhLDtMOkw5fDvcKq", "woXCgsOfOcKnVQ==", "AzDCrx8ZOzVkw7E=", "w6nDksO+RgA=", "wrXCgRbCpgrDgg==", "fMOgEydBCsK1Hns=", "wp7CnsOJNcK9QEnDq8K8", "wq9Bw4nCn1hG", "wpzDiMK+GBo=", "w4V+U8KAw7RKwp3DsAPDrBfClg==", "w5LCmBkJwpw=", "wpHDm8O7aS8=", "wpHDm8OmeTTDlw==", "wo9cw7TCjg==", "wq0zwqnDvsOmecOb", "MyUdO8Kn", "w4YRw5/CkkIYD8Osw64=", "wqFbBSRR", "w7fCm19qQMKFwrlwwrM4wrc+", "w77DsmLCvT3CsQ==", "w4LCr8KwwrjChMKPw7fCicOQOcOiAypbUg==", "DUjDrsKkw7li", "wqVaw6LCiVRtwoRsAMOPw57Dvgsbw5dqZQ==", "wrnDj8OBUCU=", "Fg0Jw6EZw6F6BMO3wpI=", "w7vDvkXDv8OZ", "ODB3wrcA", "w7PDrF/DmcODw5nCs25Twq51w5/Ct1U=", "DgUKw6Fq", "AkDCsirDncKf", "dMKuEEPClg==", "W8OSw7dAVgM=", "E8O0c8OrJA==", "BVLCtSjDhw==", "ZTzConHClA==", "w7nCjUlIRsKCwrBmwqIpwpYoFVE=", "e8OnIyxdE8OmEHF0w6R8EA==", "wqHChgoswp3Cqw==", "YcOSw7hVWwQMIsOk", "wrzDvXbCoMKsw5xsemU=", "UMObw7dEVTQLAsODPA==", "wroiF3bDl8OLw5pdwqDDnMOGEcKf", "w6/CnC8ZwpE=", "cMK0w5hpVzV6w5gS", "d8Khw4VT", "wqJjw41uw7Fdw4TDnMKW", "wqPDsj7DvAIb", "w4dZw64IbXRiwrHDiQ==", "GUbCuiHDkMKy", "wqttw4TClklRwp8=", "JcO1csO4BkHDr8KwEcOm", "NirCqBjDpMOB", "cMOmMj1GNMK0Hndjw7tMFC3CoSPChcOBZlkufMOF", "wojDrkHCpDEHP8OkIA==", "W8Kzw5RXejd2w4kqLlYa", "SQBJN8KXwoIyVwjClQ==", "WS5qJMKa", "wpnCmcOeEg==", "wodyw5d4w5xC", "w7zDoE/Dv8Opw5HCsWR0wqU=", "w75WIyUH", "IjdFwqUG", "A1bClSjDjcKf", "ccKAwpMuw5LCkcOZPmY8", "woA+esOiwp0=", "w6sCITwz", "w7tMHjUFKcKyJUVc", "PlLCvijDmw==", "w7HDtGLCvjXCpC9Swp5y", "w7JEw64zQW8=", "FcO6acOyHXY=", "bsKcwp8Fw4bCjg==", "w552wphIwqrCmWHClg==", "wr9THRNbW1RBFw==", "fsKFwpQow5jCoMO4JGYt", "wqUtM3/Cjw==", "wo5Awqc+w7vCrsOxw4M1w5PCtiZUbw==", "w67CiVpuHw==", "RMONw7fCpMKX", "wqXDkhDDljQ=", "wqXCnBHCmws=", "w7PDpsOEZCE=", "KyETOcO+MQ==", "w7oKw5fCpWA=", "TzbDiMKJDw==", "w5zDmMKDTcOA", "w4RmXcKYw6I=", "w4/DhMKkwpTDqg==", "csKewpMuw4E=", "dMOrIw1aAsK7Flx5w55yECY=", "wrxIwrsNw5o=", "TcKbwpIUw6XCgsO7JG0=", "TQlUF8KUwqgxRiTCmDDDhm5s", "CRQAOMOS", "w7HCn1NuXA==", "wq7ChhcIwp3CtsK/w5gAw5zDhMKDw4TCnw==", "Wg1HMcON", "w43Co8KwwrnCg8Kew4TChcO7JMOJNi5T", "woh+w5dTw51JwpzDncKSwpA3w6DCjQ==", "w7jDlsOmcA3CvsKcw4ctw4NRJwtl", "OyVxwrVU", "wqTDhjTDswo=", "w5nCssKlwp3Cjg==", "wrfDj8KDMjrDm8Oiw4HDuA==", "w7kNw7PCoX0aCMOGw4jDicKgwrDCug==", "IlhMwozDjxLCsA==", "aMK0JkHCmsOKw7DDoA==", "IDfCog46Nw==", "PyvCpyg7", "w6QDIycz", "DAsZw6Uvw6l7BA==", "DmvCozfDvA==", "MFhMwqTDqhbCrgZb", "cMOiPi1ZKMK4B3B0", "ZcOvOztX", "XcKuw7JfZzhxw5cc", "wprCiww8", "wopQwqEow5o=", "wq3DocO8ZTzDhg==", "w7XDtHjCmTvCrjR0w4I=", "w4lmU8Kdw58=", "PyZ5wqhKwrHDjRc+Ng==", "wrvDiwjDnj8=", "wprDthHDvDE=", "WA1OMMKTwqw=", "wp/ChMOuAsKx", "wpp4LhJ1", "w7hVFT47OsKYFUdYJG0=", "OjLCqBvDvw==", "IyzCtRfDr8OKw4w=", "wrZTw6DCnxE=", "w7zDn8O7UA7ClMKfw5YBw44=", "aMKZwrXCpwgcTMOZFFvChh4=", "LAY2SDsRHw/Dv8OCwq3CuELDr8O7", "UMOfw7tUSigUBcOCLzcVDnh3w6rDtg==", "Iy1ywrUnwrPDixwoMA==", "wqc9fsOgwpY=", "WDTCo2bCtcO0", "Vygxw5I2", "LsO8csO8BXY=", "w6XDi8KsRsOz", "w6LDqMKmQsO7", "QjHDjMKJFDYV", "B09XwrjDlB7Crhd8wqPCjWrClcKC", "wqDDlsKFHTA=", "w5zCjj4/wpfCt8Ofwp3Dsk8nw6fCrcO4", "w4/DuGrCqTHCpQlowrk=", "w6sGLSwsXgQCwr9S", "wrkWXMOrwppLKQ==", "wpLCgxHCjRE=", "w5QXw57CklcVCsO6w6A=", "Zj7DnMKE", "wp0tOn7DksONw4M=", "wqRZCD1Rew==", "w7nCnyQjwrzCssOawprDmw==", "wrrCgAInwpDChg==", "wqvCqzfChBbDjMOb", "ZMKyFFfCh8ONw7rDosOoA3BGw4IzVUdYBycGwq4MAg==", "wrtAwrUPw7bCtMO1w7I+", "bsKBwpwgw5bCgMO/NHst", "wq/ChxbCiRHDgcOVdsK5w5TDocO8", "cT3CrmjCs8OnX0oLw6h2w44=", "wrctOnTDm8Oaw4JqwozDhw==", "RQJDMQ==", "ccKzAk3CkcO+w7w=", "wolkw7BEw5E=", "wrw/B2/DnQ==", "L8OqSMOuDg==", "QMOfw7FQcBIcA8O4AQ==", "GU3CuibDkMKIw5/CjjPDjQ==", "KhMIw6E1", "wrnDo0LCpSA=", "w5JEAzU=", "w6QDKiombyUYwr9D", "PlrDv8KIw7k=", "JcOxfsOoGQ==", "wpEobMOi", "wpTDgcOGeS3DkRI8w7lU", "Eg0ew7Acw6F5D8OXwpjCvgjDqsK7w53DrMOnw7w=", "esO9GStKHw==", "w64DKigibyoFwrBf", "UTE2w4MRw7E=", "w79HYsKXw5tO", "VcKhw5tTUSFjw5QLMgg=", "X8Oew61TeRYJEsOoMDUfD39sw6jDuHE=", "w7rDlsK+VcORWkzCt8KWwrV6w4XCgETCoG7Cr8KL", "w7fDpkXDucOKw4Q=", "w7TDkMK1fsO/VUfCvQ==", "Z8KDwrnCoQMAaMOZJko=", "w6NEw64wS2pKwqDDg8Oa", "wpjCksOFA8KQTHI=", "w5XCjjIIwr3CqsOd", "w7jDoFjDrg==", "XsOhw4XCmMKE", "OSzCtQo=", "wr0pPX3DlsOc", "w5BnYsKLw7g=", "wqbDqFfCk8Ks", "wrfDtCvDmQkw", "Lg0Vw50=", "wqpbw7TCjg==", "JibCtBHDocOKw6vCi8O+", "w4LCr8Kgwp8=", "S8OMw6HCo8Kkw7vCnhzDvcK5Qz03wrU5w7hBAw==", "OSDCqBnDucOO", "JyDCqBrDqMOU", "IjYIP8Ov", "aMK0M1DCncOUw6zDoMOiFHJ2w4U=", "BjIfMMOi", "AAgzHcOd", "e8Oew7pC", "woN7w4xCw5dyw4zDk8KRwqYiw6zCiw==", "wrYgO2nDm8Orw5Buwo/DssOOEcKf", "Kjc0O8OuMQ==", "YsKGwrjCtQMxSMOHK3HCiApD", "w59MFDU=", "w7DDsnrCvhbCog8=", "w7bDgMORRhbCo8Kfw44=", "Ewp/wpkd", "ISDCvgo=", "KsOwaMOvKmPDrcKgOsOqcQPDuF4Yw6gBw6w=", "wrlbBDQ=", "w4TDoEg=", "w6ROGT4=", "DENQwo/DuxbCrxZ7wqLCs2TCisKTRjzCksOq", "RTbDgcKGHjYNw7bDsh0=", "w5XDnsKhwpbDtwDCtQ==", "w6zDnMOrUgI=", "w4bDucKnwpTDug==", "wrtTGiVzQmxtYMOtLytOwrwfZsKCwoU=", "dcO8NiNX", "UcKPwpEZw5Q=", "UMObw7dXZg==", "Gy11", "wo/Do3DCj8Kj", "w41rQsKtw4NCwpXDiy3DtC3CkivDjQ==", "ZsKvBUvCo8O+w7jDtw==", "V8KzEg==", "Xzorw7Qsw5HDkhVMWTXCrMOsLg==", "FAYh", "AyvCow==", "wpTDjsKZAinDm8Oqw5s=", "w55+wrtnwqfClw==", "w4Bbw6U5Wg==", "54Gc6Zew5o216I22w6bCkm7CnMOv54Ga5YWo", "QznCv2fCu8OsaG4aw7Vlw5M=", "woDDpmrCiw==", "w73ChFJ4S8Kowr1uwowSwrkqEw==", "GQEZw401w7M=", "Kx8nZAsMOBfDucOUwrw=", "w5Jtwq9zwoI=", "w6JMw60ya2B7wr3DkMOXwr8=", "ACrCrzc=", "woVMwqAJ", "bcKDwqTCsg==", "wpJyw4VDw5dCw4U=", "JwMnayYoLAs=", "RsKpw5tTZg==", "wqA+esOiwp1kK8OqwqLDnw==", "Jy1lwqQiwrPDiBcIOsOEPi/Dg8OjP8OMw6E=", "bcKPwrnCoRIa", "wr3DksKJCA==", "w5J0wrJVwq7CuGzCn8OtwqHDshB4", "DAYmbw==", "c8KtFEHCncOew7DDvcO1Ug==", "wq/CpcOPGsKY", "dMKuEFbCh8Obw7fDqsOkGA==", "MBgnbzo9Lw==", "wpwoccOjwp9NMA==", "DQcfw6s3w6xWC8Og", "QMOUw6xIUhsmFsOf", "w4dvTg==", "FF1Gwp7DkjvCqwBKw6g=", "w4jDh8KgwpbDoQPCuk8Zwpw=", "w6XDnMK/TsO6V2PCs8Kh", "w7wdISopUQIEwqUU", "DEzCtSrDkMKZw7bCmSHDgMOY", "woXDoXDCi8Kvw7Q=", "wrHDhsObaA==", "T8KMwpoew7o=", "fyV0LcKMwqQ=", "CErCoxLDnMKFw5HChA==", "BkzCqDnDssKKw5rCjgXDgcKZS8KvBUDClizDqcOA", "w7QMw4jCkn0XBcO2", "wpPDksKDChzDhcOKw5DDssKnw60=", "wrTDs0nCvDM=", "w6NEw64wS2pKwqDDg8Oawr8=", "QMOAw6bChcKCw7TClxbDlcKAQSAkwrg4w7VQD8KVw7ceBw==", "w53CgiQbwprCrMOywovDkU9Y", "wrtTGiU=", "BkTDqcKZ", "EjdAwrQs", "wp3Dq3zCsMKy", "FsOwY8OC", "w7VEEzsmL8KS", "wrXCgBXCjxo=", "w7HChn9/QMKtwqlswoMkwrEmFg==", "YsOTw7fCucKX", "worCryoIwr4=", "T8KzFUE=", "GUbCqSLDmcKHw7XCijI=", "w63DlsOiVgTCo8Ko", "wrklJ27DucOJw5xnwqbDiMOfHcKGdGvCm8KCXCo=", "ccKAwo4/", "w6VAHjQBKcK0K0VdPG0z", "NgosbjEb", "wrZIGzBN", "wpgDAUnDu8O3w6RS", "fhtFMcKS", "A0ZGwprDjjbCrh8=", "wqXCihA/", "fDjCuXXCj8O1Yw==", "A0vCsjnDoMKi", "wrYofMOswrFcLA==", "w7fCm35+XcKfwrNv", "QjTCpGXCuMOy", "CwzCqQk3", "w4jDlcK9woc=", "w51xwq5SwozCmmDClsOEwpvDoxxhwqTDjnrCqSki", "wrlMwrA=", "E0FKwpU=", "XsKpw4VCUzh+w548PkkCJsK7BsOmMMOGw58=", "FwkMw6M+w7M=", "CR4oNcOX", "w6EZGycoaQ==", "BlhCwpbDmQ==", "HQgEw7QD", "w5vDlcKxwrDDpybCv1gvw5djwoRzeA==", "czbDjA==", "w5J0wrRWwpI=", "aMKEwqPCoxQESMOH", "w7BABBMMMsKQLmlAHmksw6k=", "w4YKw5M=", "w4/DmsOx", "Uz3Co3HChA==", "YDjCqQ==", "wqdHw7PClXBewpVn", "wrIgccOgwpZaA8OrwrfClGE=", "L8O3f8O+FU3Dpg==", "Tzc6w4QW", "LDQfMMOJJMKYw5zCglooGsKkwrc=", "w5PDlsKjwrLDoyM=", "w5rDhcO3XRE=", "w40cISEz", "aSBpF8K3", "w5ZJFDkKPMKuL0hWImw=", "5aSu5Y6J5Z+o54+pYjM6fsO654OP5YWS", "DENQwo/DuxbCrxZ7wqLCs2TCisKTRjzCksOqw7w=", "wrVaw7LCnEZewpFfHcOaw43Dog==", "wrbDolTCohMVOsOULMKYDsONVQrCq07DscOjwrc=", "w7cRw4LCrG0=", "wptAwrUPw7bCtMO1", "5aaR5Y2E5Zyx542W", "UcKsw5lFcRpyw5cVBFgOPw==", "JxLCijnDnA==", "esKMwokCw53CkA==", "w7LDrWnCtQvCsxlNwp9lXw==", "w4l7RMK7w6I=", "VMKjwoPCvxYX", "YcKow5lB", "DQwYw6I9w6xxK8OgwpLCrx4=", "w7HDtH/CrxPCtwxYwrVvW8OfEgvCqE5RPmE=", "Jy1lwqQ=", "HxYfw6Ui", "wox+w5BF", "wpJFw6LCn04=", "RMOJw7fCtsKRw5vCnxU=", "w6NMHTUW", "w7UPw5XCrGY4D8O1", "ZgVTIMKuwrQz", "w7LCgU5/", "w5TDicKkwpfDkC7CpkgCw7Fewo1xag==", "ccKAwo4/w7TCgsO6NE0hAcONw63CkcOtSCUmwqw=", "Ng4sbjsE", "wq4EbcOjwoY=", "wrPDvTDDowIAGnBcwqnDqsOyw6E=", "bsOLw6HCow==", "w7DDmcK2wofDnTrCvQ==", "woFlw5FQw4s=", "VcOyw57CkMKy", "csKJwqXCqQoea8OKNQ==", "woXClMOPGMK+VF7Dg8O/", "XsOew7A=", "w5HDqFjDvw==", "IkzDtMKJw7t0Uw==", "CV/Dv8KMw6N0", "w4QDNzsVaAU=", "A0PDs8KZw4JY", "FgolXx0=", "wqPCvsOpDsKiXQ==", "wrfDsDLDtSI7C3NCwp/CuQ==", "w7EGw4TChHoK", "w79AGTcMLw==", "w4ZnRcKa", "w7nDkcKPVcO4fVTCvMKwwrljw4XCnA==", "SA1DP8K+wrUz", "DQ4XUwQ=", "wqPDpT7DtwI=", "AkjDs8KKw79l", "wqcqbcOowp9EAMO4wqQ=", "wq5bw6PCnw==", "PyvCszQ=", "wrTCkQTCjR7Dm8Oo", "NMO8a8O+DHbDmQ==", "wqQjWcOGwp8=", "w4bCr8K3wo4=", "ISfCriQqKBFww7oSw4XCpTo=", "wp9bBzVYRnM=", "w47DlcKrwpfDqj0=", "w7HDtH/CrxPCtwxYwrVvW8OfEgvCqE5RPg==", "S8OMw6HCow==", "wqRqwoYuw5bCmMOIw7c=", "w7zDn8O3UhfClsKcw48=", "w51xwq5S", "wqDDpmrCi8Kow4hu", "w5fCgjkI", "KSV1wrsnwqbDiw==", "PDbChQvDvsOSw4bChw==", "w6/DuGLCvzHCpA==", "S8OAPgdK", "NyECKg==", "wpjClsOQEg==", "d8OMw7E=", "wpHDhcOJeynDkA==", "XDjCuXXCmsOhYEotw790w4U/w7Zow5TCq1Y=", "w7fCjSYuwpg=", "CUnCsj3DrQ==", "woUlNw==", "w73ChFR7dw==", "JRo2ZQQFIR4=", "JkPCtx/Dkg==", "w5XDnsKxwpbDvTnCslA=", "wqXCmB3CmCc=", "NinCrw7DlA==", "wrQ5IHXDrsOEw5B7", "XzfCrEDCscOs", "ZsOJw7bCvsKNw73CoRzDm8KuQTY=", "5LuA5Lq355ue5a6LecK/AlLCnueCruWHkA==", "KAYxfhMILQLDk8OewrjCg1nDtsOawozDhsOm", "TsOqw5TCncKG", "OUXDtcKa", "I37Dj8KEw6U=", "wrRVBzddRA==", "wqrClhEewrw=", "w7lmWcKZ", "QcKow4NQcjV2w7oLNFgU", "wrzDuCzDpCAiFnl1wpPDu8O+w7h/G13CuVo=", "w7rDlsK+VQ==", "VDYsw4MDw5nDkxRLWAvCosOzPyRKw6LCmA==", "VDYsw4M=", "w4N9wrtUwq7CiGU=", "wopbw7TCjnJHwpo=", "GyvCpCU=", "w5bCgVlu", "WzMww4Qhw7vDnx1iYhrCrsOq", "w7ZXAjEd", "w6UXw5HCv2AwDcO9w67DnQ==", "w7ZOw7I4QnRJwrPDkA==", "XsOWw6Y=", "woHDjMKICBfDu8Oiw5HDp8Os", "YMOtJSFeB8KVE2w=", "w5ltRMKBw4dHwrvDjh0=", "f8Oew61TbAIK", "wohXwqEcw6o=", "woNNDDRa", "wovDi8OacyDDjx4yw6U=", "YcOrJytTH8KP", "w5jCo8K0wp/CisKDw7E=", "OwUew6E=", "wr7ClsOTE8K+XW4=", "WsOZw7dTaz4=", "OEjDvcK4w54=", "w4JsJCkUPg==", "X8Oew7VCew8UGMOfPA==", "wp/CmcOUA8KHcQ==", "w7jDoEDDv8Onw5nCrH4=", "a8KzAlA=", "wrggdMOiwr9BMcOt", "WDjCrmQ=", "a8KzGkHCv8O7w6rDug==", "w47DlcK1wpbDrjvCiw==", "wrggbMOzwrRJL8O8wpPClSDCuMKGaxlrwqzCng==", "RglOM8KIwqk=", "bcKDwrzCoyobWsOf", "GEDCtSnDkMKZw7/Cii7DncKFQcKv", "w7TDkcKrwpfDoyrCoQ==", "PDXCriU9", "wqY4NX3Dmw==", "wqrCnQfCnDjDjsOdYcKvw4TDvsOkCTDDjQnCv8Op", "w6QDLyoLdBgD", "Hg3ClRMKBRZEw4A=", "wrklP3/DssOBw4J2", "wrczwrHDssOIfMONMA==", "wot9w5LCqWVtwqFO", "wpjDuHzCmsKUw7FpfHQ=", "wpggbMOzwqFdLA==", "RgVLMcKwwqguVg==", "w7dIw64zS2o=", "w6dKw5gabQ==", "54+V5L6D5Ze/5q2p", "wrTDjsOETis=", "GU7CsiM=", "SjLDjsKGHjc=", "wrczwqnDo8ODdMOTIXfCmix8UcOEwponwpIy", "FsOweA==", "RMOJw7vCp8K7", "w5oFw5zCn3M=", "w4nCqsKtworCsg==", "LExPwqnDmw==", "wrwiIH/DjMOew5Bu", "wqbCnsOe", "w53DhcKxwpzDnyPCskU=", "wqdEwr4Y", "wqEpLG4=", "woDDpmrCi8K9w5xtakVyGTDDk1UiwpfCiAM=", "b8KLwrrCow==", "w7hDFhEINw==", "CAhfwpMu", "w7oMw5c=", "54y/5Ly/5ZSz5q+D", "RDrDm8KoFTc=", "csObw7pOUBA2EsOOJzcU", "wpRhw57CsUY=", "Ly0JKsORJMKRw6bCoUs2EsKzwrHCrgnCr08=", "WjYxw5M=", "QMOkABlQ", "w4ULw5/Cug==", "w5g5w4nCj0M=", "ICsUOMO/Ig==", "KAYpbzUNHwTDt8OIwqvCiUfDncO9woHDm8Oke8OZwq5/", "cDY7w5I=", "EsOufsO+Aw==", "wqrCjwYqwofCnsK/w5A=", "wq8zwrfDssO2", "w4ZnXcKLw6dCworDmw==", "ERMDw6Ep", "Z8O5MitcJ8K+AWo=", "wpnDmsOafTU=", "w6TCnMK9wrjCvA==", "TDHDjMKE", "w6FMGDc1", "UcOEw77CosKG", "woLCgMOYEsK8dHXDkcO5", "a8KIwpE+w5Y=", "wrglOg==", "TCg6w5Iqw7TDlwJ6", "w5tMAyQ2LsKS", "wr5JOzhTS3VFSsOjOg==", "wozDn8ONeSLDtzM=", "IhTCvwnDtw==", "w7vDsWPCtCY=", "F3tawozDhg==", "Z8O5MitcP8K4", "RMOXw7fCtsKXw78=", "wrTDgcObaB7DljI=", "w4oYKzg0eBk=", "w4zCgiQYwpDCqQ==", "NyEJKg==", "wqVKwrIZw4DCpMO4w4kSw7/CsQ==", "w7DDqGDCrz3Cgg5IwpN/bsOeAR3CgEpB", "w5PDnsKAwp3Dri3Cv1k=", "wobChcOSEMKgXW/DkQ==", "w7oMw5HCqXEL", "IQtnwpwK", "w6bDjcKoR8O3WQ7Cu8KwwqJkwoTCmEPCi2E=", "wrDDjcKuJA8=" ];

(function(_0x27d365, _0x5c3ef7) {
    var _0x3ff7c9 = function(_0x3501f1) {
        while (--_0x3501f1) {
            _0x27d365["push"](_0x27d365["shift"]());
        }
    };
    _0x3ff7c9(++_0x5c3ef7);
})(__0xc19de, 118);

var _0x5c21 = function(_0x699a09, _0x5ba0fa) {
    _0x699a09 = _0x699a09 - 0;
    var _0x2179cf = __0xc19de[_0x699a09];
    if (_0x5c21["initialized"] === undefined) {
        (function() {
            var _0x147c4a = typeof window !== "undefined" ? window : typeof process === "object" && typeof require === "function" && typeof global === "object" ? global : this;
            var _0x5a5c3b = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
            _0x147c4a["atob"] || (_0x147c4a["atob"] = function(_0x4da1f7) {
                var _0x183884 = String(_0x4da1f7)["replace"](/=+$/, "");
                for (var _0x2d3c09 = 0, _0x435ca7, _0x14c3ce, _0x36f8dd = 0, _0x36b739 = ""; _0x14c3ce = _0x183884["charAt"](_0x36f8dd++); ~_0x14c3ce && (_0x435ca7 = _0x2d3c09 % 4 ? _0x435ca7 * 64 + _0x14c3ce : _0x14c3ce, 
                _0x2d3c09++ % 4) ? _0x36b739 += String["fromCharCode"](255 & _0x435ca7 >> (-2 * _0x2d3c09 & 6)) : 0) {
                    _0x14c3ce = _0x5a5c3b["indexOf"](_0x14c3ce);
                }
                return _0x36b739;
            });
        })();
        var _0x100966 = function(_0x730a20, _0x3804c4) {
            var _0x2aad2a = [], _0x9967d5 = 0, _0x301c8b, _0xfa13a3 = "", _0x305065 = "";
            _0x730a20 = atob(_0x730a20);
            for (var _0x46aad6 = 0, _0x44a888 = _0x730a20["length"]; _0x46aad6 < _0x44a888; _0x46aad6++) {
                _0x305065 += "%" + ("00" + _0x730a20["charCodeAt"](_0x46aad6)["toString"](16))["slice"](-2);
            }
            _0x730a20 = decodeURIComponent(_0x305065);
            for (var _0x5a56af = 0; _0x5a56af < 256; _0x5a56af++) {
                _0x2aad2a[_0x5a56af] = _0x5a56af;
            }
            for (_0x5a56af = 0; _0x5a56af < 256; _0x5a56af++) {
                _0x9967d5 = (_0x9967d5 + _0x2aad2a[_0x5a56af] + _0x3804c4["charCodeAt"](_0x5a56af % _0x3804c4["length"])) % 256;
                _0x301c8b = _0x2aad2a[_0x5a56af];
                _0x2aad2a[_0x5a56af] = _0x2aad2a[_0x9967d5];
                _0x2aad2a[_0x9967d5] = _0x301c8b;
            }
            _0x5a56af = 0;
            _0x9967d5 = 0;
            for (var _0xd76f84 = 0; _0xd76f84 < _0x730a20["length"]; _0xd76f84++) {
                _0x5a56af = (_0x5a56af + 1) % 256;
                _0x9967d5 = (_0x9967d5 + _0x2aad2a[_0x5a56af]) % 256;
                _0x301c8b = _0x2aad2a[_0x5a56af];
                _0x2aad2a[_0x5a56af] = _0x2aad2a[_0x9967d5];
                _0x2aad2a[_0x9967d5] = _0x301c8b;
                _0xfa13a3 += String["fromCharCode"](_0x730a20["charCodeAt"](_0xd76f84) ^ _0x2aad2a[(_0x2aad2a[_0x5a56af] + _0x2aad2a[_0x9967d5]) % 256]);
            }
            return _0xfa13a3;
        };
        _0x5c21["rc4"] = _0x100966;
        _0x5c21["data"] = {};
        _0x5c21["initialized"] = !![];
    }
    var _0x34790c = _0x5c21["data"][_0x699a09];
    if (_0x34790c === undefined) {
        if (_0x5c21["once"] === undefined) {
            _0x5c21["once"] = !![];
        }
        _0x2179cf = _0x5c21["rc4"](_0x2179cf, _0x5ba0fa);
        _0x5c21["data"][_0x699a09] = _0x2179cf;
    } else {
        _0x2179cf = _0x34790c;
    }
    return _0x2179cf;
};

!function() {
    var _0x5cbf5e = {
        APvhe: _0x5c21("0x0", "bi^r"),
        OGqCP: _0x5c21("0x1", "ggF#"),
        IMZBD: _0x5c21("0x2", "2^mQ"),
        IXDAP: function _0x351a7a(_0x2f54b5, _0x4d50d5) {
            return _0x2f54b5 + _0x4d50d5;
        },
        CmFWi: function _0x29cf64(_0x1cb21a, _0x24b261) {
            return _0x1cb21a == _0x24b261;
        },
        tmNDT: _0x5c21("0x3", "m*dV"),
        HwkID: _0x5c21("0x4", "ikmV"),
        KZcgp: function _0x20ce3c(_0x1cb94a, _0x552c8a) {
            return _0x1cb94a != _0x552c8a;
        },
        GjnXq: function _0x598683(_0x34bffb, _0x494568) {
            return _0x34bffb != _0x494568;
        },
        gfJxQ: function _0x1d6526(_0x5534af, _0x28a49d) {
            return _0x5534af(_0x28a49d);
        },
        JpmvT: _0x5c21("0x5", "Yd[7"),
        AeCDZ: function _0x451e26(_0x702aff, _0x3514f5) {
            return _0x702aff == _0x3514f5;
        },
        NLazi: _0x5c21("0x6", "rvGE"),
        OMYdm: function _0x3508b7(_0x428c5a, _0x1674a3) {
            return _0x428c5a - _0x1674a3;
        },
        Excdu: "init Banner fail !!!",
        aBKdl: function _0x575e60(_0x515e22, _0x38207c) {
            return _0x515e22 % _0x38207c;
        },
        AmHqy: function _0x41791a(_0x238dc1, _0x98ec40) {
            return _0x238dc1 + _0x98ec40;
        },
        MppGy: function _0x520c92(_0x2040ec, _0x4fce37) {
            return _0x2040ec > _0x4fce37;
        },
        XaZBW: "bannerOnLoad",
        sfkms: function _0x46ce2c(_0x22df85, _0x458148) {
            return _0x22df85 / _0x458148;
        },
        hrvrh: _0x5c21("0x7", "[GWR"),
        QBOSW: function _0x1ac462(_0x15198d, _0x43a9b0) {
            return _0x15198d + _0x43a9b0;
        },
        PFHIu: _0x5c21("0x8", "NTNj"),
        PtnKV: function _0x5680f5(_0x1b1c81, _0x1c79bf) {
            return _0x1b1c81 == _0x1c79bf;
        },
        Wcbua: "baseRequest:",
        GwXse: _0x5c21("0x9", "[GWR"),
        nIWQo: function _0x2a97e9(_0xa3fbab, _0x4a2102) {
            return _0xa3fbab(_0x4a2102);
        },
        ujjML: _0x5c21("0xa", "oZew"),
        VYscd: _0x5c21("0xb", "Uf[4"),
        SVZHA: function _0x54e176(_0x2c7b0b, _0x53ba72) {
            return _0x2c7b0b >= _0x53ba72;
        },
        BYtIH: function _0x5e82b8(_0x5727f9) {
            return _0x5727f9();
        },
        Bajpj: _0x5c21("0xc", "(b*P"),
        pFNIz: function _0x4b0195(_0xeed0bc, _0x4965bf) {
            return _0xeed0bc != _0x4965bf;
        },
        yERin: _0x5c21("0xd", "dZ3i"),
        ZOVgB: function _0x5f1122(_0x5f1b3b, _0x25a98a, _0x51a303) {
            return _0x5f1b3b(_0x25a98a, _0x51a303);
        },
        TgvCm: _0x5c21("0xe", "fIRP"),
        AJTBt: function _0x541aaa(_0x3e7cad, _0x26d071) {
            return _0x3e7cad < _0x26d071;
        },
        ixMFu: "https://oss.vipwzs.com/417/547/2019-11-04/30a9f7891e7e53c33f2f76cdfc771093.png",
        BzACe: _0x5c21("0xf", "(b*P"),
        KuCTo: function _0x28a1b9(_0x405d5f) {
            return _0x405d5f();
        },
        kdAdC: function _0x331a50(_0x5753fe, _0xe2ba26) {
            return _0x5753fe > _0xe2ba26;
        },
        pNkLI: function _0x475dc0(_0x2aa7d4, _0x105885) {
            return _0x2aa7d4 / _0x105885;
        },
        mbBVn: function _0x3b5332(_0x51651d, _0x27b2fe) {
            return _0x51651d == _0x27b2fe;
        },
        hkBsK: function _0x3fe205(_0x44bb23, _0x3e449f) {
            return _0x44bb23 == _0x3e449f;
        },
        NjIDX: "showBanner--- bannershow",
        ztpDt: function _0x56a480(_0xa98ab3, _0x446922) {
            return _0xa98ab3 < _0x446922;
        },
        oLuPI: function _0x53d718(_0x21605c, _0x3265c9) {
            return _0x21605c(_0x3265c9);
        },
        hhlCG: function _0xeea700(_0x3d3fd2, _0x221528) {
            return _0x3d3fd2 * _0x221528;
        },
        eHUXv: function _0x89a003(_0x3b95c9) {
            return _0x3b95c9();
        },
        fKzsN: function _0x20654a(_0x523edb, _0x62db34) {
            return _0x523edb == _0x62db34;
        },
        SiKEQ: function _0x4d085f(_0x2fb2e2) {
            return _0x2fb2e2();
        },
        duFWG: _0x5c21("0x10", "t@qE"),
        XcSJd: function _0x59ffc1(_0x2bbb99, _0x51a133) {
            return _0x2bbb99 == _0x51a133;
        },
        IURHp: function _0x279561(_0x521bf0) {
            return _0x521bf0();
        },
        wXPvv: _0x5c21("0x11", "oM#F"),
        fwfQh: function _0xd8bc1f(_0xe42b0c, _0x3cd50b) {
            return _0xe42b0c != _0x3cd50b;
        },
        pHsuW: function _0x2e6e0d(_0x55944b, _0xa1927d) {
            return _0x55944b != _0xa1927d;
        },
        RKjdg: function _0x3a577d(_0x1ed643, _0xc13c22) {
            return _0x1ed643 * _0xc13c22;
        },
        HGpGs: function _0x2cb74b(_0x2069cd, _0x558104) {
            return _0x2069cd + _0x558104;
        },
        bhxjT: function _0x2559ac(_0x34e366, _0x198d19) {
            return _0x34e366 + _0x198d19;
        },
        GwQVr: "&share_id=",
        xIVzI: "&inviter_openid=",
        KMnMg: function _0x509654(_0x559fc7, _0x41a929) {
            return _0x559fc7 + _0x41a929;
        },
        dFSbz: function _0x2f8a65(_0x15e826) {
            return _0x15e826();
        },
        kKwZq: _0x5c21("0x12", "dZ3i"),
        bWJUw: function _0x44a14e(_0x49fa0f) {
            return _0x49fa0f();
        },
        cQUlZ: "startShare",
        AQgJy: function _0x5c76a5(_0x181dae, _0x5f1203) {
            return _0x181dae + _0x5f1203;
        },
        IzFlJ: _0x5c21("0x13", "4E!&"),
        KnUsp: _0x5c21("0x14", "m[2Q"),
        ptZsM: _0x5c21("0x15", "&D4Y"),
        sWrcq: function _0x5bd866(_0x42a456) {
            return _0x42a456();
        },
        ViTqJ: _0x5c21("0x16", "%9(3"),
        oJUXJ: _0x5c21("0x17", "9GG)"),
        KbgPu: function _0x9f1fbe(_0x4dd041, _0xe9a654) {
            return _0x4dd041 == _0xe9a654;
        },
        KMknY: function _0x3b9096(_0x4c0ae7, _0x3d621e) {
            return _0x4c0ae7 < _0x3d621e;
        },
        VDfYD: function _0x4e4b08(_0x168d54, _0x4e6a9e) {
            return _0x168d54 / _0x4e6a9e;
        },
        SzuPG: function _0x5e87bb(_0x2a60d3, _0x5232c9) {
            return _0x2a60d3 - _0x5232c9;
        },
        sGJJL: function _0x5ce48c(_0x375653) {
            return _0x375653();
        },
        oJuxM: _0x5c21("0x18", "Uv]h"),
        kXCeg: _0x5c21("0x19", "MjE8"),
        JAILr: function _0xea9b65(_0x2a61ac, _0x3854ad) {
            return _0x2a61ac < _0x3854ad;
        },
        LssVA: _0x5c21("0x1a", "MjE8"),
        htkTX: function _0x4c4906(_0x20d6b1, _0x946f96) {
            return _0x20d6b1 < _0x946f96;
        },
        gZeMG: function _0x4a3ed4(_0xaa221c) {
            return _0xaa221c();
        },
        ukEfl: _0x5c21("0x1b", "8&%b"),
        XpeQd: "range=",
        TmpXf: _0x5c21("0x1c", "iAvi"),
        pAEgj: function _0x11921e(_0x452766) {
            return _0x452766();
        },
        kgjWr: _0x5c21("0x1d", "*$CX"),
        tJypk: _0x5c21("0x1e", "t@qE"),
        kDNLg: function _0x1b2bb1(_0x40b7db, _0x146034) {
            return _0x40b7db >= _0x146034;
        },
        RviOy: _0x5c21("0x1f", "nnjN"),
        haTzC: _0x5c21("0x20", "iAvi"),
        ssQmA: function _0x6ff0e2(_0x1b4806, _0x57bcec) {
            return _0x1b4806 == _0x57bcec;
        },
        EObOf: _0x5c21("0x21", "rvGE"),
        iuOUq: function _0x4e8430(_0x401102, _0x3b1901) {
            return _0x401102 + _0x3b1901;
        },
        hLWjT: "/Sdk/User/exportZs",
        TzCvC: function _0x48d510(_0x589fc6, _0x9b8f06) {
            return _0x589fc6 * _0x9b8f06;
        },
        zjmdZ: function _0x53ede1(_0x2ac5ef, _0x21dd0c) {
            return _0x2ac5ef > _0x21dd0c;
        },
        RvQtN: function _0xde6b47(_0x248a80, _0x169c30) {
            return _0x248a80 / _0x169c30;
        },
        fOreF: function _0x132e83(_0x599a36, _0x497afe) {
            return _0x599a36 > _0x497afe;
        },
        fsUpl: function _0x1c56ca(_0x351eab, _0x540f7a) {
            return _0x351eab(_0x540f7a);
        },
        BivXW: function _0x240281(_0x45db28, _0x3334f5) {
            return _0x45db28 + _0x3334f5;
        },
        GIaoF: function _0x26cfa8(_0x13d226, _0x41e986) {
            return _0x13d226(_0x41e986);
        },
        DSbdr: function _0x355fba(_0x3f2ffc, _0x818a2) {
            return _0x3f2ffc(_0x818a2);
        },
        FPWFm: function _0x58dd9e(_0x4d5e01, _0x55879c) {
            return _0x4d5e01(_0x55879c);
        },
        RRVwV: function _0x519fcb(_0x2e14a0, _0xac62a5) {
            return _0x2e14a0 < _0xac62a5;
        },
        HcNdg: function _0x4e48c1(_0x5a5e83, _0x36331a) {
            return _0x5a5e83 / _0x36331a;
        },
        wPlnU: function _0x3384e4(_0xa31815, _0x5901c2) {
            return _0xa31815(_0x5901c2);
        },
        XMBlM: function _0x1cb111(_0x56dbe5, _0x51a4ad) {
            return _0x56dbe5 > _0x51a4ad;
        },
        zkTNr: function _0x4e17cb(_0x272998, _0x5dfa3c, _0x2cc967) {
            return _0x272998(_0x5dfa3c, _0x2cc967);
        },
        lWbwH: _0x5c21("0x22", "JzeF"),
        mAgdv: "Scene",
        InVGZ: "view/LoadUI.ts",
        DXMHZ: _0x5c21("0x23", "9T1Q"),
        xzudo: _0x5c21("0x24", "LDjf"),
        WYszI: "Image",
        uJiFb: _0x5c21("0x25", ")RsM"),
        AuYoI: _0x5c21("0x26", "m*dV"),
        iavkb: _0x5c21("0x27", "UOab"),
        NzhQC: _0x5c21("0x28", "&D4Y"),
        zifwz: "Music/fail.mp3",
        rRKAJ: function _0x81e491(_0x35c17d, _0x4e4c25) {
            return _0x35c17d + _0x4e4c25;
        },
        NoOFR: _0x5c21("0x29", "t@qE"),
        vEPHj: _0x5c21("0x2a", "al%z"),
        lCXkU: _0x5c21("0x2b", "ggF#"),
        zdYKC: _0x5c21("0x2c", "bBqT"),
        LDphh: _0x5c21("0x2d", "gT6R"),
        UHvUR: _0x5c21("0x2e", "MjE8"),
        euoxj: _0x5c21("0x2f", "jQ6r"),
        NBoqz: "Plane003",
        jdhzr: "wutai",
        BGKeP: _0x5c21("0x30", "al%z"),
        wTWuc: _0x5c21("0x31", "gT6R"),
        TkiHt: function _0x424f46(_0xe0499e) {
            return _0xe0499e();
        },
        Bbxid: function _0x334618(_0x7ab9fa, _0x2bba26) {
            return _0x7ab9fa < _0x2bba26;
        },
        wRnta: function _0x21bb20(_0x2cd24a, _0x1f6d4d) {
            return _0x2cd24a + _0x1f6d4d;
        },
        JqcqT: function _0x3ad01a(_0x49cb3c, _0x1da837) {
            return _0x49cb3c < _0x1da837;
        },
        LOVzI: function _0x3d9e45(_0x1bdd36, _0x1ac315) {
            return _0x1bdd36 + _0x1ac315;
        },
        SXrYM: function _0xc1504d(_0xefd263, _0x197bad) {
            return _0xefd263 == _0x197bad;
        },
        kmkAv: function _0xbb6b8d(_0x2652a8, _0x8f97fc) {
            return _0x2652a8 || _0x8f97fc;
        },
        WHEBt: function _0x32bea5(_0x33c8ad, _0x1689c7) {
            return _0x33c8ad || _0x1689c7;
        },
        HcVTs: function _0x554dbe(_0x5ae0d7, _0x48d673) {
            return _0x5ae0d7 < _0x48d673;
        },
        LLNfe: function _0x3254d2(_0x13d493, _0x2e9cb7) {
            return _0x13d493 + _0x2e9cb7;
        },
        EWsWZ: function _0x4fe720(_0xa21f4c, _0x25b855) {
            return _0xa21f4c == _0x25b855;
        },
        OmeJM: "floor",
        faJaP: _0x5c21("0x32", "omJG"),
        ggiLI: function _0x7ec084(_0xf86cf1, _0x5b4bc3) {
            return _0xf86cf1 == _0x5b4bc3;
        },
        zSKcB: "kedu",
        BLSOj: _0x5c21("0x33", "4E!&"),
        MiuDq: _0x5c21("0x34", "hOwa"),
        YTtbg: _0x5c21("0x35", "oM#F"),
        ZGGKp: function _0x33f7e2(_0x58fd05, _0x19aecc) {
            return _0x58fd05 != _0x19aecc;
        },
        PODWc: function _0x3bf6ef(_0x5c3ee6, _0x5533fb) {
            return _0x5c3ee6 != _0x5533fb;
        },
        WYaJJ: function _0x4cb122(_0x310ea8, _0x34344d) {
            return _0x310ea8 != _0x34344d;
        },
        wfXuJ: _0x5c21("0x36", "&D4Y"),
        jOqLo: "score.json",
        zdTjv: function _0x1fbd52(_0x7e1ed3, _0x4c5bc4) {
            return _0x7e1ed3 / _0x4c5bc4;
        },
        ekhki: function _0xa452b6(_0x4745e3, _0x11cc95) {
            return _0x4745e3 < _0x11cc95;
        },
        UCSHf: _0x5c21("0x37", "rvGE"),
        hvpyw: function _0x59217e(_0x5b332b, _0x3dc9a8) {
            return _0x5b332b > _0x3dc9a8;
        },
        GjKaT: function _0x11156d(_0x384d5d, _0x1d8685) {
            return _0x384d5d < _0x1d8685;
        },
        IxIRs: function _0x3a0347(_0xee1033, _0x3028aa) {
            return _0xee1033 >= _0x3028aa;
        },
        LRyIJ: _0x5c21("0x38", "Uv]h"),
        hhihN: function _0x30acfc(_0x460785, _0x4f7188) {
            return _0x460785 <= _0x4f7188;
        },
        iQphq: function _0x23c4d0(_0x16be56, _0x2ea9f2) {
            return _0x16be56 < _0x2ea9f2;
        },
        UYkaa: function _0xcdda31(_0xa80056, _0x2d1fdc) {
            return _0xa80056 >= _0x2d1fdc;
        },
        ZVwwc: function _0x7a6535(_0x47692c, _0x52d3f4) {
            return _0x47692c >= _0x52d3f4;
        },
        GUnJO: function _0x3b2e5b(_0x34b66b, _0x983463) {
            return _0x34b66b >= _0x983463;
        },
        ySbbz: function _0x57a4f1(_0x4d35b2, _0x51bd10) {
            return _0x4d35b2 >= _0x51bd10;
        },
        MRcqY: function _0x4a8b61(_0x3086ff, _0x399cfd) {
            return _0x3086ff - _0x399cfd;
        },
        YEgHC: function _0x52697c(_0x269b1e, _0x1ae7cd) {
            return _0x269b1e - _0x1ae7cd;
        },
        Ifwla: function _0xea4283(_0x2d16ef, _0x5abb0c) {
            return _0x2d16ef * _0x5abb0c;
        },
        IYsuA: _0x5c21("0x39", "9GG)"),
        EWeGE: "dancing",
        AiuJX: "liftwalk",
        GddUr: _0x5c21("0x3a", "oM#F"),
        DTAOo: "pickingwalk",
        ClynZ: _0x5c21("0x3b", "NYmF"),
        jHdSc: _0x5c21("0x3c", "2CMv"),
        dnOQq: _0x5c21("0x3d", "omJG"),
        SrSDd: "hotdog",
        esDIm: function _0x1fb4f4(_0xbdb415, _0x48043e) {
            return _0xbdb415 == _0x48043e;
        },
        PhBdl: function _0x53bc59(_0x31f12a, _0x1787a5) {
            return _0x31f12a == _0x1787a5;
        },
        nDIZh: "Tomato",
        Joscu: function _0x5460c2(_0x16e44e, _0x27a0c7) {
            return _0x16e44e - _0x27a0c7;
        },
        VgWWH: function _0x5a5202(_0xc6487b, _0x532fd5) {
            return _0xc6487b == _0x532fd5;
        },
        cqGHv: function _0x4ae944(_0x25b373, _0x1b8553) {
            return _0x25b373 < _0x1b8553;
        },
        wQUDW: "104714",
        KFyRG: _0x5c21("0x3e", "nnjN"),
        OFlfp: "6F3E0C",
        lBWnQ: function _0x3d480d(_0x16cae9, _0x501f3f) {
            return _0x16cae9 / _0x501f3f;
        },
        kteSN: function _0x5e33c1(_0x564650, _0x174b10) {
            return _0x564650 / _0x174b10;
        },
        bBWMm: _0x5c21("0x3f", "Uv]h"),
        aCebN: _0x5c21("0x40", "hOwa"),
        zePzj: _0x5c21("0x41", "([2%"),
        hPWYm: function _0x86d28f(_0xc15b6b, _0x4a42f4) {
            return _0xc15b6b == _0x4a42f4;
        },
        oJNxb: function _0x2302c7(_0x4e0207, _0x58dd8a) {
            return _0x4e0207 - _0x58dd8a;
        },
        VnvCV: _0x5c21("0x42", "([2%"),
        HMhCY: _0x5c21("0x43", "GLHs"),
        CpTGr: function _0x58a433(_0x41d084, _0x26b689) {
            return _0x41d084 - _0x26b689;
        },
        lpfAU: function _0x4b729e(_0x3b7865, _0x10c3d6) {
            return _0x3b7865 * _0x10c3d6;
        },
        uInSy: function _0x118ece(_0x303dee, _0x3c6dd3) {
            return _0x303dee / _0x3c6dd3;
        },
        YVAeQ: function _0xd7f25b(_0x1974be, _0x1036a7) {
            return _0x1974be < _0x1036a7;
        },
        kZWNX: function _0x1833b4(_0x4be5ec, _0x583410) {
            return _0x4be5ec + _0x583410;
        },
        kwZFe: function _0x50b5e2(_0x22a9a9, _0x2adcd1) {
            return _0x22a9a9 - _0x2adcd1;
        },
        fuxyV: _0x5c21("0x44", "9GG)"),
        qnAGF: "prefab/icon.json",
        pDBjz: function _0x199667(_0x34cb23, _0x594f6f) {
            return _0x34cb23 % _0x594f6f;
        },
        GCYPd: function _0x457416(_0x1e5e2a, _0x5ebab2) {
            return _0x1e5e2a > _0x5ebab2;
        },
        ZBINO: function _0x27b029(_0x34b8e4, _0x141757) {
            return _0x34b8e4 == _0x141757;
        },
        WTiXc: function _0x34d955(_0x3b2cd3, _0x2107f3) {
            return _0x3b2cd3 == _0x2107f3;
        },
        ZsLjQ: function _0x20a8b5(_0x500c72, _0x92ac30) {
            return _0x500c72 == _0x92ac30;
        },
        ZNEpo: function _0x1b0ca4(_0x333e3a, _0x53fcd5) {
            return _0x333e3a >= _0x53fcd5;
        },
        LVpvv: "gameExport1",
        XmXhm: _0x5c21("0x45", "4yM]"),
        dBTND: _0x5c21("0x46", "2(Lk"),
        NcDWW: function _0x64e2a9(_0x2040d6, _0x2cb029) {
            return _0x2040d6 - _0x2cb029;
        },
        fcArf: "right",
        IadUb: function _0x700a4c(_0x1bd244, _0xc57265) {
            return _0x1bd244 - _0xc57265;
        },
        LOaMh: _0x5c21("0x47", "GLHs"),
        vrMGb: function _0x436fc7(_0x21025b, _0x5905d0) {
            return _0x21025b - _0x5905d0;
        },
        dfbHX: function _0x255698(_0x39c269, _0x1fe2ad) {
            return _0x39c269 - _0x1fe2ad;
        },
        LflRg: "Pic",
        qEJNO: _0x5c21("0x48", "Uf[4"),
        iuHLC: "man",
        pcTje: _0x5c21("0x49", "%9(3"),
        UfnHx: "topUI",
        yDWOg: "list",
        Bgqok: _0x5c21("0x4a", "(LPe"),
        XNiIx: _0x5c21("0x4b", "JzeF"),
        PXDFK: function _0x50739d(_0x3c65fe, _0x50cda5) {
            return _0x3c65fe < _0x50cda5;
        },
        MRztR: "gamebox/tit_sl.png",
        jYEMv: _0x5c21("0x4c", "LDjf"),
        UmhpI: "page1",
        UgQLk: function _0x513ba6(_0x51e0f7, _0x51e54f) {
            return _0x51e0f7 / _0x51e54f;
        },
        TutDp: "light",
        tCOhI: _0x5c21("0x4d", "(b*P"),
        tWkcm: _0x5c21("0x4e", "NTNj"),
        dNxzI: function _0x528038(_0xc30021, _0xdfac0a) {
            return _0xc30021 > _0xdfac0a;
        },
        AgiLi: function _0x499cef(_0xa19b60, _0x21e6aa) {
            return _0xa19b60 != _0x21e6aa;
        },
        MBGCA: function _0x418b5d(_0x4bce53, _0x437a61) {
            return _0x4bce53 == _0x437a61;
        },
        sBJpf: function _0x4ad1fa(_0x1b6998, _0x2f427c) {
            return _0x1b6998 != _0x2f427c;
        },
        uCOFS: "chest",
        lUVWD: function _0x5664cc(_0x4dab00, _0x573da8) {
            return _0x4dab00 / _0x573da8;
        },
        JgNlV: function _0x3b325e(_0x15a9a4, _0x264b63) {
            return _0x15a9a4 * _0x264b63;
        },
        nhkvI: _0x5c21("0x4f", "9T1Q"),
        pjFAl: function _0x41dcb9(_0x4ae3f1, _0x31ff39) {
            return _0x4ae3f1 / _0x31ff39;
        },
        JPzfD: "Pro_Value",
        ToITf: _0x5c21("0x50", "2^mQ"),
        DihWl: _0x5c21("0x51", "CvOU"),
        EvCIv: function _0x58da92(_0x161135, _0x37f541) {
            return _0x161135 != _0x37f541;
        },
        EVjAe: _0x5c21("0x52", "r#o%"),
        ziTeS: function _0x1d995b(_0xfdbae8, _0x30b9a9) {
            return _0xfdbae8 - _0x30b9a9;
        },
        UMkwX: _0x5c21("0x53", "NTNj"),
        soyag: _0x5c21("0x54", "GLHs"),
        zIbgu: function _0x31a473(_0x104be6, _0x35ce9b) {
            return _0x104be6 == _0x35ce9b;
        },
        YRrmJ: function _0x52b136(_0x45adcd, _0x5100d0) {
            return _0x45adcd == _0x5100d0;
        },
        nxnjg: function _0x23b176(_0x2daeb9, _0x5ac7c4) {
            return _0x2daeb9(_0x5ac7c4);
        },
        YsVdI: function _0x422305(_0x369273, _0x5797b6) {
            return _0x369273 - _0x5797b6;
        },
        qdeOH: function _0xd2abd4(_0x154e8d, _0xbae438) {
            return _0x154e8d - _0xbae438;
        },
        JZRkA: _0x5c21("0x55", "ggF#"),
        whesR: function _0x3529cb(_0x2c7b58, _0x5a3141) {
            return _0x2c7b58 == _0x5a3141;
        },
        rWLGQ: function _0x18b9fc(_0x16e9a7, _0xd67840) {
            return _0x16e9a7 == _0xd67840;
        },
        OAYMm: function _0x4ca0db(_0x454437, _0x391ff6) {
            return _0x454437 * _0x391ff6;
        },
        zMrdu: _0x5c21("0x56", "ggF#"),
        IaUYP: function _0x1319fb(_0x513654, _0x20352c) {
            return _0x513654 * _0x20352c;
        },
        iOFJe: _0x5c21("0x57", "LDjf"),
        ISUir: function _0x494a69(_0x16b9c8, _0x2dc680) {
            return _0x16b9c8 == _0x2dc680;
        },
        PKqfn: function _0x54dfaa(_0x1f5141, _0x249526) {
            return _0x1f5141 == _0x249526;
        },
        bgXMC: _0x5c21("0x58", "%9(3"),
        NZyBW: function _0x8f3219(_0x140826, _0x4de81c) {
            return _0x140826 == _0x4de81c;
        },
        JapBH: function _0x26a401(_0x1f9387, _0x4b1cb1) {
            return _0x1f9387 == _0x4b1cb1;
        },
        wQywz: function _0x57f776(_0x5ea5e7, _0x2414ae) {
            return _0x5ea5e7 * _0x2414ae;
        },
        gDNPh: _0x5c21("0x59", "4yM]"),
        bFSTj: "游戏设置成功",
        VsmNa: "游戏设置失败",
        apdoo: function _0x231578(_0x269841, _0x53c5f3) {
            return _0x269841 >= _0x53c5f3;
        },
        jVAtX: function _0x4f26f4(_0x5310ae, _0x4d2d78, _0x5f0ff1) {
            return _0x5310ae(_0x4d2d78, _0x5f0ff1);
        },
        zXvkt: _0x5c21("0x5a", "TOp9"),
        ejUHh: _0x5c21("0x5b", "(b*P"),
        SuRDH: "view/HomeUI.ts",
        qLtlk: function _0x2f8c18(_0x1f794b, _0x478f2b, _0x3c91cf) {
            return _0x1f794b(_0x478f2b, _0x3c91cf);
        },
        FCdkB: function _0x579033(_0xdbecf2, _0x28577b, _0x418403) {
            return _0xdbecf2(_0x28577b, _0x418403);
        },
        pBshJ: function _0x4ccad7(_0x53017a, _0x3f361b, _0x4937f4) {
            return _0x53017a(_0x3f361b, _0x4937f4);
        },
        TDrra: "view/gameExport2.ts",
        EcCQX: function _0x5ef689(_0x46b1d3, _0x19d323, _0x69ec7f) {
            return _0x46b1d3(_0x19d323, _0x69ec7f);
        },
        UOOYK: "view/likeExport.ts",
        sZuHI: function _0xf2a1f9(_0x29e520, _0x13e7dd, _0x129700) {
            return _0x29e520(_0x13e7dd, _0x129700);
        },
        DUaGd: _0x5c21("0x5c", "m*dV"),
        kBjkU: _0x5c21("0x5d", "m*dV"),
        tuFGi: _0x5c21("0x5e", "4E!&"),
        DxlWF: _0x5c21("0x5f", "hOwa"),
        sBlSR: "resultUI",
        LIPOn: _0x5c21("0x60", "9T1Q"),
        TYOZb: _0x5c21("0x61", "UOab"),
        NQHJp: _0x5c21("0x62", "jQ6r"),
        JkuAH: _0x5c21("0x63", "&D4Y"),
        VRkyP: _0x5c21("0x64", "dZ3i"),
        irDaI: "pig",
        yMNOX: "left"
    };
    "use strict";
    class _0x574ca6 {}
    _0x574ca6["UIType"] = {
        loadUI: 0,
        gameExport1: _0x5cbf5e[_0x5c21("0x65", "9T1Q")],
        gameExport2: _0x5cbf5e[_0x5c21("0x66", "4yM]")],
        gameExport3: _0x5cbf5e[_0x5c21("0x67", "al%z")],
        homeUI: _0x5cbf5e[_0x5c21("0x68", "al%z")],
        gameUI: "gameUI",
        reviveUI: "reviveUI",
        resultUI: _0x5cbf5e[_0x5c21("0x69", "ikmV")],
        hitBoxUI1: _0x5c21("0x6a", "rvGE"),
        likeExport: _0x5c21("0x6b", "2^mQ"),
        hitBoxUI2: _0x5c21("0x6c", "ggF#")
    }, _0x574ca6[_0x5c21("0x6d", "TOp9")] = _0x5c21("0x6e", "ggF#"), _0x574ca6[_0x5c21("0x6f", "(LPe")] = [ null, "homeUI", _0x5cbf5e["LIPOn"], _0x5cbf5e[_0x5c21("0x70", "8&%b")], _0x5c21("0x71", "oZew"), "gameExport1", _0x5cbf5e[_0x5c21("0x72", "GLHs")] ];
    const _0x2beed9 = _0x5cbf5e["NQHJp"], _0x591f79 = _0x5cbf5e[_0x5c21("0x73", "NTNj")], _0x35a343 = "", _0xf4314e = _0x5c21("0x74", "2CMv"), _0x393570 = "", _0x4aecda = _0x5cbf5e[_0x5c21("0x75", "bBqT")], _0x1478e6 = "1";
    class _0x554550 {
        constructor() {}
        static [_0x5c21("0x76", "ggF#")](_0x5dfc00) {
            let _0x4c08fb;
            this["miniprogram_id"] = _0x5dfc00[_0x5c21("0x77", "JzeF")] || 0, this[_0x5c21("0x78", "MjE8")] = this[_0x5c21("0x79", "t@qE")] = _0x5dfc00[_0x5c21("0x7a", "GLHs")] || "";
            let _0x23b222 = wx["getSystemInfoSync"](), _0x866b2b = ((_0x4c08fb = wx[_0x5c21("0x7b", "JzeF")]())[_0x5c21("0x7c", "([2%")] || {})[_0x5c21("0x7d", "ikmV")] || "", _0x44fd87 = _0x23b222[_0x5c21("0x7e", "([2%")] || "", _0x3f2c91 = _0x4c08fb["query"];
            this[_0x5c21("0x7f", "[GWR")] = _0x23b222["brand"] + "-" + _0x23b222[_0x5c21("0x80", "9GG)")], 
            this[_0x5c21("0x81", "t@qE")] = _0x3f2c91["inviter_id"] || "", this["channel_id"] = _0x3f2c91[_0x5c21("0x82", "rvGE")] || "", 
            this[_0x5c21("0x83", "9T1Q")] = _0x3f2c91[_0x5c21("0x84", "LDjf")] || 0, this["scene"] = _0x4c08fb["scene"] || 0, 
            this[_0x5c21("0x85", "omJG")] = _0x866b2b, this[_0x5c21("0x86", "4yM]")] = _0x44fd87, 
            this[_0x5c21("0x87", "LDjf")] = "", this["reg_channel_id"] = "", this["reg_time"] = 0, 
            this[_0x5c21("0x88", "dZ3i")] = _0x5cbf5e[_0x5c21("0x89", "[GWR")], this["userInit"]();
        }
        static [_0x5c21("0x8a", "jQ6r")]() {
            return !(!this[_0x5c21("0x8b", "4E!&")] || !this[_0x5c21("0x8c", "TOp9")]) || (console["error"](_0x5c21("0x8d", "al%z")), 
            !1);
        }
        static ["userInit"]() {
            if (this["checkInitComplete"]()) {
                let _0x1266b9 = {
                    miniprogram_id: this["miniprogram_id"],
                    uid: this["uid"],
                    openid: this[_0x5c21("0x8e", "jQ6r")],
                    scene: this["scene"],
                    share_id: this[_0x5c21("0x8f", "fIRP")] || 0,
                    channel_id: this[_0x5c21("0x90", "m*dV")],
                    appId: this["appid"],
                    version: this["version"],
                    inviter_id: this["inviter_id"],
                    client: this[_0x5c21("0x91", "JzeF")],
                    sdk_version: this[_0x5c21("0x92", "t@qE")]
                }, _0xec42bb = _0x59e495 => {
                    this["reg_channel_id"] = _0x59e495[_0x5c21("0x93", "NYmF")][_0x5c21("0x94", "nnjN")], 
                    this[_0x5c21("0x95", "[GWR")] = _0x59e495[_0x5c21("0x96", "oM#F")][_0x5c21("0x97", "GLHs")], 
                    this[_0x5c21("0x98", "(LPe")] = _0x59e495[_0x5c21("0x99", "GLHs")][_0x5c21("0x9a", "Yd[7")];
                };
                this[_0x5c21("0x9b", "(b*P")]("/Stat/Index/init", _0x1266b9, _0xec42bb);
            }
        }
        static [_0x5c21("0x9c", "2CMv")](_0x3dae8b, _0x355dc9) {}
        static [_0x5c21("0x9d", "4yM]")](_0x3a9d3a) {
            if (this[_0x5c21("0x9e", "bBqT")]()) {
                let _0x205598 = _0x3a9d3a["id"];
                if (!_0x205598) return void console[_0x5c21("0x9f", "jQ6r")](_0x5cbf5e["OGqCP"]);
                let _0x192bb6 = {
                    id: _0x205598,
                    miniprogram_id: this[_0x5c21("0xa0", "GLHs")],
                    openid: this[_0x5c21("0xa1", "UOab")],
                    channel_id: this[_0x5c21("0xa2", "LDjf")],
                    scene: this[_0x5c21("0xa3", "ggF#")],
                    images_id: _0x3a9d3a["images_id"] || 0,
                    reg_time: this["reg_time"],
                    sdk_version: this[_0x5c21("0xa4", "*$CX")]
                }, _0x597769 = function(_0x4873a4) {};
                this["request"](_0x5cbf5e[_0x5c21("0xa5", "([2%")], _0x192bb6, _0x597769);
            }
        }
        static [_0x5c21("0xa6", "&D4Y")](_0x225d38) {
            if (this["checkInitComplete"]()) {
                let _0x5c157d = _0x225d38["id"];
                if (!_0x5c157d) return void console["error"](_0x5cbf5e[_0x5c21("0xa7", "[GWR")]);
                let _0xe1de13 = {
                    id: _0x5c157d,
                    miniprogram_id: this["miniprogram_id"],
                    openid: this[_0x5c21("0xa8", "2(Lk")],
                    channel_id: this[_0x5c21("0xa9", "GLHs")],
                    scene: this[_0x5c21("0xaa", "JzeF")],
                    images_id: _0x225d38[_0x5c21("0xab", "NTNj")] || 0,
                    reg_time: this[_0x5c21("0xac", "TOp9")],
                    sdk_version: this[_0x5c21("0xad", "NTNj")]
                }, _0x5ed9a9 = function(_0x41e4d6) {
                    console[_0x5c21("0xae", "JzeF")](_0x41e4d6["msg"]);
                };
                this[_0x5c21("0xaf", "2(Lk")]("/Stat/Index/box", _0xe1de13, _0x5ed9a9);
            }
        }
    }
    _0x554550["formatURL"] = function(_0x3d2f22) {
        return _0x5cbf5e[_0x5c21("0xb0", "UOab")](_0x5c21("0xb1", "oM#F"), _0x3d2f22);
    }, _0x554550[_0x5c21("0xb2", "dZ3i")] = function(_0xedf543, _0x5b851d, _0x12be50, _0x5468c0 = !1) {
        var _0x285738 = {
            ZwNte: function _0x5b2ada(_0x5f5d09, _0x566731) {
                return _0x5f5d09 >= _0x566731;
            },
            GQeIU: function _0xcb36f9(_0x1d318a, _0x30b5aa) {
                return _0x5cbf5e[_0x5c21("0xb3", "4yM]")](_0x1d318a, _0x30b5aa);
            }
        };
        let _0x1c9579 = this;
        _0xedf543 = this[_0x5c21("0xb4", "UOab")](_0xedf543);
        let _0x2dda21 = _0x5b851d;
        var _0x28aaf1 = new XMLHttpRequest();
        if (_0x28aaf1["onreadystatechange"] = function() {
            if (_0x285738[_0x5c21("0xb5", "hOwa")](_0x28aaf1[_0x5c21("0xb6", "rvGE")], 200) && _0x28aaf1["status"] < 400 && _0x285738[_0x5c21("0xb7", "NTNj")](4, _0x28aaf1["readyState"])) {
                let _0xedf543 = _0x28aaf1[_0x5c21("0xb8", "fIRP")], _0x5b851d = _0x1c9579[_0x5c21("0xb9", "dZ3i")](_0xedf543);
                _0x12be50 && _0x12be50(_0x5b851d);
            }
        }, _0x28aaf1[_0x5c21("0xba", ")RsM")](_0x5cbf5e[_0x5c21("0xbb", "([2%")], _0xedf543, !0), 
        _0x5468c0) _0x28aaf1["setRequestHeader"](_0x5c21("0xbc", "2(Lk"), _0x5cbf5e[_0x5c21("0xbd", "NTNj")]), 
        _0x28aaf1[_0x5c21("0xbe", "bBqT")](JSON["stringify"](_0x2dda21)); else {
            let _0xedf543 = "";
            for (let _0x5b851d in _0x2dda21) _0x5cbf5e["KZcgp"]("?", _0xedf543) && _0x5cbf5e[_0x5c21("0xbf", "bi^r")]("", _0xedf543) && (_0xedf543 += "&"), 
            _0xedf543 += _0x5cbf5e["IXDAP"](_0x5b851d + "=", _0x5cbf5e[_0x5c21("0xc0", "CvOU")](encodeURIComponent, _0x2dda21[_0x5b851d]));
            _0x28aaf1[_0x5c21("0xc1", "(b*P")](_0x5c21("0xc2", "ikmV"), _0x5c21("0xc3", "4yM]")), 
            _0x28aaf1[_0x5c21("0xc4", "ikmV")](_0xedf543);
        }
        console[_0x5c21("0xc5", "4yM]")](_0x5cbf5e[_0x5c21("0xc6", "JzeF")], _0x2dda21);
    }, _0x554550[_0x5c21("0xc7", "AQRo")] = function(_0x20a73d) {
        if (_0x5cbf5e[_0x5c21("0xc8", "2CMv")](_0x5cbf5e["NLazi"], _0x20a73d) || "" == _0x20a73d) return;
        return JSON["parse"](_0x20a73d);
    };
    var _0x2c7420 = Laya["Browser"][_0x5c21("0xc9", "8&%b")]["wx"];
    class _0xf06c16 {
        constructor() {
            this[_0x5c21("0xca", "iAvi")] = 0, this["isShow"] = !1, this[_0x5c21("0xcb", "LDjf")] = 0, 
            this[_0x5c21("0xcc", "m[2Q")] = [];
        }
        static get [_0x5c21("0xcd", "Yd[7")]() {
            return _0xf06c16["_inst"] || (_0xf06c16[_0x5c21("0xce", "r#o%")] = new _0xf06c16()), 
            _0xf06c16[_0x5c21("0xcf", "(LPe")];
        }
        ["init"](_0x5de5fe, _0x2ffa52, _0x9a34b1) {
            for (var _0x2eaaf5 in this[_0x5c21("0xd0", "4E!&")] = _0x5de5fe, this[_0x5c21("0xd1", "efPG")] = 0, 
            this["refreshTime"] = 1e3 * _0x2ffa52 || 5e3, this[_0x5c21("0xd2", "fIRP")] = _0x9a34b1, 
            this[_0x5c21("0xd3", "2^mQ")] = window["wx"]["getSystemInfoSync"](), this[_0x5c21("0xd4", "Yd[7")]) this["initBanner"](this[_0x5c21("0xd5", "efPG")][_0x2eaaf5]);
            Laya[_0x5c21("0xd6", "*$CX")]["loop"](20, this, this[_0x5c21("0xd7", "Uv]h")]), 
            window["wx"] && (window["wx"]["onShow"](_0x1f0162 => {
                this[_0x5c21("0xd8", "rvGE")](_0x1f0162);
            }), window["wx"][_0x5c21("0xd9", "AQRo")](_0x153ae8 => {
                this[_0x5c21("0xda", "ggF#")](_0x153ae8);
            }));
        }
        [_0x5c21("0xdb", "NTNj")]() {
            this[_0x5c21("0xdc", "fIRP")] && Laya["timer"]["currTimer"] > this[_0x5c21("0xdd", "&D4Y")] && this[_0x5c21("0xde", "jQ6r")]();
        }
        [_0x5c21("0xdf", "m*dV")](_0x45ed01) {
            console[_0x5c21("0xe0", "AQRo")](_0x5c21("0xe1", "nnjN"), _0x45ed01), this[_0x5c21("0xe2", "9T1Q")] && this[_0x5c21("0xe3", "rvGE")]();
        }
        [_0x5c21("0xe4", "8&%b")](_0x203d64) {
            console[_0x5c21("0xe5", "Uv]h")](_0x5c21("0xe6", "Yd[7"), _0x203d64);
        }
        [_0x5c21("0xe7", "4E!&")](_0x48ab24) {
            if (null == _0x48ab24) return;
            let _0x407f90 = _0x2c7420[_0x5c21("0xe8", "ikmV")]({
                adUnitId: _0x48ab24,
                adIntervals: 30,
                style: {
                    left: 0,
                    top: 0,
                    width: this[_0x5c21("0xe9", "oM#F")][_0x5c21("0xea", "4yM]")]
                }
            });
            _0x407f90[_0x5c21("0xeb", "4yM]")](_0x2d6503 => {
                _0x407f90[_0x5c21("0xec", "TOp9")][_0x5c21("0xed", "r#o%")] = 120, _0x407f90[_0x5c21("0xee", "Yd[7")][_0x5c21("0xef", "9GG)")] = _0x5cbf5e[_0x5c21("0xf0", "MjE8")](this[_0x5c21("0xf1", "([2%")]["windowHeight"], Math["floor"](_0x2d6503["height"])) - 3, 
                _0x407f90[_0x5c21("0xf2", "GLHs")][_0x5c21("0xf3", "hOwa")] = 0;
            }), _0x407f90["onError"](_0x29bc46 => {
                console["log"](_0x48ab24 + _0x5cbf5e[_0x5c21("0xf4", "Uf[4")], _0x29bc46);
            }), _0x407f90["onLoad"](_0x40064c => {
                console[_0x5c21("0xe5", "Uv]h")](_0x5c21("0xf5", "TOp9")), _0x407f90[_0x5c21("0xf6", "9GG)")]();
                let _0x2f3e30 = {
                    bannerAd: _0x407f90,
                    isShow: !1,
                    num: 0
                };
                this["allBanner"]["push"](_0x2f3e30);
            });
        }
        ["changeBanner"]() {
            this["bannerIdex"] = _0x5cbf5e[_0x5c21("0xf7", "([2%")](_0x5cbf5e[_0x5c21("0xf8", "4E!&")](this[_0x5c21("0xf9", "AQRo")], 1), this[_0x5c21("0xfa", "Uv]h")]["length"]), 
            this["showBanner"]();
        }
        ["showBanner"]() {
            if (this[_0x5c21("0xfb", "*$CX")](), this[_0x5c21("0xfc", "ggF#")] = !0, _0x5cbf5e["MppGy"](this["allBanner"]["length"], 0) && this[_0x5c21("0xfd", "dZ3i")][this[_0x5c21("0xca", "iAvi")]]) {
                let _0x456bec = this[_0x5c21("0xfe", "hOwa")][this[_0x5c21("0xff", "m*dV")]];
                _0x456bec[_0x5c21("0x100", "UOab")] && _0x456bec[_0x5c21("0x101", "ggF#")][_0x5c21("0x102", "ggF#")](), 
                _0x456bec["isShow"] = !0, _0x456bec[_0x5c21("0x103", "2^mQ")] += 1, this[_0x5c21("0x104", "m*dV")] = Laya[_0x5c21("0x105", "2^mQ")][_0x5c21("0x106", "[GWR")] + this[_0x5c21("0x107", "Uf[4")];
            } else this[_0x5c21("0x108", "CvOU")] = _0x5cbf5e[_0x5c21("0x109", "CvOU")](Laya[_0x5c21("0x10a", "8&%b")][_0x5c21("0x10b", "dZ3i")], 1e3);
        }
        [_0x5c21("0x10c", "NYmF")]() {
            if (this[_0x5c21("0x10d", "dZ3i")] = !1, _0x5cbf5e[_0x5c21("0x10e", "2^mQ")](this[_0x5c21("0x10f", "4E!&")][_0x5c21("0x110", "dZ3i")], 0)) for (var _0x33f628 in this[_0x5c21("0x111", "2(Lk")]) {
                let _0x49fdac = this[_0x5c21("0x112", "ikmV")][_0x33f628];
                _0x49fdac["isShow"] && (_0x49fdac[_0x5c21("0x113", "TOp9")] && _0x49fdac[_0x5c21("0x100", "UOab")][_0x5c21("0x114", "CvOU")](), 
                _0x49fdac["isShow"] = !1, _0x49fdac["num"] > this[_0x5c21("0x115", "nnjN")] && this[_0x5c21("0x116", "&D4Y")](_0x33f628));
            }
        }
        [_0x5c21("0x117", "bBqT")](_0x33e787) {
            var _0x2d350a = {
                DkiRN: function _0x3ab8c8(_0xe3bf81, _0x84aa46) {
                    return _0x5cbf5e["OMYdm"](_0xe3bf81, _0x84aa46);
                }
            };
            let _0x24bb96 = this[_0x5c21("0x118", "(b*P")][_0x33e787];
            _0x24bb96[_0x5c21("0x119", "(LPe")] = 0, _0x24bb96[_0x5c21("0x11a", "dZ3i")] && _0x24bb96["bannerAd"]["destroy"](), 
            _0x24bb96[_0x5c21("0x11b", "hOwa")] = null;
            let _0x538f9f = _0x2c7420["createBannerAd"]({
                adUnitId: this[_0x5c21("0x11c", ")RsM")][_0x33e787],
                adIntervals: 30,
                style: {
                    left: 0,
                    top: 0,
                    width: this["system"][_0x5c21("0x11d", "jQ6r")]
                }
            });
            _0x538f9f["onResize"](_0x520ba7 => {
                _0x538f9f["style"][_0x5c21("0x11e", "(LPe")] = 120, _0x538f9f[_0x5c21("0xec", "TOp9")][_0x5c21("0x11f", "ikmV")] = _0x2d350a[_0x5c21("0x120", "oM#F")](this[_0x5c21("0x121", "Uf[4")][_0x5c21("0x122", "efPG")], Math["floor"](_0x520ba7[_0x5c21("0x123", "nnjN")])) - 3, 
                _0x538f9f["style"]["left"] = 0;
            }), _0x538f9f[_0x5c21("0x124", "bBqT")](_0x5d8876 => {
                console[_0x5c21("0x125", "al%z")](this[_0x5c21("0x126", "9GG)")][_0x33e787] + _0x5cbf5e[_0x5c21("0x127", "(b*P")], _0x5d8876);
            }), _0x538f9f["onLoad"](_0x4541d2 => {
                console[_0x5c21("0x128", "2^mQ")](_0x5cbf5e[_0x5c21("0x129", "AQRo")]), _0x538f9f[_0x5c21("0x12a", "efPG")](), 
                _0x24bb96[_0x5c21("0x12b", "(b*P")] = _0x538f9f;
            });
        }
    }
    var _0x1fa80d = Laya[_0x5c21("0x12c", "JzeF")]["window"]["wx"];
    class _0x420221 {
        constructor() {
            this["PixY"] = 2, this["login_count"] = 0, this["max_count"] = 0, this[_0x5c21("0x12d", "NTNj")] = 130, 
            this[_0x5c21("0x12e", "bBqT")] = _0x2beed9, this[_0x5c21("0x12f", "t@qE")] = _0x591f79, 
            this[_0x5c21("0x130", "oM#F")] = _0xf4314e, this["clientVersion"] = _0x5c21("0x131", "hOwa"), 
            this[_0x5c21("0x132", "9T1Q")] = {
                box_info: []
            }, this[_0x5c21("0x133", "r#o%")] = !1, this[_0x5c21("0x134", "([2%")] = _0x35a343, 
            this[_0x5c21("0x135", "ikmV")] = _0x35a343, this[_0x5c21("0x136", "NTNj")] = _0x393570, 
            this[_0x5c21("0x137", "nnjN")] = !1, this[_0x5c21("0x138", "9GG)")] = !1, this["gameName"] = "", 
            _0x1fa80d && (this[_0x5c21("0x139", ")RsM")] = _0x1fa80d[_0x5c21("0x13a", "UOab")](), 
            this[_0x5c21("0x13b", "iAvi")] = _0x1fa80d["getLaunchOptionsSync"](), this["PixY"] = _0x5cbf5e["sfkms"](Laya[_0x5c21("0x13c", "oZew")][_0x5c21("0x13d", "2(Lk")], this[_0x5c21("0x13e", "t@qE")][_0x5c21("0x13f", "nnjN")])), 
            this[_0x5c21("0x140", "bi^r")] = {
                openid: "",
                session_key: "",
                head_cookie: "",
                inviter_id: "",
                nickname: "",
                headimgurl: "",
                id: "",
                is_new: !0,
                area: ""
            }, this[_0x5c21("0x141", "NTNj")] = _0xf4314e, this["miniID"] = _0x591f79;
        }
        static [_0x5c21("0x142", "rvGE")]() {
            return _0x420221["_inst"] || (_0x420221[_0x5c21("0x143", "oZew")] = new _0x420221()), 
            _0x420221["_inst"];
        }
        ["initzs"](_0x3e7e2b = this["userInfo"]["openid"]) {
            const _0x198d58 = this;
            let _0x26b1b, _0x1c7a0d, _0x420313, _0x27c5d0 = _0x1fa80d[_0x5c21("0x144", "oZew")]();
            _0x1c7a0d = _0x5cbf5e[_0x5c21("0x145", "dZ3i")](_0x5cbf5e[_0x5c21("0x146", "jQ6r")](_0x27c5d0[_0x5c21("0x147", "([2%")], "-"), _0x27c5d0[_0x5c21("0x148", "[GWR")]), 
            _0x420313 = _0x1fa80d[_0x5c21("0x149", "rvGE")](), this[_0x5c21("0x14a", "TOp9")] = _0x420313[_0x5c21("0x14b", "r#o%")];
            let _0x44886a = _0x420313["referrerInfo"] || {}, _0x16bf55 = _0x420313["query"], _0xcb6931 = _0x44886a["appId"] || "";
            _0x27c5d0["version"];
            if (_0x1fa80d[_0x5c21("0x14c", "t@qE")]({
                success: _0x30cf32 => {
                    _0x26b1b = _0x30cf32[_0x5c21("0x14d", "rvGE")], _0x554550["init"]({
                        miniId: _0x198d58[_0x5c21("0x12f", "t@qE")],
                        openid: _0x3e7e2b
                    });
                }
            }), _0x198d58[_0x5c21("0x14e", "&D4Y")]) {
                let _0x53d53d = {
                    application_id: _0x198d58[_0x5c21("0x14f", "2CMv")],
                    version: _0x198d58[_0x5c21("0x150", "([2%")],
                    scene: _0x420313[_0x5c21("0x151", "AQRo")],
                    openid: _0x3e7e2b,
                    share_id: _0x16bf55["share_id"],
                    channel_id: _0x16bf55["channel_id"],
                    scene_id: _0x420313["scene"],
                    is_new: _0x198d58[_0x5c21("0x152", "&D4Y")][_0x5c21("0x153", "8&%b")],
                    app_id: _0xcb6931
                };
                _0x198d58["baseExternalRequest"](_0x5cbf5e[_0x5c21("0x154", "JzeF")], _0x5cbf5e[_0x5c21("0x155", "hOwa")](_0x198d58[_0x5c21("0x156", ")RsM")], _0x5cbf5e[_0x5c21("0x157", "Yd[7")]), _0x53d53d);
            }
        }
        [_0x5c21("0x158", "fIRP")](_0x8924d2, _0x19e0fa, _0x125421, _0x53d0d1 = null, _0x5d3719 = null) {
            var _0xa76828 = {
                bqJvG: _0x5cbf5e[_0x5c21("0x159", "rvGE")]
            };
            const _0x3e25e3 = this;
            _0x1fa80d && _0x1fa80d["request"]({
                url: _0x19e0fa,
                method: _0x8924d2,
                header: {
                    "content-type": _0x5c21("0x15a", "efPG"),
                    cookie: _0x3e25e3[_0x5c21("0x15b", "2^mQ")][_0x5c21("0x15c", "omJG")],
                    version: _0x3e25e3["clientVersion"],
                    appid: this[_0x5c21("0x15d", "omJG")]
                },
                data: _0x125421,
                success(_0x49b980) {
                    _0x5cbf5e[_0x5c21("0x15e", "jQ6r")](200, _0x49b980[_0x5c21("0x15f", "4E!&")][_0x5c21("0x160", "JzeF")]) ? _0x53d0d1 && _0x53d0d1(_0x49b980["data"], _0x49b980[_0x5c21("0x161", "MjE8")]) : (console[_0x5c21("0x162", "bBqT")](_0x5cbf5e["QBOSW"](_0x5cbf5e[_0x5c21("0x163", "t@qE")](_0x5cbf5e["Wcbua"] + _0x8924d2, ",url:") + _0x19e0fa + _0x5cbf5e[_0x5c21("0x164", "&D4Y")], _0x49b980["data"][_0x5c21("0x165", "AQRo")])), 
                    _0x5d3719 && _0x5cbf5e[_0x5c21("0x166", "nnjN")](_0x5d3719, _0x49b980));
                },
                fail() {
                    _0x5d3719 && _0x5d3719(_0xa76828["bqJvG"]);
                }
            });
        }
        [_0x5c21("0x167", "ikmV")](_0x400073, _0x21af63) {
            var _0x35399e = {
                rXFPh: function _0x3943df(_0x4006c8, _0xdd5923) {
                    return _0x5cbf5e["SVZHA"](_0x4006c8, _0xdd5923);
                },
                HXiSg: function _0x49d45c(_0x3eb588, _0x1ae7cf, _0x38a2c8) {
                    return _0x3eb588(_0x1ae7cf, _0x38a2c8);
                }
            };
            if (_0x5cbf5e[_0x5c21("0x168", "Uf[4")](null, _0x1fa80d)) return _0x400073();
            const _0x41abaa = this;
            let _0x4b65ea = _0x41abaa["luach"][_0x5c21("0x169", "UOab")][_0x5c21("0x16a", "9GG)")] ? _0x41abaa["luach"][_0x5c21("0x16b", "[GWR")]["inviter_id"] : "";
            if (_0x41abaa[_0x5c21("0x16c", "*$CX")] = _0x41abaa[_0x5c21("0x16d", "&D4Y")]["scene"], 
            _0x41abaa[_0x5c21("0x16e", "ggF#")]) _0x1fa80d["login"]({
                pkgName: "",
                success(_0x440c5a) {
                    _0x41abaa[_0x5c21("0x16f", "oM#F")] = _0x440c5a["code"], _0x41abaa[_0x5c21("0x170", "rvGE")] = _0x440c5a[_0x5c21("0x171", "*$CX")];
                },
                fail() {},
                complete() {
                    _0x41abaa["ttLogin"](_0x400073, _0x21af63);
                }
            }); else {
                function _0x2f327c() {
                    _0x35399e[_0x5c21("0x172", "4E!&")](setTimeout, () => {
                        _0x35399e["rXFPh"](_0x41abaa["login_count"], _0x41abaa[_0x5c21("0x173", "ggF#")]) ? _0x21af63 && _0x21af63() : (_0x41abaa[_0x5c21("0x174", "NYmF")](_0x400073, _0x21af63), 
                        console["log"](_0x5c21("0x175", "&D4Y"), _0x41abaa[_0x5c21("0x176", "8&%b")]), _0x41abaa[_0x5c21("0x177", "t@qE")] += 1);
                    }, 300);
                }
                _0x1fa80d[_0x5c21("0x178", "GLHs")]({
                    pkgName: "",
                    success(_0x5bf0ef) {
                        var _0x52bb16 = {
                            kRlJh: function _0x3a60a4(_0x2555e4, _0xf05ce9) {
                                return _0x2555e4(_0xf05ce9);
                            },
                            Tcvco: function _0x4ce0b5(_0x3d7bf5) {
                                return _0x3d7bf5();
                            }
                        };
                        _0x41abaa[_0x5c21("0x179", "CvOU")] = _0x5bf0ef[_0x5c21("0x17a", "2^mQ")];
                        let _0x476d14 = {
                            code: _0x5bf0ef[_0x5c21("0x17b", "8&%b")]
                        };
                        _0x4b65ea && (_0x476d14[_0x5c21("0x17c", "9T1Q")] = _0x4b65ea), _0x41abaa[_0x5c21("0x17d", "al%z")](_0x5c21("0x17e", "8&%b"), _0x5cbf5e[_0x5c21("0x17f", "Uf[4")], JSON[_0x5c21("0x180", "Yd[7")](_0x476d14), (_0x4e3399, _0x288769) => {
                            200 == _0x4e3399[_0x5c21("0x181", "gT6R")] ? (_0x41abaa[_0x5c21("0x182", "*$CX")]["openid"] = _0x4e3399[_0x5c21("0x183", "fIRP")][_0x5c21("0x184", "Uf[4")], 
                            _0x41abaa["userInfo"][_0x5c21("0x185", "UOab")] = _0x4e3399["data"]["session_key"], 
                            _0x41abaa["userInfo"]["inviter_id"] = _0x4b65ea, _0x41abaa["userInfo"]["head_cookie"] = _0x288769[_0x5c21("0x186", "al%z")], 
                            _0x41abaa["userInfo"]["id"] = _0x4e3399[_0x5c21("0x187", "m[2Q")]["id"], _0x41abaa[_0x5c21("0x188", "m*dV")][_0x5c21("0x189", "t@qE")] = _0x4e3399["data"]["area"], 
                            _0x41abaa[_0x5c21("0x18a", "Uv]h")]["is_new"] = _0x4e3399[_0x5c21("0x18b", "UOab")][_0x5c21("0x18c", "Yd[7")], 
                            console[_0x5c21("0x18d", "TOp9")](_0x4e3399[_0x5c21("0x18e", "(b*P")]["id"]), _0x400073 && _0x52bb16[_0x5c21("0x18f", "GLHs")](_0x400073, _0x4e3399), 
                            console["log"](_0x41abaa["userInfo"][_0x5c21("0x190", "hOwa")]), _0x41abaa["initzs"](_0x41abaa[_0x5c21("0x191", "TOp9")][_0x5c21("0x192", "bi^r")]), 
                            _0x1fa80d[_0x5c21("0x193", "dZ3i")](_0x41abaa[_0x5c21("0x194", "4E!&")][_0x5c21("0x195", "m*dV")])) : _0x52bb16[_0x5c21("0x196", "oZew")](_0x2f327c);
                        }, _0x21c283 => {
                            _0x2f327c();
                        });
                    },
                    fail() {
                        _0x2f327c();
                    },
                    complete() {}
                });
            }
        }
        [_0x5c21("0x197", "JzeF")](_0x26f276, _0x3787bc, _0x2aff63) {
            var _0x1f5079 = {
                QTjFF: function _0x3e92e8(_0x549d89, _0x2ba0cd) {
                    return _0x549d89 != _0x2ba0cd;
                },
                CtsvK: "设置游戏数据成功",
                OLMAy: function _0x33ea6d(_0x5b3020, _0x3d6b75) {
                    return _0x5cbf5e[_0x5c21("0x198", "jQ6r")](_0x5b3020, _0x3d6b75);
                },
                NCrdf: function _0x22b1b4(_0x53f22d, _0x3c2b0a) {
                    return _0x53f22d == _0x3c2b0a;
                },
                Cglii: function _0x7962b5(_0x474272, _0x371561) {
                    return _0x5cbf5e["pFNIz"](_0x474272, _0x371561);
                },
                tMKQS: function _0x17f887(_0x64eb18, _0x36ae9f) {
                    return _0x5cbf5e[_0x5c21("0x199", ")RsM")](_0x64eb18, _0x36ae9f);
                },
                MCDkL: _0x5c21("0x19a", "ggF#")
            };
            const _0xaa1ae1 = this;
            let _0x3575f4 = _0x1fa80d[_0x5c21("0x149", "rvGE")](), _0x313d82 = _0x3575f4[_0x5c21("0x19b", "GLHs")], _0x122088 = _0x3575f4[_0x5c21("0x19c", "&D4Y")] || {};
            var _0x360629 = "";
            if (_0x122088 && _0x122088[_0x5c21("0x19d", "9GG)")] && (_0x360629 = _0x122088[_0x5c21("0x19e", "JzeF")]), 
            _0xaa1ae1[_0x5c21("0x19f", "MjE8")]) {
                let _0x111cef = {
                    application_id: _0xaa1ae1[_0x5c21("0x1a0", "MjE8")],
                    scene: _0x3575f4[_0x5c21("0x1a1", "TOp9")] || 0,
                    version: _0xaa1ae1[_0x5c21("0x1a2", ")RsM")]
                };
                this[_0x5c21("0x1a3", "oZew")]("GET", _0xaa1ae1[_0x5c21("0x1a4", "m[2Q")] + _0x5cbf5e[_0x5c21("0x1a5", "m*dV")], _0x111cef, _0x79cde6 => {
                    _0xaa1ae1[_0x5c21("0x1a6", "omJG")] = _0x79cde6[_0x5c21("0x1a7", "9T1Q")], null != _0x79cde6[_0x5c21("0x1a8", "8&%b")]["ad_videoID"] && (_0xaa1ae1["videoID"] = _0x79cde6[_0x5c21("0x1a9", "Yd[7")][_0x5c21("0x1aa", "LDjf")]), 
                    _0x1f5079["QTjFF"](null, _0x79cde6[_0x5c21("0x96", "oM#F")][_0x5c21("0x1ab", "MjE8")]) && (_0xaa1ae1["bannerID"] = _0x79cde6["data"]["ad_bannerID"]), 
                    console[_0x5c21("0x1ac", "r#o%")](_0x1f5079["CtsvK"], _0x79cde6[_0x5c21("0x1ad", "bBqT")]), 
                    _0x26f276 && _0x1f5079[_0x5c21("0x1ae", "hOwa")](_0x26f276, _0x79cde6), _0x2aff63 && _0x2aff63();
                }, _0x43e686 => {
                    _0x3787bc && _0x3787bc(_0x43e686), _0x2aff63 && _0x5cbf5e[_0x5c21("0x1af", "AQRo")](_0x2aff63);
                });
            } else {
                let _0x47363b = {
                    channel_id: _0x313d82[_0x5c21("0x1b0", "9GG)")] || "",
                    scene: _0x3575f4[_0x5c21("0x1b1", "Yd[7")] || 0,
                    soure_id: _0x360629
                };
                console["log"](_0x5c21("0x1b2", "&D4Y") + JSON[_0x5c21("0x1b3", "bBqT")](_0x47363b)), 
                this[_0x5c21("0x1b4", "dZ3i")](_0x5c21("0x1b5", "2(Lk"), "/setting/config", JSON[_0x5c21("0x1b6", "ikmV")](_0x47363b), _0x862f52 => {
                    _0xaa1ae1[_0x5c21("0x1b7", "oZew")] = _0x862f52["data"], _0x1f5079[_0x5c21("0x1b8", "AQRo")](null, _0xaa1ae1["config"]["share_count"]) && (_0xaa1ae1[_0x5c21("0x1b9", "rvGE")]["share_count"] = 1), 
                    _0x1f5079[_0x5c21("0x1ba", ")RsM")](null, _0x862f52[_0x5c21("0x1bb", "ggF#")][_0x5c21("0x1bc", "fIRP")]) && (_0x1f5079["tMKQS"](_0x1f5079["MCDkL"], typeof _0x862f52[_0x5c21("0x1bd", "bi^r")][_0x5c21("0x1be", "jQ6r")]) ? _0xaa1ae1[_0x5c21("0x1bf", "jQ6r")] = _0x862f52["data"][_0x5c21("0x1c0", "dZ3i")] : _0x1f5079[_0x5c21("0x1c1", "GLHs")](_0x5c21("0x1c2", "bi^r"), typeof _0x862f52[_0x5c21("0x1c3", "gT6R")][_0x5c21("0x1c4", "[GWR")]) && _0x862f52[_0x5c21("0x183", "fIRP")]["ad_videoID"]["length"] > 0 && (_0xaa1ae1[_0x5c21("0x1c5", "(b*P")] = _0x862f52[_0x5c21("0x1c6", "dZ3i")][_0x5c21("0x1c7", "JzeF")][0])), 
                    null != _0x862f52[_0x5c21("0x1c8", "&D4Y")][_0x5c21("0x1c9", "bi^r")] && (_0xaa1ae1[_0x5c21("0x1ca", "NTNj")] = _0x862f52[_0x5c21("0x1c3", "gT6R")]["ad_bannerID"]), 
                    console["log"]("设置游戏数据成功", _0x862f52[_0x5c21("0x1cb", "iAvi")]), _0x26f276 && _0x26f276(_0x862f52), 
                    _0x2aff63 && _0x2aff63();
                }, _0x135f81 => {
                    _0xaa1ae1[_0x5c21("0x1cc", "4yM]")](_0x5cbf5e["Bajpj"]), _0x3787bc && _0x5cbf5e[_0x5c21("0x1cd", "8&%b")](_0x3787bc, _0x135f81), 
                    _0x2aff63 && _0x2aff63();
                });
            }
        }
        ["ttLogin"](_0x37511f, _0x267763) {
            var _0x1a6a22 = {
                juXRa: function _0x473370(_0x4ee298, _0x50ebb2) {
                    return _0x4ee298 in _0x50ebb2;
                },
                JgKnh: _0x5c21("0x1ce", "4E!&"),
                hpJgc: "set-cookie",
                xFTjy: _0x5c21("0x1cf", "CvOU")
            };
            const _0x45946f = this;
            let _0xdf95ca = {
                code: _0x45946f["wxcode"],
                anonymous_code: _0x45946f[_0x5c21("0x1d0", "LDjf")],
                sceneid: _0x45946f[_0x5c21("0x1d1", "([2%")][_0x5c21("0x1d2", "MjE8")]
            };
            _0x45946f["baseRequest"](_0x5cbf5e["tmNDT"], "/user/login", JSON[_0x5c21("0x1d3", "4yM]")](_0xdf95ca), (_0x167930, _0x3b87b0) => {
                if (200 == _0x167930["code"]) {
                    for (var _0x1526ed in _0x45946f[_0x5c21("0x1d4", "ggF#")]) _0x1a6a22[_0x5c21("0x1d5", "2(Lk")](_0x1526ed, _0x167930["data"]) && (_0x45946f[_0x5c21("0x18a", "Uv]h")][_0x1526ed] = _0x167930[_0x5c21("0x1d6", "[GWR")][_0x1526ed]);
                    _0x3b87b0[_0x1a6a22["JgKnh"]] ? _0x45946f[_0x5c21("0x1d7", "r#o%")][_0x5c21("0x1d8", "TOp9")] = _0x3b87b0[_0x5c21("0x1d9", "iAvi")] : _0x45946f["userInfo"][_0x5c21("0x1da", "rvGE")] = _0x3b87b0[_0x1a6a22[_0x5c21("0x1db", "(LPe")]], 
                    console[_0x5c21("0x1dc", "2CMv")](_0x1a6a22["xFTjy"], _0x45946f[_0x5c21("0x140", "bi^r")], _0x167930), 
                    _0x37511f && _0x37511f(_0x167930);
                }
            }, _0x526654 => {
                console[_0x5c21("0x1dd", "jQ6r")](_0x526654), _0x267763 && _0x267763();
            });
        }
        [_0x5c21("0x1de", "Yd[7")](_0x5e7995, _0x22e61a, _0x2d62b1, _0x2cee23, _0x516738) {
            const _0x566209 = this;
            _0x1fa80d && _0x1fa80d[_0x5c21("0x1df", "9T1Q")]({
                url: _0x5cbf5e[_0x5c21("0x1e0", "oZew")](_0x566209[_0x5c21("0x1e1", "2CMv")], _0x22e61a),
                method: _0x5e7995,
                header: {
                    "content-type": _0x5cbf5e["HwkID"],
                    cookie: _0x566209["userInfo"][_0x5c21("0x1e2", "JzeF")],
                    version: _0x566209[_0x5c21("0x1e3", "gT6R")],
                    appid: _0x566209[_0x5c21("0x1e4", "Uf[4")]
                },
                data: _0x2d62b1,
                success(_0x40a4ed) {
                    200 == _0x40a4ed[_0x5c21("0x1e5", "(LPe")]["code"] ? _0x2cee23 && _0x5cbf5e[_0x5c21("0x1e6", "CvOU")](_0x2cee23, _0x40a4ed[_0x5c21("0x1e7", "MjE8")], _0x40a4ed["header"]) : _0x516738 && _0x516738(_0x40a4ed);
                },
                fail() {
                    _0x516738 && _0x5cbf5e[_0x5c21("0x1e8", "AQRo")](_0x516738, _0x5cbf5e[_0x5c21("0x1e9", "[GWR")]);
                }
            });
        }
        [_0x5c21("0x1ea", "CvOU")]() {
            for (var _0xa3a290 = 0; _0x5cbf5e["AJTBt"](_0xa3a290, 21); ++_0xa3a290) {
                var _0x1a3f8d = {
                    appid: "wxf5aff0e346b14167",
                    banner_images: _0x5cbf5e[_0x5c21("0x1eb", "NTNj")],
                    banner_images1: [],
                    id: 189,
                    images: _0x5cbf5e[_0x5c21("0x1ec", "nnjN")],
                    images1: [],
                    images2: "",
                    is_banner: 0,
                    is_best: 0,
                    is_hot: 0,
                    is_multipoint: 1,
                    is_recommend: 1,
                    is_top: 0,
                    frame: 9,
                    name: _0x5cbf5e["QBOSW"](_0x5c21("0x1ed", "iAvi"), _0xa3a290),
                    navigate_type: 1,
                    pageimg: "",
                    path: "",
                    poster: "",
                    target_id: 0,
                    type: 2
                };
                this["config"][_0x5c21("0x1ee", "CvOU")]["push"](_0x1a3f8d);
            }
            this[_0x5c21("0x1ef", "dZ3i")][_0x5c21("0x1f0", "([2%")] = 1, this[_0x5c21("0x1f1", "ggF#")]["open_ad_late"] = 0, 
            this[_0x5c21("0x1f2", "nnjN")][_0x5c21("0x1f3", "m*dV")] = 1, this[_0x5c21("0x1ef", "dZ3i")][_0x5c21("0x1f4", "2^mQ")] = 0, 
            this["config"][_0x5c21("0x1f5", "[GWR")] = 1;
        }
        [_0x5c21("0x1f6", "rvGE")](_0xe53d92) {
            let _0x1336da = this[_0x5c21("0x1f7", "rvGE")][_0x5c21("0x1f8", "Yd[7")][_0x5c21("0x1f9", "iAvi")]("."), _0x1ebd66 = _0xe53d92["split"](".");
            const _0x3c8123 = Math[_0x5c21("0x1fa", "*$CX")](_0x1336da[_0x5c21("0x1fb", "CvOU")], _0x1ebd66["length"]);
            for (;_0x1336da[_0x5c21("0x1fc", "*$CX")] < _0x3c8123; ) _0x1336da[_0x5c21("0x1fd", "iAvi")]("0");
            for (;_0x1ebd66[_0x5c21("0x1fe", "Yd[7")] < _0x3c8123; ) _0x1ebd66["push"]("0");
            for (let _0xe53d92 = 0; _0x5cbf5e["AJTBt"](_0xe53d92, _0x3c8123); _0xe53d92++) {
                const _0x37fe99 = Math[_0x5c21("0x1ff", "AQRo")](_0x5cbf5e[_0x5c21("0x200", "ggF#")](Number, _0x1336da[_0xe53d92])), _0x3ece73 = Math[_0x5c21("0x201", "[GWR")](Number(_0x1ebd66[_0xe53d92]));
                if (_0x37fe99 > _0x3ece73) return 1;
                if (_0x37fe99 < _0x3ece73) return -1;
            }
            return 0;
        }
        [_0x5c21("0x202", "[GWR")](_0x3198a0 = "提示", _0x47cda3 = _0x5c21("0x203", "dZ3i"), _0x3db499 = 2e3) {
            null != _0x1fa80d ? _0x1fa80d["showToast"]({
                title: _0x3198a0,
                icon: _0x47cda3,
                duration: _0x3db499
            }) : _0x5cbf5e[_0x5c21("0x204", "ikmV")](alert, _0x3198a0);
        }
        ["showAlert"](_0x634af7, _0x3b80f7 = "提示", _0x1fd69c) {
            null != _0x1fa80d && _0x1fa80d["showModal"]({
                title: _0x3b80f7,
                content: _0x634af7,
                showCancel: !1,
                success(_0x124f2a) {
                    _0x1fd69c && _0x5cbf5e[_0x5c21("0x205", "2^mQ")](_0x1fd69c, _0x124f2a);
                }
            });
        }
        [_0x5c21("0x206", ")RsM")](_0x1d34fb, _0x482b91 = _0x5c21("0x207", "jQ6r"), _0x52a690, _0x848fb2, _0x1a16a3 = "确认") {
            null != _0x1fa80d && _0x1fa80d[_0x5c21("0x208", "%9(3")]({
                title: _0x482b91,
                content: _0x1d34fb,
                showCancel: !0,
                confirmText: _0x1a16a3,
                success(_0x3d6500) {
                    _0x3d6500[_0x5c21("0x209", "TOp9")] ? _0x52a690 && _0x52a690() : _0x3d6500[_0x5c21("0x20a", "CvOU")] && _0x848fb2 && _0x5cbf5e[_0x5c21("0x20b", "ggF#")](_0x848fb2);
                }
            });
        }
        [_0x5c21("0x20c", "nnjN")]() {
            if (_0x1fa80d) {
                var _0x287871 = _0x1fa80d["getMenuButtonBoundingClientRect"]();
                let _0x5ef19f = this["system"][_0x5c21("0x20d", "CvOU")], _0x23bd7f = Laya[_0x5c21("0x20e", "4yM]")][_0x5c21("0x20f", "9T1Q")] / _0x5ef19f;
                return _0x287871[_0x5c21("0x210", ")RsM")] *= _0x23bd7f, _0x287871[_0x5c21("0x211", "*$CX")] *= _0x23bd7f, 
                console[_0x5c21("0x212", "oZew")](_0x287871), _0x287871;
            }
            return {
                bottom: 84,
                height: 32,
                left: 556,
                right: 365,
                top: 10,
                width: 87
            };
        }
        ["gc"]() {
            _0x1fa80d && _0x1fa80d[_0x5c21("0x213", "oZew")]();
        }
        ["vibrateFun"](_0x9192ca, _0x37c4c5 = 0) {
            if (_0x9192ca) _0x1fa80d["vibrateLong"]({
                success: () => {},
                fail: () => {},
                complete: () => {}
            }); else if (0 == _0x37c4c5) _0x1fa80d["vibrateShort"]({
                success: () => {},
                fail: () => {},
                complete: () => {}
            }); else {
                let _0x9192ca = _0x5cbf5e[_0x5c21("0x214", "ggF#")](_0x37c4c5, 15), _0x3f996b = 0, _0xadae68 = {
                    count: _0x9192ca,
                    index: _0x3f996b
                };
                Laya[_0x5c21("0x215", "omJG")][_0x5c21("0x216", "UOab")](16, _0xadae68, function() {
                    this[_0x5c21("0x217", "jQ6r")](!1), _0x5cbf5e[_0x5c21("0x218", "m*dV")](++_0x3f996b, _0x9192ca) && Laya["timer"]["clearAll"](_0xadae68);
                });
            }
        }
        ["aldOnStart"](_0x506fb2, _0x872701) {
            const _0x2e75e3 = this;
            _0x1fa80d && _0x1fa80d[_0x5c21("0x219", "dZ3i")] && _0x1fa80d["aldStage"]["onStart"] && _0x5cbf5e[_0x5c21("0x21a", "m*dV")](1, this[_0x5c21("0x21b", "Uf[4")][_0x5c21("0x21c", "m[2Q")]) && _0x1fa80d["aldStage"][_0x5c21("0x21d", "bBqT")]({
                stageId: _0x506fb2,
                stageName: _0x872701,
                userId: _0x2e75e3["userInfo"]["id"]
            });
        }
        ["aldOnEnd"](_0x4baf25, _0x22b01f, _0x5e36aa, _0x1551d7) {
            const _0x828c86 = this;
            _0x1fa80d && _0x1fa80d[_0x5c21("0x21e", "ikmV")] && _0x1fa80d["aldStage"][_0x5c21("0x21f", "NYmF")] && _0x5cbf5e["mbBVn"](1, this[_0x5c21("0x220", "&D4Y")][_0x5c21("0x221", "oM#F")]) && _0x1fa80d[_0x5c21("0x222", "2^mQ")][_0x5c21("0x223", "TOp9")]({
                stageId: _0x4baf25,
                stageName: _0x22b01f,
                userId: _0x828c86[_0x5c21("0x224", "hOwa")]["id"],
                event: _0x5e36aa,
                params: {
                    desc: _0x1551d7
                }
            });
        }
        [_0x5c21("0x225", "LDjf")](_0x3fab59, _0x417588, _0x325a2f, _0x38779b) {
            const _0x1afdcb = this;
            _0x1fa80d && _0x1fa80d["aldStage"] && _0x1fa80d[_0x5c21("0x226", "AQRo")][_0x5c21("0x227", "omJG")] && _0x5cbf5e[_0x5c21("0x228", "2CMv")](1, this[_0x5c21("0x229", "NYmF")]["open_ald_eventstat"]) && _0x1fa80d["aldStage"][_0x5c21("0x22a", "TOp9")]({
                stageId: _0x3fab59,
                stageName: _0x417588,
                userId: _0x1afdcb["userInfo"]["id"],
                event: _0x325a2f,
                params: {
                    itemName: _0x38779b
                }
            });
        }
        ["clearAllTime"]() {
            Laya[_0x5c21("0x22b", "2CMv")][_0x5c21("0x22c", "m[2Q")](this);
        }
        ["initBanner"](_0x11f936 = !1) {
            null != this["bannerID"] ? this[_0x5c21("0x22d", "TOp9")][_0x5c21("0x22e", "(b*P")] <= 0 ? this[_0x5c21("0x22f", "oZew")] = void 0 : _0xf06c16["Inst"]["init"](this[_0x5c21("0x230", "gT6R")], this[_0x5c21("0x231", "jQ6r")][_0x5c21("0x232", "2CMv")], this[_0x5c21("0x233", ")RsM")][_0x5c21("0x234", "dZ3i")]) : this["bannerAd"] = void 0;
        }
        ["showBanner"](_0x2dfdb0, _0x313522) {
            if (this[_0x5c21("0x235", "bi^r")] = _0x313522, _0x1fa80d) {
                if (!this[_0x5c21("0x236", "4yM]")] || _0x2dfdb0) {
                    console["debug"](_0x5cbf5e[_0x5c21("0x237", "2^mQ")]), this[_0x5c21("0x238", "2^mQ")]();
                    var _0x599931 = !1;
                    1 == this[_0x5c21("0x1f1", "ggF#")]["open_ad_late"] && 1 == this[_0x5c21("0x239", "iAvi")][_0x5c21("0x23a", "([2%")] && _0x5cbf5e["AJTBt"](this[_0x5c21("0x23b", "4E!&")](0, 100), this["config"][_0x5c21("0x23c", ")RsM")]) && (_0x599931 = !(this[_0x5c21("0x23d", "hOwa")] && _0x5cbf5e["kdAdC"](_0x5cbf5e[_0x5c21("0x23e", "&D4Y")](Laya[_0x5c21("0x23f", "TOp9")]["currTimer"], this[_0x5c21("0x240", "fIRP")]) / 1e3, this[_0x5c21("0x241", "2^mQ")][_0x5c21("0x242", "rvGE")]))), 
                    _0x3c1d73["Inst"][_0x5c21("0x243", "dZ3i")] && _0x3c1d73[_0x5c21("0x244", "gT6R")][_0x5c21("0x245", ")RsM")] && (_0x599931 = !1), 
                    _0x599931 && _0x2dfdb0 ? (this[_0x5c21("0x246", "*$CX")] = !0, this[_0x5c21("0x247", "NYmF")](_0x2dfdb0, () => {
                        this["bannershow"]();
                    }, !0)) : this[_0x5c21("0x248", "AQRo")](_0x2dfdb0, () => {
                        this["bannershow"]();
                    }, !1);
                }
            } else (_0x599931 = !0) && _0x2dfdb0 && _0x5cbf5e[_0x5c21("0x249", "2^mQ")](this[_0x5c21("0x24a", "r#o%")](0, 100), 30) ? this["bannerMoveTop"](_0x2dfdb0, () => {
                this[_0x5c21("0x24b", "%9(3")]();
            }, !0) : this[_0x5c21("0x24c", "omJG")](_0x2dfdb0, () => {
                this["bannershow"]();
            }, !1);
        }
        [_0x5c21("0x24d", "Yd[7")](_0xcf1a54, _0x2e66dc, _0x249590 = !1) {
            var _0x4dc49 = {
                EmkGV: function _0x5a73d1(_0x242865) {
                    return _0x242865();
                }
            };
            const _0x1e91ea = this;
            let _0x479d5b = 0;
            if (_0x249590) {
                _0x479d5b = Laya[_0x5c21("0x24e", "rvGE")][_0x5c21("0x24f", "Yd[7")] - 100, _0xcf1a54["y"] = _0x479d5b, 
                _0x479d5b = _0x5cbf5e[_0x5c21("0x250", "9T1Q")](Laya[_0x5c21("0x251", "al%z")][_0x5c21("0x252", "%9(3")], (_0x1e91ea["bannerheight"] + 15) * _0x1e91ea[_0x5c21("0x253", "8&%b")]);
                let _0x249590 = _0x1e91ea["config"][_0x5c21("0x254", "al%z")] || 1, _0xef3c19 = _0x1e91ea[_0x5c21("0x255", "NTNj")][_0x5c21("0x256", "nnjN")] || 1;
                Laya[_0x5c21("0x257", "r#o%")][_0x5c21("0x258", "NTNj")](1e3 * _0x5cbf5e["oLuPI"](parseInt, _0x249590), _0x1e91ea, () => {
                    _0x2e66dc && _0x4dc49[_0x5c21("0x259", "NTNj")](_0x2e66dc), _0x1e91ea[_0x5c21("0x25a", "LDjf")] = Laya[_0x5c21("0x25b", "JzeF")][_0x5c21("0x25c", "Uv]h")];
                }), Laya["timer"][_0x5c21("0x25d", "CvOU")](1e3 * _0x5cbf5e[_0x5c21("0x25e", "t@qE")](parseInt, _0xef3c19), _0x1e91ea, () => {
                    Laya["Tween"]["to"](_0xcf1a54, {
                        y: _0x479d5b
                    }, 1e3, Laya[_0x5c21("0x25f", "omJG")]["linearIn"]);
                });
            } else _0x479d5b = _0x5cbf5e[_0x5c21("0x260", "([2%")](Laya[_0x5c21("0x261", "CvOU")]["height"], _0x5cbf5e["hhlCG"](_0x1e91ea[_0x5c21("0x262", "2CMv")] + 20, _0x1e91ea[_0x5c21("0x263", "2CMv")])), 
            _0xcf1a54 && (_0xcf1a54["y"] = _0x479d5b), _0x2e66dc && _0x5cbf5e[_0x5c21("0x264", "4E!&")](_0x2e66dc);
        }
        [_0x5c21("0x265", "TOp9")]() {
            0 == this["isBannerShowed"] && _0xf06c16[_0x5c21("0x266", "t@qE")][_0x5c21("0x267", "JzeF")]();
        }
        ["hideBanner"]() {
            _0xf06c16["Inst"]["hideBanner"]();
        }
        [_0x5c21("0x268", "(LPe")]() {
            this[_0x5c21("0x269", "MjE8")] ? null == this["videoAd"] && _0x1fa80d[_0x5c21("0x26a", "2(Lk")] && (this["videoAd"] = _0x1fa80d[_0x5c21("0x26b", "Yd[7")]({
                adUnitId: this[_0x5c21("0x26c", "dZ3i")]
            }), this[_0x5c21("0x26d", "4E!&")][_0x5c21("0x26e", "*$CX")](_0xef3a07 => {
                console["log"](_0xef3a07);
            })) : this[_0x5c21("0x26f", "m*dV")] = !1;
        }
        ["showVideo"](_0x116cb0, _0x1e5804) {
            if (_0x1fa80d) {
                if (this[_0x5c21("0x270", "2(Lk")](), _0x5cbf5e["XcSJd"](null, this[_0x5c21("0x271", "2(Lk")])) return console[_0x5c21("0x272", "ikmV")](_0x5c21("0x273", "oZew")), 
                void (1 == this[_0x5c21("0x274", "ikmV")]["is_share"] ? this[_0x5c21("0x275", "NYmF")](_0x116cb0, _0x1e5804) : _0x116cb0 && _0x5cbf5e[_0x5c21("0x276", "([2%")](_0x116cb0));
                if (1 == this[_0x5c21("0x239", "iAvi")][_0x5c21("0x277", "gT6R")]) return console[_0x5c21("0x18d", "TOp9")](_0x5cbf5e["wXPvv"]), 
                void this[_0x5c21("0x278", "[GWR")](_0x116cb0, _0x1e5804);
                if (this[_0x5c21("0x279", "nnjN")]) return this[_0x5c21("0x27a", "oZew")]("视频载入中");
                this[_0x5c21("0x27b", "Uv]h")] = !0;
                let _0x39c3f8 = _0x4ea928 => {
                    this[_0x5c21("0x27c", "t@qE")]["offClose"](_0x39c3f8), _0x5cbf5e[_0x5c21("0x27d", "hOwa")](null, _0x4ea928) || _0x5cbf5e["fKzsN"](null, _0x4ea928[_0x5c21("0x27e", "MjE8")]) || 1 == _0x4ea928[_0x5c21("0x27f", "dZ3i")] ? (this[_0x5c21("0x280", "gT6R")] = !1, 
                    _0x116cb0 && _0x5cbf5e[_0x5c21("0x281", "jQ6r")](_0x116cb0), this["cancelClicked"] = !1) : (this[_0x5c21("0x282", "(LPe")] = !1, 
                    this[_0x5c21("0x283", "omJG")]("你提前关闭了视频"), _0x1e5804 && _0x1e5804(), this[_0x5c21("0x284", "m*dV")] = !0);
                };
                this[_0x5c21("0x285", "oM#F")][_0x5c21("0x286", "ggF#")](_0x39c3f8), this["videoAd"]["load"]()[_0x5c21("0x287", "GLHs")](() => {
                    this["videoAd"][_0x5c21("0x288", "%9(3")]();
                })[_0x5c21("0x289", "%9(3")](_0x4fd73e => {
                    this[_0x5c21("0x28a", "*$CX")] = !1, this["videoPlaying"] = !1, console[_0x5c21("0x28b", "hOwa")](_0x4fd73e["errMsg"], _0x5cbf5e[_0x5c21("0x28c", "nnjN")]), 
                    this["share"](_0x116cb0, _0x1e5804);
                });
            } else _0x116cb0 && _0x116cb0();
        }
        [_0x5c21("0x28d", "Yd[7")](_0x5409a5, _0x3459ba) {
            const _0x282f6d = this;
            _0x5cbf5e[_0x5c21("0x28e", "JzeF")](null, _0x1fa80d) && (_0x282f6d[_0x5c21("0x28f", "omJG")] = new Date(), 
            _0x5409a5 ? (_0x282f6d["startShare"] = !0, _0x282f6d["successReward"] = null, _0x282f6d["successReward"] = _0x5409a5) : (_0x282f6d[_0x5c21("0x290", "AQRo")] = !1, 
            _0x282f6d[_0x5c21("0x291", "Uv]h")] = (() => {})), _0x282f6d["failShare"] = _0x3459ba, 
            this[_0x5c21("0x292", "CvOU")] = !1, _0x5cbf5e[_0x5c21("0x293", "NTNj")](0, _0x282f6d[_0x5c21("0x294", "[GWR")]["is_share"]) ? _0x282f6d[_0x5c21("0x295", "jQ6r")]() : this["shareFailStep1"](_0x282f6d[_0x5c21("0x296", "[GWR")]));
        }
        [_0x5c21("0x297", "CvOU")]() {
            _0x1fa80d[_0x5c21("0x298", "2CMv")](this["getShareInfo"]());
        }
        [_0x5c21("0x299", "4yM]")](_0x48b9af = "") {
            const _0x43bfbe = this;
            let _0x3df7ce = 0;
            return _0x43bfbe[_0x5c21("0x241", "2^mQ")][_0x5c21("0x29a", "AQRo")]["length"] && (_0x3df7ce = Math[_0x5c21("0x29b", "bBqT")](_0x5cbf5e["RKjdg"](Math["random"](), _0x43bfbe[_0x5c21("0x29c", "(LPe")][_0x5c21("0x29a", "AQRo")][_0x5c21("0x29d", "JzeF")]))), 
            null != _0x43bfbe["config"][_0x5c21("0x29e", "TOp9")][_0x3df7ce] ? {
                title: _0x43bfbe[_0x5c21("0x132", "9T1Q")][_0x5c21("0x29f", "2(Lk")][_0x3df7ce][_0x5c21("0x2a0", "m*dV")],
                imageUrl: _0x43bfbe["config"]["share_info"][_0x3df7ce][_0x5c21("0x2a1", "r#o%")],
                query: _0x5cbf5e[_0x5c21("0x2a2", "NYmF")](_0x5cbf5e[_0x5c21("0x2a3", "Uf[4")](_0x5c21("0x2a4", "bi^r"), _0x43bfbe["userInfo"]["id"]) + _0x5cbf5e[_0x5c21("0x2a5", "t@qE")] + _0x43bfbe[_0x5c21("0x231", "jQ6r")][_0x5c21("0x2a6", "oM#F")][_0x3df7ce]["id"] + _0x5cbf5e["xIVzI"], _0x43bfbe[_0x5c21("0x2a7", "MjE8")][_0x5c21("0x2a8", "NYmF")]),
                ald_desc: _0x48b9af
            } : {
                title: _0x43bfbe[_0x5c21("0x2a9", "(LPe")],
                imageUrl: "",
                query: _0x5cbf5e["bhxjT"](_0x5cbf5e[_0x5c21("0x2aa", "Uv]h")]("inviter_id=", _0x43bfbe["userInfo"]["id"]), _0x5c21("0x2ab", "fIRP"))
            };
        }
        ["shareFailStep1"](_0x477c36) {
            const _0xac2340 = this;
            _0xac2340[_0x5c21("0x2ac", "([2%")] && 1 != _0xac2340["config"][_0x5c21("0x2ad", "UOab")] ? (console["log"](_0x5cbf5e["kKwZq"]), 
            _0xac2340[_0x5c21("0x2ae", "nnjN")](() => {
                _0x5cbf5e[_0x5c21("0x2af", "%9(3")](_0x477c36), console[_0x5c21("0x18d", "TOp9")](_0x5c21("0x2b0", "m*dV"));
            }, () => {
                Laya["timer"][_0x5c21("0x2b1", "omJG")]();
            })) : _0x5cbf5e[_0x5c21("0x2b2", "al%z")](_0x477c36);
        }
        [_0x5c21("0x2b3", "TOp9")]() {
            var _0x55304e = {
                iDgPS: _0x5cbf5e[_0x5c21("0x2b4", "*$CX")]
            };
            const _0x59db1c = this;
            _0x5cbf5e[_0x5c21("0x2b5", "iAvi")](null, _0x1fa80d) && (_0x1fa80d[_0x5c21("0x2b6", "2(Lk")]({
                withShareTicket: !0,
                success: () => {},
                fail: () => {},
                complete: () => {}
            }), _0x1fa80d[_0x5c21("0x2b7", "NTNj")]({
                withShareTicket: !0,
                success: () => {},
                fail: () => {},
                complete: () => {}
            }), _0x1fa80d["onShareAppMessage"](() => _0x59db1c["getShareInfo"]()), _0x1fa80d[_0x5c21("0x2b8", "8&%b")](_0x2cfee0 => {
                _0x59db1c["onShow"](_0x2cfee0), console[_0x5c21("0x2b9", "fIRP")](_0x5cbf5e[_0x5c21("0x2ba", "bi^r")] + this["startShare"]), 
                this[_0x5c21("0x2bb", "9T1Q")] && _0x59db1c[_0x5c21("0x2bc", "m[2Q")](() => {
                    this[_0x5c21("0x2bd", "t@qE")] = !1, _0x59db1c[_0x5c21("0x2be", "(LPe")] && _0x59db1c["successReward"](), 
                    _0x59db1c["successReward"] = null, console[_0x5c21("0x2bf", "2(Lk")](_0x55304e[_0x5c21("0x2c0", "AQRo")]);
                }, () => {
                    this[_0x5c21("0x2c1", "NTNj")] = !1, Laya[_0x5c21("0x2c2", "fIRP")][_0x5c21("0x2c3", "MjE8")](), 
                    _0x59db1c["cancelClicked"] = !0, _0x59db1c[_0x5c21("0x2c4", "dZ3i")] && _0x59db1c[_0x5c21("0x2c5", "jQ6r")](), 
                    _0x59db1c[_0x5c21("0x2c6", "iAvi")] = null, console[_0x5c21("0x2c7", "t@qE")]("sharefail");
                });
            }), _0x1fa80d[_0x5c21("0x2c8", "LDjf")](() => {
                console[_0x5c21("0x2c9", "NTNj")](_0x5cbf5e[_0x5c21("0x2ca", "Yd[7")](_0x5cbf5e["IzFlJ"], this[_0x5c21("0x2cb", "JzeF")])), 
                _0x59db1c[_0x5c21("0x2cc", "([2%")]();
            }));
        }
        [_0x5c21("0x2cd", "JzeF")](_0x4a56d0, _0x26bef2) {
            if (null == _0x1fa80d) return _0x4a56d0();
            this["videoAd"] || _0x5cbf5e["pHsuW"]("", this["videoID"]) ? (console["log"](_0x5c21("0x2ce", "m[2Q")), 
            this[_0x5c21("0x2cf", "9GG)")](_0x4a56d0, _0x26bef2)) : this["share"](_0x4a56d0, _0x26bef2);
        }
        ["onStartGame"](_0x4826c0, _0x35805f) {
            var _0x4abc6c = this[_0x5c21("0x2d0", "Uv]h")](0, 100);
            _0x5cbf5e["ztpDt"](_0x4abc6c, _0x35805f) && _0x5cbf5e[_0x5c21("0x2d1", "m[2Q")](1, this["config"][_0x5c21("0x2d2", "iAvi")]) ? (console["log"](_0x5cbf5e[_0x5c21("0x2d3", "MjE8")], _0x4abc6c), 
            this["getReward"](() => {
                _0x4826c0();
            }, () => {
                _0x4826c0();
            })) : _0x5cbf5e["sWrcq"](_0x4826c0);
        }
        [_0x5c21("0x2d4", "omJG")](_0x4e0897) {
            const _0x514f7f = this;
            console[_0x5c21("0x2d5", "m*dV")](_0x5cbf5e[_0x5c21("0x2d6", "NYmF")], _0x4e0897["scene"]), 
            _0x5cbf5e["oJUXJ"] == _0x4e0897[_0x5c21("0x2d7", "8&%b")] && (_0x514f7f[_0x5c21("0x2d8", "TOp9")](), 
            _0x514f7f[_0x5c21("0x2d9", "MjE8")]());
        }
        [_0x5c21("0x2da", "m*dV")]() {
            const _0x36626f = this;
            _0x5cbf5e[_0x5c21("0x2db", "t@qE")](1, _0x36626f[_0x5c21("0x2dc", "[GWR")]) ? _0x5cbf5e["KMknY"](_0x5cbf5e["VDfYD"](_0x5cbf5e[_0x5c21("0x2dd", "2^mQ")](Laya[_0x5c21("0x2de", "Uv]h")][_0x5c21("0x2df", "nnjN")], _0x36626f[_0x5c21("0x2e0", "(LPe")]), 1e3), _0x36626f[_0x5c21("0x229", "NYmF")][_0x5c21("0x2e1", "JzeF")]) ? (_0x36626f[_0x5c21("0x2e2", "([2%")](_0x5c21("0x2e3", "nnjN")), 
            _0x36626f[_0x5c21("0x2e4", "m*dV")] = !0, _0x36626f[_0x5c21("0x2e5", "ikmV")] = Laya[_0x5c21("0x2e6", "m[2Q")][_0x5c21("0x2e7", "MjE8")]) : _0x36626f[_0x5c21("0x2e8", "TOp9")] = !1 : _0x36626f[_0x5c21("0x2e9", "JzeF")] = !1;
        }
        [_0x5c21("0x2ea", "*$CX")](_0x275243) {
            this[_0x5c21("0x2eb", "9GG)")](_0x275243);
        }
        ["reportOp2Ald"](_0xc158f3) {
            const _0x5505e8 = this;
            _0x1fa80d && 1 == this[_0x5c21("0x229", "NYmF")]["open_ald_eventstat"] && _0x1fa80d[_0x5c21("0x2ec", "[GWR")] && (_0x1fa80d[_0x5c21("0x2ed", "UOab")](_0xc158f3), 
            _0x1fa80d[_0x5c21("0x2ee", "bBqT")][_0x5c21("0x2ef", "2^mQ")]({
                stageId: 0,
                stageName: _0x5505e8[_0x5c21("0x2f0", "%9(3")],
                userId: _0x5505e8["userInfo"]["id"],
                event: _0x5c21("0x2f1", "gT6R"),
                params: {
                    itemName: _0xc158f3
                }
            }));
        }
        [_0x5c21("0x2f2", "9GG)")](_0x152c88, _0x2b6187) {
            var _0x5e5a4a = {
                flQNq: function _0x16d0b0(_0x4762ac) {
                    return _0x4762ac();
                },
                ljQHD: function _0x576459(_0xebb917) {
                    return _0x5cbf5e["sGJJL"](_0xebb917);
                }
            };
            const _0x21f0c5 = this;
            let _0x172597 = [ _0x5cbf5e["oJuxM"], _0x5c21("0x2f3", "MjE8"), _0x5c21("0x2f4", "4yM]") ], _0x14bf44 = Math[_0x5c21("0x2f5", "NYmF")](_0x5cbf5e[_0x5c21("0x2f6", "oZew")](3, Math[_0x5c21("0x2f7", "4E!&")]())), _0x431bc2 = null != _0x21f0c5[_0x5c21("0x2f8", "oM#F")]["share_long_time"] ? _0x5cbf5e["VDfYD"](_0x21f0c5[_0x5c21("0x1f2", "nnjN")]["share_long_time"][0][_0x5c21("0x2f9", "r#o%")], 1e3) : 1, _0x4ac1b3 = _0x5cbf5e["pHsuW"](null, _0x21f0c5[_0x5c21("0x1ef", "dZ3i")]["share_long_time"]) ? _0x5cbf5e["VDfYD"](_0x21f0c5[_0x5c21("0x2fa", "Yd[7")]["share_long_time"][1]["time"], 1e3) : 3, _0x46a877 = null != _0x21f0c5["config"][_0x5c21("0x2fb", "2(Lk")] ? _0x21f0c5[_0x5c21("0x2fc", "m[2Q")][_0x5c21("0x2fd", "*$CX")][0]["probability"] : 0, _0x15bb12 = null != _0x21f0c5["config"][_0x5c21("0x2fd", "*$CX")] ? _0x21f0c5[_0x5c21("0x2fe", "UOab")][_0x5c21("0x2ff", "rvGE")][1][_0x5c21("0x300", "dZ3i")] : 20, _0x53d42f = null != _0x21f0c5[_0x5c21("0x301", "r#o%")][_0x5c21("0x302", "al%z")] ? _0x21f0c5[_0x5c21("0x303", "TOp9")][_0x5c21("0x304", "UOab")][2][_0x5c21("0x305", "MjE8")] : [ 80, 10, 50, 60 ], _0x23ce58 = Math[_0x5c21("0x306", "m[2Q")](100 * Math[_0x5c21("0x307", "AQRo")]()) + 1, _0x3e1342 = _0x21f0c5["getSecond1"]();
            if (console[_0x5c21("0x308", "omJG")](_0x5cbf5e[_0x5c21("0x309", "9GG)")](_0x5cbf5e[_0x5c21("0x30a", "JzeF")], _0x3e1342)), 
            _0x5cbf5e[_0x5c21("0x30b", "m[2Q")](_0x3e1342, _0x431bc2)) _0x23ce58 < _0x46a877 ? (console[_0x5c21("0x30c", "bi^r")](_0x5cbf5e["AQgJy"](_0x23ce58 + "<", _0x46a877)), 
            _0x152c88 && _0x152c88()) : (console[_0x5c21("0x1dd", "jQ6r")](_0x5cbf5e[_0x5c21("0x30d", "9GG)")]), 
            _0x21f0c5[_0x5c21("0x30e", "UOab")](_0x172597[_0x14bf44], "系统提示：", function() {
                _0x21f0c5["share"](_0x21f0c5[_0x5c21("0x30f", "(b*P")], _0x2b6187);
            }, function() {
                _0x2b6187 && _0x5e5a4a[_0x5c21("0x310", "rvGE")](_0x2b6187);
            }, _0x5c21("0x311", "4E!&"))); else if (_0x5cbf5e["JAILr"](_0x3e1342, _0x4ac1b3)) _0x5cbf5e["htkTX"](_0x23ce58, _0x15bb12) ? (console[_0x5c21("0x312", "([2%")](_0x5cbf5e[_0x5c21("0x313", "JzeF")](_0x23ce58, "<") + _0x15bb12), 
            _0x152c88 && _0x5cbf5e["gZeMG"](_0x152c88)) : _0x21f0c5[_0x5c21("0x314", "8&%b")](_0x172597[_0x14bf44], _0x5cbf5e[_0x5c21("0x315", "9GG)")], function() {
                _0x21f0c5["share"](_0x21f0c5[_0x5c21("0x316", "oM#F")], _0x2b6187);
            }, function() {
                _0x2b6187 && _0x5e5a4a[_0x5c21("0x317", "%9(3")](_0x2b6187);
            }, _0x5c21("0x318", "TOp9")); else {
                let _0x539d6c = _0x53d42f[_0x21f0c5[_0x5c21("0x319", "[GWR")]];
                console["log"](_0x5cbf5e["XpeQd"] + _0x23ce58), console[_0x5c21("0x2bf", "2(Lk")](_0x5cbf5e[_0x5c21("0x31a", "jQ6r")]("rate=", _0x539d6c)), 
                _0x23ce58 <= _0x539d6c ? (console[_0x5c21("0xe5", "Uv]h")](_0x5cbf5e[_0x5c21("0x31b", "(b*P")]), 
                _0x152c88 && _0x5cbf5e[_0x5c21("0x31c", "oZew")](_0x152c88)) : (console[_0x5c21("0xae", "JzeF")](_0x5cbf5e[_0x5c21("0x31d", "[GWR")]), 
                _0x21f0c5[_0x5c21("0x31e", "CvOU")](_0x172597[_0x14bf44], _0x5cbf5e["ukEfl"], function() {
                    _0x21f0c5[_0x5c21("0x31f", ")RsM")](_0x21f0c5[_0x5c21("0x320", "2(Lk")], _0x2b6187);
                }, function() {
                    _0x2b6187 && _0x5e5a4a[_0x5c21("0x321", "ggF#")](_0x2b6187);
                }, _0x5cbf5e[_0x5c21("0x322", "TOp9")])), _0x21f0c5["shareRatio"] += 1, _0x5cbf5e[_0x5c21("0x323", "dZ3i")](_0x21f0c5["shareRatio"], _0x53d42f[_0x5c21("0x22e", "(b*P")]) && (_0x21f0c5[_0x5c21("0x324", "al%z")] = 0);
            }
        }
        [_0x5c21("0x325", "9T1Q")]() {
            let _0x57eece = _0x5cbf5e[_0x5c21("0x326", "al%z")](new Date()[_0x5c21("0x327", "gT6R")]() - this[_0x5c21("0x328", "Yd[7")][_0x5c21("0x329", "GLHs")](), 1e3);
            return Math["floor"](_0x57eece);
        }
        ["openMiniGame"](_0x4e41e2, _0x1e2c75, _0xa64c15, _0x69d4a9) {
            var _0x7b711b = {
                Nkxpg: function _0x532e90(_0x105ab3, _0x2e5276) {
                    return _0x105ab3 + _0x2e5276;
                },
                dfKxJ: _0x5cbf5e[_0x5c21("0x32a", "AQRo")]
            };
            const _0x54b827 = this;
            if (_0x1fa80d) if (_0x5cbf5e[_0x5c21("0x32b", "GLHs")](null, _0x554550) && _0x554550[_0x5c21("0x32c", "nnjN")]({
                id: _0x4e41e2["id"],
                images_id: _0x4e41e2["images_id"]
            }), _0x1fa80d[_0x5c21("0x32d", "LDjf")] && _0x5cbf5e[_0x5c21("0x32e", "oZew")](1, _0x4e41e2[_0x5c21("0x32f", "MjE8")])) _0x1fa80d[_0x5c21("0x330", "al%z")]({
                appId: _0x4e41e2["appid"],
                path: _0x4e41e2["path"],
                extraData: null,
                envVersion: _0x5cbf5e["EObOf"],
                success() {
                    _0x1e2c75 && _0x1e2c75(), null != _0x554550 && _0x554550[_0x5c21("0x331", "JzeF")]({
                        id: _0x4e41e2["id"],
                        images_id: _0x4e41e2[_0x5c21("0x332", "dZ3i")]
                    }), _0x54b827[_0x5c21("0x333", "m*dV")] && _0x54b827[_0x5c21("0x334", "hOwa")](_0x4e41e2), 
                    _0x420221["getIns"]()[_0x5c21("0x335", "m*dV")](_0x7b711b[_0x5c21("0x336", "m*dV")](_0x69d4a9, _0x7b711b[_0x5c21("0x337", "rvGE")]));
                },
                fail() {
                    console[_0x5c21("0x338", "rvGE")](_0x5cbf5e[_0x5c21("0x339", "LDjf")]), _0xa64c15 && _0xa64c15();
                },
                complete: () => {}
            }); else {
                let _0x2771ac = _0x4e41e2["poster"];
                _0x1fa80d["previewImage"]({
                    current: _0x2771ac,
                    urls: [ _0x2771ac ],
                    success() {
                        _0x1e2c75 && _0x5cbf5e["pAEgj"](_0x1e2c75), null != _0x554550 && _0x554550[_0x5c21("0x33a", "t@qE")]({
                            id: _0x4e41e2["id"],
                            images_id: _0x4e41e2[_0x5c21("0x33b", "gT6R")]
                        }), _0x54b827[_0x5c21("0x33c", "AQRo")] && _0x54b827[_0x5c21("0x33d", "TOp9")](_0x4e41e2), 
                        _0x420221[_0x5c21("0x33e", "dZ3i")]()[_0x5c21("0x33f", "t@qE")](_0x69d4a9 + _0x5cbf5e["haTzC"]);
                    },
                    fail() {
                        console[_0x5c21("0x125", "al%z")](_0x5c21("0x340", "ggF#")), _0xa64c15 && _0xa64c15();
                    },
                    complete() {}
                });
            }
        }
        [_0x5c21("0x341", "bBqT")](_0x2fe8bb) {
            let _0x162471 = _0x2fe8bb["id"];
            if (!_0x162471) return void console[_0x5c21("0x342", "ggF#")]("统计->跳转ID为空");
            var _0x1862cc = _0x1fa80d[_0x5c21("0x343", "CvOU")](), _0x29c317 = _0x1862cc["query"];
            let _0x27eab4 = {
                export_id: _0x162471,
                application_id: this[_0x5c21("0x344", "rvGE")],
                version: this[_0x5c21("0x345", "nnjN")],
                scene: _0x1862cc[_0x5c21("0x346", "t@qE")],
                openid: this[_0x5c21("0x347", "fIRP")][_0x5c21("0x348", "2CMv")],
                share_id: _0x29c317[_0x5c21("0x349", "t@qE")] || 0,
                channel_id: _0x29c317["channel_id"] || "",
                scene_id: _0x1862cc[_0x5c21("0x34a", "NTNj")],
                is_new: this[_0x5c21("0x34b", "JzeF")][_0x5c21("0x34c", "rvGE")],
                image_url: _0x2fe8bb[_0x5c21("0x34d", "(b*P")]
            };
            this["baseExternalRequest"](_0x5c21("0x34e", "Uf[4"), _0x5cbf5e[_0x5c21("0x34f", "fIRP")](this["externalDataServerUrl"], _0x5cbf5e[_0x5c21("0x350", "TOp9")]), _0x27eab4, function(_0x27a16f) {
                console[_0x5c21("0x351", "[GWR")](_0x27a16f["msg"]);
            });
        }
        ["setKeepLight"]() {
            _0x5cbf5e[_0x5c21("0x352", "hOwa")](this[_0x5c21("0x353", "([2%")]("1.4.0"), 0) && _0x1fa80d[_0x5c21("0x354", "CvOU")]({
                keepScreenOn: !0,
                success: () => {},
                fail: () => {},
                complete: () => {}
            });
        }
        ["saveLocalData"](_0x10070a, _0x435f7e) {
            Laya[_0x5c21("0x355", "2CMv")]["setItem"](_0x10070a, JSON[_0x5c21("0x356", "al%z")](_0x435f7e));
        }
        [_0x5c21("0x357", "hOwa")](_0x4ba8ca) {
            return Laya[_0x5c21("0x358", "(b*P")][_0x5c21("0x359", "ikmV")](_0x4ba8ca) ? JSON["parse"](Laya[_0x5c21("0x35a", "LDjf")][_0x5c21("0x35b", "nnjN")](_0x4ba8ca)) : null;
        }
        [_0x5c21("0x35c", "(LPe")]() {
            Laya["LocalStorage"][_0x5c21("0x35d", "4yM]")]();
        }
        [_0x5c21("0x35e", "dZ3i")](_0x189e0a, _0x4331ef) {
            return Math[_0x5c21("0x35f", "NTNj")](_0x5cbf5e[_0x5c21("0x360", "(b*P")](Math[_0x5c21("0x307", "AQRo")](), _0x5cbf5e["SzuPG"](_0x4331ef, _0x189e0a) + 1)) + _0x189e0a;
        }
        [_0x5c21("0x361", "JzeF")](_0x4aca3e, _0x8ae5b) {
            let _0x48c036, _0x1facba, _0x1a1229 = _0x4aca3e["length"], _0x280fd1 = _0x1a1229 - _0x8ae5b;
            for (;_0x1a1229-- > _0x280fd1; ) _0x48c036 = _0x4aca3e[_0x1facba = Math[_0x5c21("0x2f5", "NYmF")](_0x5cbf5e[_0x5c21("0x362", "UOab")](_0x5cbf5e["iuOUq"](_0x1a1229, 1), Math[_0x5c21("0x363", "2(Lk")]()))], 
            _0x4aca3e[_0x1facba] = _0x4aca3e[_0x1a1229], _0x4aca3e[_0x1a1229] = _0x48c036;
            return _0x4aca3e["slice"](_0x280fd1);
        }
        ["shuffleArray"](_0x1b9389) {
            return _0x1b9389[_0x5c21("0x364", "4E!&")]((_0x81c0af, _0x20e4b5) => Math[_0x5c21("0x365", "&D4Y")]() > .5 ? -1 : 1);
        }
        [_0x5c21("0x366", "r#o%")](_0x50cf6f, _0x29ee3c) {
            if (0 != _0x29ee3c) {
                let _0x418e64 = _0x50cf6f[_0x29ee3c];
                _0x50cf6f[_0x5c21("0x367", "*$CX")](_0x29ee3c, 1), _0x50cf6f[_0x5c21("0x368", "bi^r")](_0x418e64);
            } else console[_0x5c21("0x351", "[GWR")](_0x5c21("0x369", "AQRo"));
        }
        [_0x5c21("0x36a", "al%z")](_0x212932, _0x49be86) {
            if (_0x49be86 != _0x212932[_0x5c21("0x36b", "4E!&")] - 1) {
                let _0x2194b2 = _0x212932[_0x49be86];
                _0x212932[_0x5c21("0x36c", "Uv]h")](_0x49be86, 1), _0x212932[_0x5c21("0x36d", "*$CX")](_0x2194b2);
            } else console["log"]("已经处于置底");
        }
        [_0x5c21("0x36e", "AQRo")](_0x2e5337 = 0) {
            let _0x2edd5b, _0x4a5aa3, _0x350c03, _0x195ef0, _0x4082a1, _0x29eb2b, _0x5b58e7;
            return _0x4a5aa3 = ("0" + ((_0x2edd5b = new Date(_0x5cbf5e[_0x5c21("0x36f", "Uv]h")](new Date()[_0x5c21("0x370", "MjE8")](), _0x5cbf5e[_0x5c21("0x371", "(LPe")](24 * _0x2e5337 * 3600, 1e3))))[_0x5c21("0x372", "ggF#")]() + 1))[_0x5c21("0x373", "LDjf")](-2), 
            _0x350c03 = ("0" + _0x2edd5b[_0x5c21("0x374", "4E!&")]())[_0x5c21("0x375", "al%z")](-2), 
            _0x195ef0 = ("0" + _0x2edd5b["getHours"]())[_0x5c21("0x376", "2^mQ")](-2), _0x4082a1 = _0x5cbf5e["iuOUq"]("0", _0x2edd5b["getMinutes"]())[_0x5c21("0x377", "efPG")](-2), 
            _0x29eb2b = _0x5cbf5e[_0x5c21("0x378", "al%z")]("0", _0x2edd5b[_0x5c21("0x379", "2CMv")]())[_0x5c21("0x37a", "fIRP")](-2), 
            _0x5b58e7 = _0x2edd5b[_0x5c21("0x37b", "LDjf")]() + "/" + _0x4a5aa3 + "/" + _0x350c03 + " " + _0x195ef0 + ":" + _0x4082a1 + ":" + _0x29eb2b;
        }
        [_0x5c21("0x37c", "2(Lk")](_0x1700ec, _0x39b05b = !1) {
            let _0x43c85b = Math[_0x5c21("0x37d", "r#o%")](_0x1700ec), _0x13ecb5 = 0, _0x5c3f9b = 0;
            return _0x5cbf5e["zjmdZ"](_0x43c85b, 60) && (_0x13ecb5 = Math[_0x5c21("0x37e", "2CMv")](_0x5cbf5e[_0x5c21("0x37f", "oM#F")](_0x43c85b, 60)), 
            _0x43c85b = Math[_0x5c21("0x37e", "2CMv")](_0x43c85b % 60), _0x5cbf5e[_0x5c21("0x380", "%9(3")](_0x13ecb5, 60) && (_0x5c3f9b = Math["floor"](_0x13ecb5 / 60), 
            _0x13ecb5 = Math[_0x5c21("0x381", "omJG")](_0x13ecb5 % 60))), _0x39b05b ? {
                hour: _0x5c3f9b = _0x5cbf5e[_0x5c21("0x382", "MjE8")](parseInt, _0x5cbf5e[_0x5c21("0x383", "2CMv")]("0", _0x5c3f9b)[_0x5c21("0x384", "*$CX")](-2)),
                minute: _0x13ecb5 = _0x5cbf5e[_0x5c21("0x385", "UOab")](parseInt, ("0" + _0x13ecb5)[_0x5c21("0x386", "omJG")](-2)),
                second: _0x43c85b = parseInt(("0" + _0x43c85b)[_0x5c21("0x387", "9GG)")](-2))
            } : _0x5cbf5e[_0x5c21("0x388", "oM#F")](_0x5cbf5e[_0x5c21("0x389", "fIRP")](_0x13ecb5 = _0x5cbf5e["DSbdr"](parseInt, _0x5cbf5e[_0x5c21("0x38a", "*$CX")]("0", _0x13ecb5)["slice"](-2)), ":"), _0x43c85b = _0x5cbf5e[_0x5c21("0x38b", "[GWR")](parseInt, ("0" + _0x43c85b)[_0x5c21("0x38c", "m[2Q")](-2)));
        }
        [_0x5c21("0x38d", "*$CX")](_0x1fd4f3, _0x7d2d3d) {
            let _0x571936 = _0x5cbf5e["RvQtN"](new Date(_0x1fd4f3)[_0x5c21("0x370", "MjE8")]() - new Date(_0x7d2d3d)["getTime"](), 1e3);
            return Math[_0x5c21("0x38e", "nnjN")](_0x571936);
        }
        ["getDays"](_0x4458b3, _0x2989a7) {
            return Math[_0x5c21("0x38e", "nnjN")](_0x4458b3[_0x5c21("0x38f", "%9(3")]() - _0x2989a7[_0x5c21("0x390", "hOwa")]() / 864e5);
        }
        [_0x5c21("0x391", "([2%")](_0x2b3444) {
            let _0x38ab91 = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？%+_]"), _0x4e4427 = "";
            for (let _0x1f0882 = 0; _0x5cbf5e[_0x5c21("0x392", "m[2Q")](_0x1f0882, _0x2b3444["length"]); _0x1f0882++) _0x4e4427 += _0x2b3444["substr"](_0x1f0882, 1)[_0x5c21("0x393", "GLHs")](_0x38ab91, "");
            return _0x4e4427;
        }
        ["unitsNumber"](_0x3cf627 = 0) {
            if (0 == (_0x3cf627 = Math["floor"](_0x3cf627))) return 0;
            let _0x548172 = Math[_0x5c21("0x394", "oZew")](_0x5cbf5e["HcNdg"](Math["log"](_0x3cf627), Math[_0x5c21("0x351", "[GWR")](1e3))), _0x5f335c = _0x3cf627 / Math[_0x5c21("0x395", "bBqT")](1e3, _0x548172);
            return 0 === _0x548172 ? _0x5f335c : (_0x5f335c = parseInt(_0x5f335c["toFixed"](3)), 
            (_0x5f335c = _0x5cbf5e[_0x5c21("0x396", "8&%b")](parseInt, _0x5f335c[_0x5c21("0x397", "bi^r")]()[_0x5c21("0x398", "oZew")](0, _0x5f335c[_0x5c21("0x399", "al%z")]()[_0x5c21("0x39a", "&D4Y")](".") + 2))) + [ "", "k", "m", "b", "f", "e", "ae", "be", "ce", "de", "ee", "fe", "ge", "he", "ie" ][_0x548172]);
        }
    }
    var _0x1c3643 = Laya[_0x5c21("0x39b", "m[2Q")][_0x5c21("0x39c", "omJG")]["wx"];
    class _0x4176cc {
        constructor() {
            this[_0x5c21("0x39d", "2^mQ")] = 0, this[_0x5c21("0x39e", "2CMv")] = !1, this[_0x5c21("0x39f", "ggF#")] = _0x1c3643[_0x5c21("0x3a0", "Yd[7")]();
        }
        static get [_0x5c21("0x3a1", "al%z")]() {
            return _0x4176cc["_inst"] || (_0x4176cc["_inst"] = new _0x4176cc()), _0x4176cc[_0x5c21("0x3a2", "Uv]h")];
        }
        [_0x5c21("0x3a3", "4E!&")](_0x379d8e, _0x45a546) {
            this[_0x5c21("0x3a4", "&D4Y")] = [], this[_0x5c21("0x3a5", "9T1Q")] = 0, this[_0x5c21("0x3a6", "NYmF")] = !1, 
            this[_0x5c21("0x3a7", "4E!&")] = _0x45a546, this[_0x5c21("0x3a8", "oM#F")] = 0;
            for (let _0x45a546 = 0; _0x45a546 < _0x379d8e[_0x5c21("0x3a9", "rvGE")]; _0x45a546++) {
                let _0x16fe67 = {
                    customID: _0x379d8e[_0x45a546],
                    customAd: null,
                    showNum: 0
                };
                this[_0x5c21("0x3aa", "bi^r")][_0x5c21("0x3ab", "nnjN")](_0x16fe67), this["creatCustomAd"](_0x16fe67);
            }
            Laya["timer"][_0x5c21("0x3ac", "%9(3")](2, this, this["loopFun"]);
        }
        [_0x5c21("0x3ad", "AQRo")]() {
            this[_0x5c21("0x3ae", "t@qE")] && (this[_0x5c21("0x3af", "&D4Y")] += Laya[_0x5c21("0x3b0", "oM#F")][_0x5c21("0x3b1", "Uf[4")], 
            _0x5cbf5e["XMBlM"](this[_0x5c21("0x3af", "&D4Y")], _0x5cbf5e[_0x5c21("0x3b2", "efPG")](1e3, this[_0x5c21("0x3b3", "oZew")])) && (this["curSecond"] = 0, 
            this["hideCustom"](), this[_0x5c21("0x3b4", "4E!&")]()));
        }
        ["creatCustomAd"](_0x3d1047) {
            const _0x4a9442 = _0x1c3643["createCustomAd"]({
                adUnitId: _0x3d1047["customID"],
                style: {
                    left: this[_0x5c21("0x3b5", "oZew")][_0x5c21("0x3b6", "8&%b")] - 80,
                    top: this[_0x5c21("0x3b7", "(LPe")]()[_0x5c21("0x3b8", "2(Lk")] + 120
                }
            });
            _0x4a9442[_0x5c21("0x3b9", "%9(3")](() => {
                _0x3d1047[_0x5c21("0x3ba", "rvGE")] = _0x4a9442, _0x3d1047[_0x5c21("0x3bb", "dZ3i")] = 0;
            }), _0x4a9442["onError"](_0x41611c => {
                console[_0x5c21("0x3bc", "NYmF")]("createCustomAd error", _0x41611c);
            });
        }
        [_0x5c21("0x3bd", "UOab")]() {
            if (0 == this[_0x5c21("0x3be", "(b*P")][_0x5c21("0x3bf", "Uf[4")]) return;
            let _0x4245f0 = this[_0x5c21("0x3c0", "9T1Q")][this[_0x5c21("0x3c1", "2CMv")]];
            _0x4245f0["customAd"] && (_0x4245f0[_0x5c21("0x3c2", "LDjf")][_0x5c21("0x3c3", "2CMv")](), 
            _0x4245f0[_0x5c21("0x3c4", "omJG")] += 1), this[_0x5c21("0x3c5", ")RsM")] = !0, 
            this["CustomIdex"] += 1, this["CustomIdex"] = this["CustomIdex"] >= this[_0x5c21("0x3c6", "4yM]")][_0x5c21("0x3c7", "t@qE")] ? 0 : this["CustomIdex"];
        }
        [_0x5c21("0x3c8", "ggF#")]() {
            if (0 != this[_0x5c21("0x3c9", "4E!&")][_0x5c21("0x3ca", "hOwa")]) {
                for (let _0x1740a1 in this[_0x5c21("0x3cb", "ikmV")]) {
                    let _0x393070 = this["CustomList"][_0x1740a1];
                    _0x393070 && _0x393070["customAd"] && _0x393070[_0x5c21("0x3cc", "Yd[7")][_0x5c21("0x3cd", ")RsM")] && _0x393070["customAd"][_0x5c21("0x3ce", "MjE8")]();
                }
                this["isCustomShow"] = !1;
            }
        }
        [_0x5c21("0x3cf", "TOp9")]() {
            if (_0x1c3643) {
                var _0x24a737 = _0x1c3643[_0x5c21("0x3d0", "(LPe")]();
                let _0x590c07 = this[_0x5c21("0x3d1", "9T1Q")][_0x5c21("0x3d2", "JzeF")], _0x15a354 = Laya[_0x5c21("0x3d3", "GLHs")][_0x5c21("0x3d4", "rvGE")] / _0x590c07;
                return _0x24a737[_0x5c21("0x3d5", "dZ3i")] *= _0x15a354, _0x24a737[_0x5c21("0x3d6", "LDjf")] *= _0x15a354, 
                console["log"](_0x24a737), _0x24a737;
            }
            return {
                bottom: 84,
                height: 32,
                left: 556,
                right: 365,
                top: 10,
                width: 87
            };
        }
    }
    var _0x27b03e, _0xd1f1d2, _0x19e6f7 = Laya[_0x5c21("0x3d7", "m*dV")], _0x3ea549 = Laya["ClassUtils"][_0x5c21("0x3d8", "UOab")];
    !function(_0x5403f6) {
        !function(_0x426445) {
            var _0x5bab3a = {
                mlwNO: _0x5c21("0x3d9", "fIRP")
            };
            class _0x1a96df extends _0x19e6f7 {
                constructor() {
                    super();
                }
                [_0x5c21("0x3da", "m*dV")]() {
                    super[_0x5c21("0x3db", "fIRP")](), this["loadScene"](_0x5bab3a[_0x5c21("0x3dc", "Uv]h")]);
                }
            }
            _0x426445[_0x5c21("0x3dd", "UOab")] = _0x1a96df, _0x5cbf5e["zkTNr"](_0x3ea549, _0x5cbf5e[_0x5c21("0x3de", "([2%")], _0x1a96df);
            class _0x416278 extends _0x19e6f7 {
                constructor() {
                    super();
                }
                [_0x5c21("0x3df", "(b*P")]() {
                    super[_0x5c21("0x3e0", "gT6R")](), this[_0x5c21("0x3e1", "TOp9")](_0x416278["uiView"]);
                }
            }
            _0x416278[_0x5c21("0x3e2", "(LPe")] = {
                type: _0x5cbf5e[_0x5c21("0x3e3", "GLHs")],
                props: {
                    width: 750,
                    runtime: _0x5cbf5e[_0x5c21("0x3e4", "oZew")],
                    height: 1624
                },
                compId: 2,
                child: [ {
                    type: _0x5cbf5e["DXMHZ"],
                    props: {
                        y: 812,
                        x: 0,
                        var: "bg",
                        texture: _0x5c21("0x3e5", "4yM]"),
                        pivotY: 812,
                        height: 1624
                    },
                    compId: 3
                }, {
                    type: _0x5cbf5e["xzudo"],
                    props: {
                        y: 812,
                        x: 0,
                        var: "loginView",
                        right: 0,
                        left: 0,
                        height: 1334,
                        anchorY: .5
                    },
                    compId: 4,
                    child: [ {
                        type: "Sprite",
                        props: {
                            y: 1100,
                            x: 99,
                            texture: "load/bg-loading.png"
                        },
                        compId: 5,
                        child: [ {
                            type: _0x5cbf5e[_0x5c21("0x3e6", "MjE8")],
                            props: {
                                y: 0,
                                x: 0,
                                width: 166,
                                var: _0x5cbf5e[_0x5c21("0x3e7", "(b*P")],
                                skin: _0x5cbf5e["AuYoI"],
                                sizeGrid: _0x5c21("0x3e8", "Yd[7"),
                                scaleY: 1,
                                scaleX: 1
                            },
                            compId: 6
                        } ]
                    }, {
                        type: _0x5cbf5e["DXMHZ"],
                        props: {
                            y: 1200,
                            x: 51,
                            texture: _0x5cbf5e[_0x5c21("0x3e9", "([2%")]
                        },
                        compId: 7
                    }, {
                        type: _0x5cbf5e[_0x5c21("0x3ea", "([2%")],
                        props: {
                            y: 76,
                            x: 76,
                            texture: _0x5c21("0x3eb", "nnjN"),
                            scaleY: 1,
                            scaleX: 1
                        },
                        compId: 8
                    } ]
                } ],
                loadList: [ _0x5cbf5e[_0x5c21("0x3ec", "[GWR")], "load/bg-loading.png", _0x5cbf5e["AuYoI"], _0x5c21("0x3ed", "NTNj"), "load/logo.png" ],
                loadList3D: []
            }, _0x426445[_0x5c21("0x3ee", "hOwa")] = _0x416278, _0x5cbf5e[_0x5c21("0x3ef", "rvGE")](_0x3ea549, _0x5c21("0x3f0", "&D4Y"), _0x416278);
        }(_0x5403f6[_0x5c21("0x3f1", "Uv]h")] || (_0x5403f6[_0x5c21("0x3f2", "4yM]")] = {}));
    }(_0x27b03e || (_0x27b03e = {}));
    class _0x36ffa1 extends Laya[_0x5c21("0x3f3", "dZ3i")] {
        static [_0x5c21("0x3f4", "4E!&")]() {
            Laya[_0x5c21("0x3f5", "rvGE")][_0x5c21("0x3f6", "4yM]")](_0x36ffa1["gameName"], JSON["stringify"](_0x36ffa1[_0x5c21("0x3f7", "4E!&")]));
        }
        static ["getData"]() {
            let _0x3aab25 = Laya[_0x5c21("0x355", "2CMv")][_0x5c21("0x3f8", "gT6R")](_0x36ffa1[_0x5c21("0x3f9", "2(Lk")]) ? JSON["parse"](Laya[_0x5c21("0x3fa", "omJG")][_0x5c21("0x3fb", "9T1Q")](_0x36ffa1[_0x5c21("0x3fc", "oM#F")])) : null;
            _0x3aab25 && (_0x36ffa1[_0x5c21("0x3fd", "jQ6r")] = _0x3aab25);
        }
        static [_0x5c21("0x3fe", "4yM]")]() {}
        static [_0x5c21("0x3ff", "al%z")]() {
            Laya[_0x5c21("0x400", "9T1Q")]["clear"]();
        }
    }
    _0x36ffa1["UserInfo"] = {}, _0x36ffa1[_0x5c21("0x401", "ikmV")] = {
        level: 1
    }, _0x36ffa1["gameName"] = _0x5cbf5e[_0x5c21("0x402", "dZ3i")];
    class _0x14063c {
        constructor() {}
    }
    _0x14063c["IsStart"] = !1, _0x14063c[_0x5c21("0x403", "([2%")] = !1, _0x14063c["IsSuccess"] = !1, 
    _0x14063c["startGame"] = function() {
        _0x14063c["IsStart"] = !0;
    }, _0x14063c["gameOver"] = function(_0x491f49, _0x4f085b = 1e3) {
        _0x14063c[_0x5c21("0x404", "8&%b")] = !1, _0x14063c[_0x5c21("0x405", "AQRo")] = _0x491f49, 
        _0x3c1d73["Inst"][_0x5c21("0x406", "dZ3i")][_0x5c21("0x407", "CvOU")](), _0x491f49 ? (Laya[_0x5c21("0x408", ")RsM")]["playSound"]("Music/win.mp3"), 
        _0x420221[_0x5c21("0x409", "MjE8")]()["aldOnEnd"](_0x36ffa1[_0x5c21("0x40a", "2(Lk")][_0x5c21("0x40b", "4yM]")], "第" + _0x36ffa1[_0x5c21("0x40a", "2(Lk")]["level"] + "关", "complete", "过关")) : (Laya[_0x5c21("0x40c", "bi^r")][_0x5c21("0x40d", "NYmF")](_0x5cbf5e["zifwz"]), 
        _0x420221["getIns"]()[_0x5c21("0x40e", "[GWR")](_0x36ffa1[_0x5c21("0x40f", "Yd[7")]["level"], _0x5cbf5e[_0x5c21("0x410", "CvOU")]("第", _0x36ffa1[_0x5c21("0x411", "dZ3i")]["level"]) + "关", _0x5cbf5e[_0x5c21("0x412", "Uv]h")], "失败")), 
        Laya[_0x5c21("0x215", "omJG")][_0x5c21("0x413", "Uf[4")](_0x4f085b, this, () => {
            _0x3c1d73[_0x5c21("0x266", "t@qE")]["GetUI"](_0x574ca6[_0x5c21("0x414", "hOwa")][_0x5c21("0x415", "2^mQ")])[_0x5c21("0x416", "AQRo")](), 
            _0x3c1d73[_0x5c21("0x417", "Uv]h")][_0x5c21("0x418", "*$CX")]();
        });
    }, _0x14063c[_0x5c21("0x419", "dZ3i")] = function() {
        _0x5cbf5e[_0x5c21("0x41a", "2^mQ")](1, _0x14063c[_0x5c21("0x41b", "ikmV")]) && (_0x14063c[_0x5c21("0x41c", "rvGE")] = !0);
    }, _0x14063c["remuseGame"] = function() {
        1 == _0x14063c[_0x5c21("0x41d", "iAvi")] && (_0x14063c[_0x5c21("0x41e", "r#o%")] = !1);
    }, _0x14063c[_0x5c21("0x41f", "jQ6r")] = function(_0x11b076, _0x520986, _0xabed1b) {
        _0x11b076["on"](_0x520986, this, () => {
            _0x5cbf5e[_0x5c21("0x420", "al%z")](_0xabed1b);
        });
    };
    class _0x4adf09 {
        constructor() {
            this[_0x5c21("0x421", "oM#F")] = new Map(), this[_0x5c21("0x422", "m[2Q")] = new Map();
        }
        static get [_0x5c21("0x423", "hOwa")]() {
            return this[_0x5c21("0x424", "(b*P")] || (this[_0x5c21("0x425", "8&%b")] = new _0x4adf09()), 
            this[_0x5c21("0x426", "Yd[7")];
        }
        [_0x5c21("0x427", "t@qE")](_0x450d38) {
            this["objMap"]["set"](_0x450d38["name"], _0x450d38), _0x450d38[_0x5c21("0x428", "m[2Q")] = !1;
            this[_0x5c21("0x429", "nnjN")]["set"](_0x450d38[_0x5c21("0x42a", "r#o%")], []);
        }
        [_0x5c21("0x42b", "nnjN")](_0x18c931) {
            try {
                let _0x49c8e3, _0x57502f = this["objArrMap"][_0x5c21("0x42c", "fIRP")](_0x18c931);
                return (_0x49c8e3 = _0x57502f[_0x5c21("0x42d", "GLHs")] > 0 ? _0x57502f[_0x5c21("0x42e", "8&%b")]() : this[_0x5c21("0x42f", "oZew")][_0x5c21("0x430", "(LPe")](_0x18c931)[_0x5c21("0x431", "9T1Q")]())[_0x5c21("0x432", "MjE8")] = !0, 
                _0x49c8e3;
            } catch (_0x15187a) {
                console["log"](_0x18c931, _0x15187a);
            }
        }
        [_0x5c21("0x433", "&D4Y")](_0x174104) {
            _0x174104[_0x5c21("0x434", "Yd[7")] = !1, _0x5cbf5e["XMBlM"](_0x174104[_0x5c21("0x435", "4yM]")][_0x5c21("0x436", "Uf[4")](_0x5c21("0x437", "TOp9")), -1) && (_0x174104[_0x5c21("0x438", ")RsM")] = _0x174104["name"]["replace"](_0x5cbf5e["NoOFR"], "")), 
            this[_0x5c21("0x429", "nnjN")][_0x5c21("0x439", "Yd[7")](_0x174104[_0x5c21("0x43a", "9T1Q")])["push"](_0x174104);
        }
        ["clearPool"](_0x321d38) {
            this["objArrMap"][_0x5c21("0x43b", "m[2Q")](_0x321d38[_0x5c21("0x43c", "al%z")])[_0x5c21("0x22e", "(b*P")] = 0;
        }
    }
    class _0x3f5234 {
        constructor() {
            this["filePath"] = _0x5cbf5e["vEPHj"], this[_0x5c21("0x43d", "JzeF")] = [ _0x5c21("0x43e", "rvGE"), _0x5cbf5e[_0x5c21("0x43f", "bBqT")], _0x5c21("0x440", ")RsM"), _0x5c21("0x441", "TOp9"), "Cylinder006", _0x5c21("0x442", "fIRP"), "Hamburguer_Mesh", "hotdog", _0x5cbf5e[_0x5c21("0x443", "Uv]h")], _0x5cbf5e["LDphh"], _0x5cbf5e["UHvUR"], _0x5cbf5e["euoxj"], _0x5cbf5e[_0x5c21("0x444", "MjE8")], _0x5c21("0x445", "GLHs"), _0x5cbf5e["jdhzr"], _0x5c21("0x42", "([2%"), _0x5cbf5e["BGKeP"] ], 
            this[_0x5c21("0x446", "hOwa")] = _0x5cbf5e["wTWuc"];
        }
        [_0x5c21("0x447", "dZ3i")](_0x266ad1 = null) {
            let _0x11b466 = this[_0x5c21("0x448", "gT6R")]();
            this[_0x5c21("0x449", "9GG)")](), Laya[_0x5c21("0x44a", "TOp9")][_0x5c21("0x44b", "m*dV")](_0x11b466, new (Laya[_0x5c21("0x44c", "iAvi")])(this, () => {
                this[_0x5c21("0x44d", "([2%")] = {};
                let _0x6d7dbb = this["getAllModelNames"]();
                for (let _0x266ad1 = 0; _0x266ad1 < _0x6d7dbb[_0x5c21("0x44e", "UOab")]; _0x266ad1++) {
                    let _0x38b410 = Laya[_0x5c21("0x44f", "fIRP")]["getRes"](this[_0x5c21("0x450", "4E!&")](_0x6d7dbb[_0x266ad1]));
                    _0x4adf09[_0x5c21("0x451", "&D4Y")][_0x5c21("0x452", "bi^r")](_0x38b410);
                }
                _0x266ad1 && _0x5cbf5e[_0x5c21("0x453", "r#o%")](_0x266ad1);
            }));
        }
        ["getModelByName"](_0x5b8eac) {
            return _0x4adf09["Inst"][_0x5c21("0x454", "hOwa")](_0x5b8eac);
        }
        [_0x5c21("0x455", "fIRP")](_0x445370) {
            return _0x4adf09[_0x5c21("0x417", "Uv]h")]["getPool"](_0x445370);
        }
        ["recoverModel"](_0x5b6adb) {
            _0x4adf09[_0x5c21("0x456", "bi^r")]["recoverPool"](_0x5b6adb);
        }
        [_0x5c21("0x457", "Yd[7")](_0x22bc50) {
            return this["filePath"] + _0x22bc50 + _0x5c21("0x458", "NTNj");
        }
        [_0x5c21("0x459", "TOp9")]() {
            let _0x5b06d9 = [], _0x584ef2 = this[_0x5c21("0x45a", "&D4Y")]();
            for (let _0x5711a9 = 0; _0x5cbf5e[_0x5c21("0x45b", "LDjf")](_0x5711a9, _0x584ef2["length"]); _0x5711a9++) _0x5b06d9[_0x5c21("0x45c", "JzeF")](_0x5cbf5e[_0x5c21("0x45d", "2^mQ")](_0x5cbf5e[_0x5c21("0x45e", "m[2Q")](this["filePath"], _0x584ef2[_0x5711a9]), ".lh"));
            return _0x5b06d9;
        }
        [_0x5c21("0x45f", "omJG")]() {
            let _0x208aee = [], _0x5ed16a = this[_0x5c21("0x460", "GLHs")];
            for (let _0x4f581e = 0; _0x5cbf5e["JqcqT"](_0x4f581e, _0x5ed16a[_0x5c21("0x461", "2CMv")]); _0x4f581e++) _0x208aee[_0x5c21("0x462", "TOp9")](_0x5ed16a[_0x4f581e]);
            return _0x208aee;
        }
        [_0x5c21("0x463", "4E!&")]() {
            var _0x439e56 = {
                eekTr: _0x5c21("0x464", "Yd[7")
            };
            let _0x1893b6 = [];
            for (var _0x5a1707 = 0; _0x5a1707 < 6; _0x5a1707++) _0x1893b6[_0x5c21("0x465", "UOab")](_0x5cbf5e[_0x5c21("0x466", "2^mQ")](this[_0x5c21("0x467", "bi^r")], this[_0x5c21("0x468", "(LPe")]) + (_0x5a1707 + ".jpg"));
            Laya[_0x5c21("0x469", "MjE8")]["create"](_0x1893b6, Laya[_0x5c21("0x46a", "oZew")]["create"](this, () => {
                console[_0x5c21("0x312", "([2%")](_0x439e56[_0x5c21("0x46b", "Uf[4")]);
            }));
        }
        ["getTexture"](_0xd9787) {
            return Laya[_0x5c21("0x46c", "%9(3")][_0x5c21("0x46d", "bi^r")](_0x5cbf5e["wRnta"](_0x5cbf5e[_0x5c21("0x46e", "NTNj")](this[_0x5c21("0x46f", "9T1Q")], this[_0x5c21("0x470", "[GWR")]), _0xd9787 + _0x5c21("0x471", "al%z")));
        }
        static ["getIns"]() {
            return this[_0x5c21("0x472", "hOwa")] || (this[_0x5c21("0x473", "&D4Y")] = new _0x3f5234()), 
            this[_0x5c21("0x474", "nnjN")];
        }
    }
    class _0x6e184f {
        static [_0x5c21("0x475", "Uv]h")](_0x33ec4e, _0x5458ef, _0x50a5c0 = []) {
            if (!_0x5458ef) return _0x50a5c0;
            if (_0x5cbf5e["SXrYM"](_0x5458ef[_0x5c21("0x476", "LDjf")], _0x33ec4e) && _0x50a5c0[_0x5c21("0x477", "2(Lk")](_0x5458ef), 
            !_0x5458ef[_0x5c21("0x478", "(LPe")]) return _0x50a5c0;
            for (var _0x4abc8f = 0; _0x5cbf5e[_0x5c21("0x479", "hOwa")](_0x4abc8f, _0x5458ef["numChildren"]); ++_0x4abc8f) this[_0x5c21("0x47a", "r#o%")](_0x33ec4e, _0x5458ef[_0x5c21("0x47b", "Uv]h")](_0x4abc8f), _0x50a5c0);
            return _0x50a5c0;
        }
        static ["GetComponent"](_0x26ec45, _0x13d563 = null) {
            if (_0x5cbf5e[_0x5c21("0x47c", "(b*P")](!_0x26ec45, !_0x13d563)) return null;
            var _0x5bb457 = _0x13d563[_0x5c21("0x47d", "9GG)")](_0x26ec45);
            if (_0x5bb457) return _0x5bb457;
            if (!_0x13d563[_0x5c21("0x47e", "hOwa")]) return null;
            for (var _0x48e8a8 = 0; _0x5cbf5e[_0x5c21("0x47f", "oZew")](_0x48e8a8, _0x13d563["numChildren"]); ++_0x48e8a8) {
                var _0xca813 = _0x13d563["getChildAt"](_0x48e8a8);
                if (_0xca813 && (_0x5bb457 = this["GetComponent"](_0x26ec45, _0xca813))) return _0x5bb457;
            }
            return null;
        }
        static [_0x5c21("0x480", "oZew")](_0x58fce7, _0x4ab087 = null, _0x1b8fae = []) {
            if (_0x5cbf5e[_0x5c21("0x481", "fIRP")](!_0x58fce7, !_0x4ab087)) return _0x1b8fae;
            if ((_0x401d52 = _0x4ab087["getComponent"](_0x58fce7)) && _0x1b8fae[_0x5c21("0x482", "Yd[7")](_0x401d52), 
            !_0x4ab087[_0x5c21("0x483", "%9(3")]) return _0x1b8fae;
            for (var _0x489332 = 0; _0x5cbf5e[_0x5c21("0x484", ")RsM")](_0x489332, _0x4ab087["numChildren"]); ++_0x489332) {
                var _0x401d52, _0x80586c = _0x4ab087[_0x5c21("0x485", "LDjf")](_0x489332);
                if (_0x80586c["numChildren"]) this[_0x5c21("0x486", "4E!&")](_0x58fce7, _0x80586c, _0x1b8fae); else (_0x401d52 = _0x80586c["getComponent"](_0x58fce7)) && _0x1b8fae["push"](_0x401d52);
            }
            return _0x1b8fae;
        }
        static [_0x5c21("0x487", "oM#F")](_0x40d892) {
            let _0x45b0b4 = [];
            for (let _0x3859ca = 0; _0x5cbf5e[_0x5c21("0x488", "NYmF")](_0x3859ca, _0x40d892[_0x5c21("0x42d", "GLHs")]); _0x3859ca += 2) _0x45b0b4[_0x5c21("0x489", "al%z")](_0x5cbf5e[_0x5c21("0x48a", "rvGE")](_0x5cbf5e[_0x5c21("0x48b", "ikmV")](parseInt, "0x" + _0x40d892["slice"](_0x3859ca, _0x5cbf5e[_0x5c21("0x48c", "8&%b")](_0x3859ca, 2))), 255));
            return new (Laya[_0x5c21("0x48d", "efPG")])(_0x45b0b4[0], _0x45b0b4[1], _0x45b0b4[2], 1);
        }
    }
    class _0x4696aa extends Laya["Script3D"] {
        constructor() {
            super(), this[_0x5c21("0x48e", "r#o%")] = !1;
        }
        [_0x5c21("0x48f", "*$CX")](_0x53675f, _0x14da29) {
            if (this["enabled"] = !0, this[_0x5c21("0x490", "(b*P")] = _0x53675f["ModelName"], 
            this[_0x5c21("0x491", "8&%b")] = _0x53675f[_0x5c21("0x492", "LDjf")], this["model"] = this["owner"], 
            this[_0x5c21("0x493", "nnjN")]["transform"][_0x5c21("0x494", "9T1Q")] = new (Laya[_0x5c21("0x495", "t@qE")])(_0x53675f[_0x5c21("0x496", "NYmF")], _0x53675f["posY"], _0x53675f[_0x5c21("0x497", "*$CX")]), 
            this["model"]["transform"]["rotationEuler"] = new (Laya[_0x5c21("0x498", "AQRo")])(_0x53675f[_0x5c21("0x499", "TOp9")], _0x5cbf5e[_0x5c21("0x49a", "al%z")](_0x53675f[_0x5c21("0x49b", "GLHs")], 180), _0x53675f[_0x5c21("0x49c", "bBqT")]), 
            this[_0x5c21("0x148", "[GWR")][_0x5c21("0x49d", "efPG")][_0x5c21("0x49e", "oM#F")](new Laya["Vector3"](_0x53675f[_0x5c21("0x49f", "4E!&")], _0x53675f[_0x5c21("0x4a0", "m*dV")], _0x53675f["scaleZ"])), 
            this[_0x5c21("0x4a1", "Yd[7")] = !1, this["physics"] = _0x6e184f["GetComponent"](Laya[_0x5c21("0x4a2", "2^mQ")], this["model"]), 
            this[_0x5c21("0x4a3", "MjE8")] && (this["physics"][_0x5c21("0x4a4", "efPG")] = _0x14da29), 
            _0x5cbf5e["EWsWZ"](_0x5cbf5e[_0x5c21("0x4a5", "bBqT")], this["barrierType"])) this[_0x5c21("0x4a6", "&D4Y")] = this["model"]["getChildByName"](_0x5c21("0x4a7", "*$CX"))[_0x5c21("0x4a8", "NYmF")][_0x5c21("0x4a9", "omJG")], 
            this[_0x5c21("0x4aa", "jQ6r")]["tilingOffset"] = new Laya["Vector4"](1, _0x53675f[_0x5c21("0x4ab", "rvGE")], 0, 0); else if (_0x5cbf5e[_0x5c21("0x4ac", "oM#F")](_0x5cbf5e["faJaP"], this["barrierType"]) || "Cylinder006" == this[_0x5c21("0x4ad", "bi^r")]) this["model"][_0x5c21("0x4ae", "bBqT")]["setWorldLossyScale"](new (Laya[_0x5c21("0x4af", "nnjN")])(2, 2, 2)), 
            _0x5cbf5e[_0x5c21("0x4b0", "CvOU")](0, _0x420221[_0x5c21("0x4b1", "4E!&")]()["config"][_0x5c21("0x4b2", "&D4Y")]) && (this["model"]["active"] = !1); else if (_0x5c21("0x4b3", "&D4Y") == this[_0x5c21("0x4b4", "LDjf")]) {
                this["model"]["transform"][_0x5c21("0x4b5", "CvOU")] = new (Laya[_0x5c21("0x4b6", "LDjf")])(_0x53675f[_0x5c21("0x4b7", ")RsM")], _0x53675f[_0x5c21("0x4b8", "(b*P")], _0x5cbf5e["SzuPG"](_0x53675f[_0x5c21("0x4b9", "JzeF")], 4)), 
                this[_0x5c21("0x4ba", "Yd[7")] = this[_0x5c21("0x4bb", "CvOU")][_0x5c21("0x4bc", "UOab")](_0x5c21("0x4bd", "LDjf")), 
                this[_0x5c21("0x4be", "TOp9")][_0x5c21("0x4bf", "AQRo")] = !1, this[_0x5c21("0x4c0", "Uf[4")] = this[_0x5c21("0x4c1", "rvGE")]["transform"][_0x5c21("0x4c2", "dZ3i")][_0x5c21("0x4c3", "rvGE")](), 
                this[_0x5c21("0x4c4", "4yM]")] = this[_0x5c21("0x4c5", "nnjN")][_0x5c21("0x4c6", "bi^r")]["rotationEuler"][_0x5c21("0x4c7", "%9(3")](), 
                this[_0x5c21("0x4c8", "Uv]h")] = this["model"]["getChildByName"](_0x5c21("0x4c9", "2(Lk"))[_0x5c21("0x4ca", "%9(3")](_0x5c21("0x4cb", "ggF#")), 
                this["kedu"]["transform"][_0x5c21("0x4cc", "8&%b")] = new Laya["Vector3"](0, 1.18, .53), 
                this["kedu"]["meshRenderer"][_0x5c21("0x4cd", "MjE8")][_0x5c21("0x4ce", "t@qE")] = 2002, 
                this[_0x5c21("0x4cf", "oZew")] = this[_0x5c21("0x4d0", "iAvi")][_0x5c21("0x4d1", "2^mQ")](_0x5cbf5e[_0x5c21("0x4d2", "bBqT")]) || this[_0x5c21("0x4d3", "r#o%")][_0x5c21("0x4d4", "dZ3i")](), 
                this[_0x5c21("0x4d5", "dZ3i")]["transform"][_0x5c21("0x4d6", "MjE8")] = new (Laya[_0x5c21("0x4d7", "ikmV")])(-.6, 0, 0), 
                this[_0x5c21("0x4d8", "AQRo")][_0x5c21("0x4d9", "9T1Q")](this["keduClone"]), _0x5cbf5e[_0x5c21("0x4da", "Yd[7")](0, _0x420221[_0x5c21("0x4db", "t@qE")]()[_0x5c21("0x4dc", "2(Lk")]["open_tempGame"]) && (this[_0x5c21("0x4dd", "MjE8")][_0x5c21("0x4de", "iAvi")](_0x5cbf5e["BLSOj"])[_0x5c21("0x4df", "LDjf")] = !1, 
                this[_0x5c21("0x4bb", "CvOU")][_0x5c21("0x4e0", "oM#F")](_0x5cbf5e[_0x5c21("0x4e1", "oM#F")])[_0x5c21("0x4e2", "efPG")] = !1);
            }
            _0x5cbf5e[_0x5c21("0x4e3", "jQ6r")](_0x5cbf5e["lCXkU"], this["barrierType"]) && _0x5cbf5e[_0x5c21("0x4e4", "jQ6r")] != this[_0x5c21("0x4e5", "*$CX")] && _0x5cbf5e["pHsuW"]("hotdog", this["barrierType"]) && _0x5cbf5e[_0x5c21("0x4e6", "JzeF")](_0x5cbf5e[_0x5c21("0x4e7", "al%z")], this[_0x5c21("0x4e8", "ggF#")]) && _0x5cbf5e[_0x5c21("0x4e9", "Yd[7")]("Tomato", this["barrierType"]) && _0x5cbf5e[_0x5c21("0x4ea", "([2%")](_0x5cbf5e[_0x5c21("0x4eb", "dZ3i")], this[_0x5c21("0x4ad", "bi^r")]) && _0x5cbf5e[_0x5c21("0x4ec", "gT6R")] != this[_0x5c21("0x4ed", "2(Lk")] && _0x5cbf5e["WYaJJ"](_0x5c21("0x4ee", "2CMv"), this[_0x5c21("0x4ef", "bBqT")]) || 0 == _0x420221[_0x5c21("0x142", "rvGE")]()["config"][_0x5c21("0x4f0", "*$CX")] && (this["model"]["active"] = !1);
        }
        [_0x5c21("0x4f1", "omJG")]() {
            _0x5cbf5e[_0x5c21("0x4f2", "8&%b")] != this[_0x5c21("0x4f3", "gT6R")] && _0x5cbf5e["WYaJJ"](_0x5cbf5e[_0x5c21("0x4f4", "2^mQ")], this["barrierType"]) || this["model"]["transform"]["rotate"](new (Laya[_0x5c21("0x498", "AQRo")])(0, .05, 0), !1);
        }
        [_0x5c21("0x4f5", "%9(3")]() {
            this[_0x5c21("0x4f6", "ikmV")]["active"] = !1, Laya["timer"]["clearAll"](this), 
            this[_0x5c21("0x4f7", "gT6R")] = !1, this["destroy"]();
        }
        [_0x5c21("0x4f8", "2^mQ")](_0x87635a, _0x36d9d0, _0x57c67f) {
            this[_0x5c21("0x4f9", "(b*P")][_0x5c21("0x4fa", "2CMv")]["position"] = _0x87635a[_0x5c21("0x4fb", "gT6R")][_0x5c21("0x4fc", "([2%")], 
            this[_0x5c21("0x4fd", "gT6R")][_0x5c21("0x4fe", "([2%")][_0x5c21("0x4ff", "ikmV")] = _0x87635a[_0x5c21("0x500", "*$CX")][_0x5c21("0x501", "(LPe")], 
            this["camera"]["active"] = !0, _0x87635a[_0x5c21("0x502", "dZ3i")] = !1;
            let _0x3527a2 = this[_0x5c21("0x503", "ggF#")]["transform"][_0x5c21("0x504", "4E!&")]["clone"](), _0x1cc5d3 = this[_0x5c21("0x505", "iAvi")][_0x5c21("0x506", "UOab")]["rotationEuler"]["clone"](), _0x2780a3 = Laya[_0x5c21("0x507", "Yd[7")]["to"](_0x3527a2, {
                x: this[_0x5c21("0x4c0", "Uf[4")]["x"],
                y: this[_0x5c21("0x508", "dZ3i")]["y"],
                z: this[_0x5c21("0x509", "NYmF")]["z"],
                update: new Laya["Handler"](this, () => {
                    this[_0x5c21("0x50a", "m*dV")][_0x5c21("0x50b", "oZew")][_0x5c21("0x50c", "GLHs")] = _0x3527a2;
                })
            }, 800, Laya["Ease"]["linearNone"], Laya[_0x5c21("0x50d", "oM#F")][_0x5c21("0x50e", "2CMv")](this, () => {
                Laya["Tween"][_0x5c21("0x50f", "JzeF")](_0x2780a3);
            })), _0x2eb7dd = Laya["Tween"]["to"](_0x1cc5d3, {
                x: this[_0x5c21("0x510", "2CMv")]["x"],
                y: this[_0x5c21("0x511", "MjE8")]["y"],
                z: this[_0x5c21("0x512", "Yd[7")]["z"],
                update: new (Laya[_0x5c21("0x513", "MjE8")])(this, () => {
                    this[_0x5c21("0x4be", "TOp9")][_0x5c21("0x514", "ikmV")][_0x5c21("0x515", "AQRo")] = _0x1cc5d3;
                })
            }, 800, Laya[_0x5c21("0x516", "ikmV")][_0x5c21("0x517", "9T1Q")], Laya[_0x5c21("0x518", "GLHs")][_0x5c21("0x50e", "2CMv")](this, () => {
                Laya[_0x5c21("0x519", "4yM]")]["clear"](_0x2eb7dd), Laya[_0x5c21("0x51a", "[GWR")]["to"](this["kedu"]["transform"], {
                    localPositionX: .6
                }, 1e3, Laya[_0x5c21("0x51b", "9T1Q")]["linearNone"], Laya[_0x5c21("0x513", "MjE8")]["create"](this, () => {
                    var _0x21d875 = {
                        OCFQo: function _0x1807ae(_0x577f60) {
                            return _0x577f60();
                        }
                    };
                    let _0x36d9d0 = _0x87635a["transform"]["position"][_0x5c21("0x51c", "LDjf")](), _0x530291 = _0x87635a[_0x5c21("0x514", "ikmV")][_0x5c21("0x51d", ")RsM")][_0x5c21("0x51e", "Uv]h")](), _0x3d7466 = Laya[_0x5c21("0x51f", "ggF#")]["to"](_0x3527a2, {
                        x: _0x36d9d0["x"],
                        y: _0x36d9d0["y"],
                        z: _0x36d9d0["z"],
                        update: new (Laya[_0x5c21("0x50d", "oM#F")])(this, () => {
                            this["camera"]["transform"]["position"] = _0x3527a2;
                        })
                    }, 800, Laya[_0x5c21("0x520", "nnjN")][_0x5c21("0x521", "m[2Q")], Laya["Handler"][_0x5c21("0x522", "JzeF")](this, () => {
                        Laya[_0x5c21("0x523", "efPG")]["clear"](_0x3d7466);
                    })), _0x2682d3 = Laya[_0x5c21("0x524", "2CMv")]["to"](_0x1cc5d3, {
                        x: _0x530291["x"],
                        y: _0x530291["y"],
                        z: _0x530291["z"],
                        update: new Laya["Handler"](this, () => {
                            this[_0x5c21("0x525", "dZ3i")][_0x5c21("0x526", "2(Lk")]["rotationEuler"] = _0x1cc5d3;
                        })
                    }, 800, Laya[_0x5c21("0x527", "NYmF")][_0x5c21("0x528", "nnjN")], Laya[_0x5c21("0x529", "r#o%")]["create"](this, () => {
                        Laya[_0x5c21("0x52a", "8&%b")][_0x5c21("0x52b", "rvGE")](_0x2682d3), this[_0x5c21("0x52c", "&D4Y")]["active"] = !1, 
                        this[_0x5c21("0x52d", "9T1Q")][_0x5c21("0x52e", "al%z")][_0x5c21("0x52f", "r#o%")] = this["cameraPos"], 
                        this[_0x5c21("0x530", "oZew")][_0x5c21("0x531", "9GG)")]["rotationEuler"] = this["cameraRot"], 
                        _0x87635a[_0x5c21("0x532", "fIRP")] = !0, _0x57c67f && _0x21d875[_0x5c21("0x533", "al%z")](_0x57c67f);
                    }));
                }));
            })), _0x1a07a3 = this[_0x5c21("0x534", "4E!&")][_0x5c21("0x535", "%9(3")][_0x5c21("0x536", "NTNj")];
            _0x1a07a3[_0x5c21("0x537", "Yd[7")] = _0x3f5234["getIns"]()[_0x5c21("0x538", "iAvi")](_0x5cbf5e[_0x5c21("0x539", "NYmF")](_0x36d9d0, 1)), 
            _0x1a07a3["renderQueue"] = 2002;
        }
    }
    class _0x3678cc extends Laya[_0x5c21("0x53a", "hOwa")] {
        [_0x5c21("0x53b", "hOwa")](_0x1041d9, _0xb92938, _0x58d6c8 = _0x5c21("0x53c", "m*dV")) {
            let _0x3f9f24 = this["owner"];
            _0x3f9f24[_0x5c21("0x53d", "efPG")] = 1, _0x3f9f24[_0x5c21("0x53e", "bi^r")] = _0xb92938, 
            _0x3f9f24["color"] = _0x58d6c8, _0x3f9f24[_0x5c21("0x53f", "AQRo")](_0x1041d9["x"], _0x1041d9["y"]), 
            Laya["Tween"]["to"](_0x3f9f24, {
                y: _0x5cbf5e["SzuPG"](_0x3f9f24["y"], 200)
            }, 1500), Laya["Tween"]["to"](_0x3f9f24, {
                alpha: .3
            }, 500, Laya[_0x5c21("0x540", "oM#F")][_0x5c21("0x541", "2^mQ")], null, 800), Laya[_0x5c21("0x542", "t@qE")]["once"](1500, this, this[_0x5c21("0x543", "AQRo")]);
        }
        ["Exit"]() {
            this[_0x5c21("0x544", "r#o%")][_0x5c21("0x545", "NTNj")](), Laya[_0x5c21("0x546", "hOwa")]["recover"]("WordTips", this[_0x5c21("0x547", "ikmV")]);
        }
        [_0x5c21("0x548", "2(Lk")]() {
            this[_0x5c21("0x549", "iAvi")][_0x5c21("0x54a", "[GWR")](), Laya[_0x5c21("0x54b", "(LPe")][_0x5c21("0x54c", "iAvi")](_0x5cbf5e[_0x5c21("0x54d", "4yM]")], this[_0x5c21("0x54e", "Uf[4")]);
        }
        static [_0x5c21("0x54f", "t@qE")](_0x553443, _0x2699a5, _0x2b2b84 = _0x5c21("0x550", "2^mQ")) {
            let _0x52cf24 = new (Laya[_0x5c21("0x551", "2(Lk")])();
            _0x52cf24[_0x5c21("0x552", "bi^r")] = Laya["loader"][_0x5c21("0x553", "MjE8")](_0x5cbf5e[_0x5c21("0x554", "hOwa")]);
            let _0x202047 = Laya[_0x5c21("0x555", "bBqT")][_0x5c21("0x556", "&D4Y")](_0x5cbf5e["wfXuJ"], _0x52cf24[_0x5c21("0x522", "JzeF")], _0x52cf24);
            Laya[_0x5c21("0x261", "CvOU")][_0x5c21("0x557", "GLHs")](_0x202047), _0x202047[_0x5c21("0x558", "MjE8")](_0x3678cc)[_0x5c21("0x559", "m[2Q")](_0x553443, _0x2699a5, _0x2b2b84);
        }
    }
    class _0x7ecc3a extends Laya[_0x5c21("0x55a", "NTNj")] {
        constructor() {
            super(...arguments), this[_0x5c21("0x55b", "oZew")] = null, this[_0x5c21("0x55c", "UOab")] = null, 
            this[_0x5c21("0x55d", "8&%b")] = null, this["followObj"] = null, this[_0x5c21("0x55e", "efPG")] = null, 
            this[_0x5c21("0x55f", "ikmV")] = !0, this["tw"] = null, this["perFrame"] = 2, this[_0x5c21("0x560", "gT6R")] = !1, 
            this["frameFlag"] = 10, this[_0x5c21("0x561", "LDjf")] = 0, this[_0x5c21("0x562", "UOab")] = 0, 
            this["cameraOffZ"] = 0, this[_0x5c21("0x563", "bi^r")] = !1, this[_0x5c21("0x564", "ikmV")] = !0, 
            this["isChangeTarget"] = !1, this[_0x5c21("0x565", "fIRP")] = !0;
        }
        [_0x5c21("0x566", "fIRP")]() {}
        [_0x5c21("0x567", "al%z")]() {
            this[_0x5c21("0x52c", "&D4Y")][_0x5c21("0x568", "2CMv")] && (this["cameraFollow"](.05), 
            this["updateCamera"]());
        }
        [_0x5c21("0x569", "fIRP")](_0x3269ad, _0x273d20, _0x3a8481, _0x2e6f00, _0x3027eb) {
            this[_0x5c21("0x56a", "2(Lk")] = _0x3269ad, this[_0x5c21("0x505", "iAvi")] = _0x273d20, 
            this[_0x5c21("0x56b", "[GWR")] = _0x3a8481, _0x2e6f00 && (this[_0x5c21("0x56c", "Uv]h")] = _0x2e6f00), 
            _0x3027eb && (this[_0x5c21("0x56d", "jQ6r")] = !1);
        }
        [_0x5c21("0x56e", "ggF#")]() {
            this[_0x5c21("0x56f", "hOwa")] = !0;
        }
        [_0x5c21("0x570", "%9(3")]() {
            this[_0x5c21("0x571", "efPG")] = !1;
        }
        [_0x5c21("0x572", "nnjN")]() {
            this[_0x5c21("0x573", "CvOU")] && this[_0x5c21("0x574", "ggF#")] && this["obj"]["transform"] && (this[_0x5c21("0x575", "Yd[7")][_0x5c21("0x49d", "efPG")][_0x5c21("0x576", "bi^r")] = new (Laya[_0x5c21("0x577", "rvGE")])(this[_0x5c21("0x578", "8&%b")]["transform"][_0x5c21("0x579", "efPG")]["x"], this[_0x5c21("0x57a", "r#o%")][_0x5c21("0x57b", "JzeF")][_0x5c21("0x4fc", "([2%")]["y"], this["obj"][_0x5c21("0x57c", "2^mQ")][_0x5c21("0x57d", "ikmV")]["z"]));
        }
        [_0x5c21("0x57e", "4yM]")](_0x5b3adb) {
            if (this[_0x5c21("0x57f", "GLHs")] && this[_0x5c21("0x580", "LDjf")]) {
                var _0x18e41f = this["followObj"][_0x5c21("0x581", "GLHs")][_0x5c21("0x582", "m[2Q")], _0x3c3f37 = this[_0x5c21("0x583", "iAvi")](_0x18e41f["x"], this["obj"]["transform"]["position"]["x"], _0x5b3adb), _0x1100a5 = this[_0x5c21("0x584", "Uv]h")](_0x18e41f["y"], this[_0x5c21("0x585", "fIRP")]["transform"][_0x5c21("0x586", "rvGE")]["y"], _0x5b3adb), _0x4bc777 = this[_0x5c21("0x587", "bBqT")](_0x18e41f["z"], this["obj"][_0x5c21("0x588", "(LPe")]["position"]["z"], 1);
                this[_0x5c21("0x589", "2(Lk")] ? this[_0x5c21("0x58a", "([2%")][_0x5c21("0x58b", "4E!&")][_0x5c21("0x58c", "m[2Q")] = _0x1100a5 + this[_0x5c21("0x58d", "hOwa")] : this[_0x5c21("0x58e", "t@qE")][_0x5c21("0x581", "GLHs")][_0x5c21("0x58f", "LDjf")] = new (Laya[_0x5c21("0x590", "dZ3i")])(_0x3c3f37 + this[_0x5c21("0x591", "4yM]")], _0x1100a5 + this[_0x5c21("0x592", "gT6R")], _0x4bc777 + this[_0x5c21("0x593", "ikmV")]);
            }
        }
        [_0x5c21("0x594", "2CMv")](_0xad2c0e) {
            this[_0x5c21("0x595", "TOp9")] = !1, console[_0x5c21("0x596", "m[2Q")](_0x5c21("0x597", "8&%b"), this["followObj"][_0x5c21("0x598", "t@qE")][_0x5c21("0x599", "jQ6r")]), 
            Laya[_0x5c21("0x59a", "NYmF")]["to"](this[_0x5c21("0x59b", "LDjf")]["transform"], {
                localRotationEulerY: this[_0x5c21("0x59c", "bi^r")][_0x5c21("0x59d", "jQ6r")][_0x5c21("0x59e", "&D4Y")] + _0xad2c0e
            }, 800, Laya["Ease"][_0x5c21("0x59f", "AQRo")], Laya[_0x5c21("0x5a0", "4yM]")][_0x5c21("0x5a1", "%9(3")](this, this[_0x5c21("0x5a2", "(b*P")]));
        }
        [_0x5c21("0x5a3", "nnjN")]() {
            console[_0x5c21("0x1dd", "jQ6r")](_0x5c21("0x5a4", "hOwa"), this[_0x5c21("0x5a5", "ikmV")][_0x5c21("0x5a6", "rvGE")][_0x5c21("0x5a7", "MjE8")]);
        }
        [_0x5c21("0x5a8", "Uv]h")](_0x2b3c67) {
            this[_0x5c21("0x5a9", "t@qE")] = _0x2b3c67, this[_0x5c21("0x5aa", "oZew")] = !1, 
            this[_0x5c21("0x5ab", "([2%")] = !1;
            let _0x1684e2 = new (Laya[_0x5c21("0x5ac", "Uf[4")])(), _0x7c806c = new (Laya[_0x5c21("0x5ad", "efPG")])();
            this[_0x5c21("0x5ae", "rvGE")][_0x5c21("0x5af", "oM#F")][_0x5c21("0x5b0", "([2%")](_0x7c806c), 
            console[_0x5c21("0x5b1", "(LPe")](_0x5c21("0x5b2", "8&%b"), _0x7c806c), Laya["Vector3"][_0x5c21("0x5b3", "*$CX")](this[_0x5c21("0x580", "LDjf")][_0x5c21("0x5b4", "9T1Q")][_0x5c21("0x504", "4E!&")], _0x2b3c67[_0x5c21("0x5a6", "rvGE")]["position"], _0x1684e2), 
            Laya[_0x5c21("0x5b5", "&D4Y")][_0x5c21("0x5b6", "Uf[4")](_0x1684e2, _0x1684e2), 
            Laya[_0x5c21("0x590", "dZ3i")][_0x5c21("0x5b7", "(LPe")](_0x7c806c, _0x7c806c), 
            console["log"](_0x5c21("0x5b8", "oZew"), _0x1684e2);
            let _0x180af0 = Laya[_0x5c21("0x5b9", "jQ6r")][_0x5c21("0x5ba", "JzeF")](new (Laya[_0x5c21("0x5bb", "bi^r")])(_0x7c806c["x"], _0x7c806c["z"]), new Laya["Vector2"](_0x1684e2["x"], _0x1684e2["z"])), _0x39c80d = _0x5cbf5e[_0x5c21("0x5bc", "jQ6r")](_0x180af0, Laya["Vector2"][_0x5c21("0x5bd", "iAvi")](new (Laya[_0x5c21("0x5be", "Uv]h")])(_0x7c806c["x"], _0x7c806c["z"])) * Laya["Vector2"]["scalarLength"](new (Laya[_0x5c21("0x5bf", "bBqT")])(_0x1684e2["x"], _0x1684e2["z"])));
            _0x180af0 = Laya[_0x5c21("0x5c0", "iAvi")][_0x5c21("0x5c1", "bi^r")](Math[_0x5c21("0x5c2", "2(Lk")](_0x39c80d)), 
            _0x5cbf5e["XMBlM"](Math[_0x5c21("0x5c3", "m[2Q")](_0x7c806c["z"]), .9) && (_0x5cbf5e[_0x5c21("0x5c4", "iAvi")](_0x7c806c["z"], 0) && (_0x180af0 *= -1), 
            _0x5cbf5e["HcVTs"](_0x1684e2["x"], 0) && (_0x180af0 *= -1)), Math[_0x5c21("0x5c5", "t@qE")](_0x7c806c["x"]) > .9 && (_0x5cbf5e["ekhki"](_0x7c806c["x"], 0) && (_0x180af0 *= -1), 
            _0x1684e2["z"] > 0 && (_0x180af0 *= -1)), this[_0x5c21("0x5c6", "&D4Y")](_0x180af0), 
            console["log"](_0x5cbf5e[_0x5c21("0x5c7", "dZ3i")], _0x180af0);
        }
        [_0x5c21("0x5c8", "NYmF")]() {
            if (!this[_0x5c21("0x5c9", "r#o%")]) return;
            let _0x48aa86 = this["followObj"]["transform"]["localRotationEulerY"], _0xd7a5ff = this[_0x5c21("0x5ca", "(b*P")][_0x5c21("0x5cb", "m*dV")][_0x5c21("0x5cc", "[GWR")]["y"];
            this[_0x5c21("0x5cd", "NYmF")] || (_0xd7a5ff += 180), _0x5cbf5e[_0x5c21("0x5ce", "gT6R")](_0x48aa86, -100) && _0x5cbf5e[_0x5c21("0x5cf", "dZ3i")](_0xd7a5ff, 100) ? (_0x48aa86 = 360 + _0x48aa86, 
            this[_0x5c21("0x575", "Yd[7")][_0x5c21("0x526", "2(Lk")][_0x5c21("0x5d0", "UOab")] = _0x48aa86) : _0x5cbf5e[_0x5c21("0x5d1", "efPG")](_0x48aa86, 100) && _0x5cbf5e["GjKaT"](_0xd7a5ff, -100) && (_0x48aa86 -= 360, 
            this[_0x5c21("0x5d2", "8&%b")][_0x5c21("0x4fe", "([2%")][_0x5c21("0x5d3", "(b*P")] = _0x48aa86);
            let _0x422de5 = Laya[_0x5c21("0x5d4", "TOp9")]["lerp"](_0x48aa86, _0xd7a5ff, .1);
            this[_0x5c21("0x5d5", "CvOU")]["transform"][_0x5c21("0x5d6", "NYmF")] = _0x422de5;
        }
        [_0x5c21("0x5d7", "JzeF")]() {
            let _0xc9af3f = this["followObj"]["transform"][_0x5c21("0x5d8", "hOwa")], _0x5b73c2 = this["changeTargetSp"][_0x5c21("0x5d9", "CvOU")][_0x5c21("0x5da", "bi^r")];
            _0xc9af3f < -100 && _0x5b73c2 > 100 ? (_0xc9af3f = _0x5cbf5e["LLNfe"](360, _0xc9af3f), 
            this["followObj"][_0x5c21("0x5db", "Uv]h")][_0x5c21("0x5dc", "rvGE")] = _0xc9af3f) : _0x5cbf5e["hvpyw"](_0xc9af3f, 100) && _0x5cbf5e[_0x5c21("0x5dd", "9GG)")](_0x5b73c2, -100) && (_0xc9af3f -= 360, 
            this[_0x5c21("0x575", "Yd[7")][_0x5c21("0x4fb", "gT6R")][_0x5c21("0x5de", "2(Lk")] = _0xc9af3f), 
            _0x5b73c2 += 180;
            let _0x17c510 = Laya[_0x5c21("0x5df", "9GG)")]["lerp"](_0xc9af3f, _0x5b73c2, .1);
            _0x5cbf5e[_0x5c21("0x5e0", "9GG)")](Math[_0x5c21("0x5e1", "LDjf")](_0x5cbf5e[_0x5c21("0x5e2", "ggF#")](_0xc9af3f, _0x5b73c2)), 350) && (_0x17c510 = _0x5b73c2), 
            this[_0x5c21("0x5e3", "gT6R")][_0x5c21("0x5e4", "4yM]")][_0x5c21("0x5d8", "hOwa")] = _0x17c510;
        }
        [_0x5c21("0x5e5", "AQRo")](_0x2bc4aa, _0x3c5378, _0x545ab8) {
            return _0x545ab8 <= 0 ? _0x2bc4aa : _0x5cbf5e["IxIRs"](_0x545ab8, 1) ? _0x3c5378 : _0x545ab8 * _0x3c5378 + _0x5cbf5e[_0x5c21("0x5e6", "[GWR")](1 - _0x545ab8, _0x2bc4aa);
        }
        [_0x5c21("0x5e7", "9GG)")]() {
            var _0x55e091 = {
                WPPwv: function _0x21cfb5(_0x39f5e0, _0x467f5b) {
                    return _0x5cbf5e[_0x5c21("0x5e8", "NTNj")](_0x39f5e0, _0x467f5b);
                },
                DSnyu: function _0x59e972(_0x230a17, _0x4fe1d2) {
                    return _0x230a17 / _0x4fe1d2;
                }
            };
            if (!this[_0x5c21("0x5e9", "NTNj")]) return;
            if (!this[_0x5c21("0x5ea", "efPG")]["transform"]) return void console[_0x5c21("0x5eb", "iAvi")](_0x5cbf5e[_0x5c21("0x5ec", "4E!&")]);
            let _0x531865 = this["followObj"][_0x5c21("0x5ed", "NYmF")][_0x5c21("0x5ee", "t@qE")];
            this[_0x5c21("0x5ef", "oM#F")] && (_0x5cbf5e[_0x5c21("0x5f0", "2(Lk")](_0x531865, 0) && _0x5cbf5e["hhihN"](_0x531865, 180) ? _0x531865 -= 180 : _0x5cbf5e["iQphq"](_0x531865, 0) && _0x5cbf5e[_0x5c21("0x5f1", "&D4Y")](_0x531865, -180) && (_0x531865 += 180));
            let _0x2948f8 = this[_0x5c21("0x5f2", "Uv]h")][_0x5c21("0x5f3", "(b*P")]["rotationEuler"]["y"], _0xf586d5 = 0, _0x559273 = 0;
            _0x5cbf5e["ZVwwc"](_0x531865, -180) && _0x531865 <= -120 && _0x5cbf5e[_0x5c21("0x5f4", "2(Lk")](_0x2948f8, 180) && _0x5cbf5e[_0x5c21("0x5f5", "oM#F")](_0x2948f8, 120) ? (_0xf586d5 = _0x5cbf5e["SzuPG"](_0x531865, -180) + (180 - _0x2948f8), 
            _0x559273 = 1) : _0x5cbf5e["ySbbz"](_0x2948f8, -180) && _0x2948f8 <= -120 && _0x5cbf5e[_0x5c21("0x5f6", "4yM]")](_0x531865, 180) && _0x531865 >= 120 ? (_0xf586d5 = _0x5cbf5e[_0x5c21("0x5f7", "ikmV")](_0x2948f8 - -180, 180 - _0x531865), 
            _0x559273 = -1) : _0x2948f8 > _0x531865 ? (_0xf586d5 = _0x5cbf5e["MRcqY"](_0x2948f8, _0x531865), 
            _0x559273 = -1) : (_0xf586d5 = _0x5cbf5e["YEgHC"](_0x531865, _0x2948f8), _0x559273 = 1);
            this["tw"] && Laya[_0x5c21("0x5f8", "nnjN")][_0x5c21("0x5f9", "4E!&")](this["tw"]), 
            this["tw"] = Laya[_0x5c21("0x5fa", "Uv]h")]["to"]({
                value: 0
            }, {
                value: 1,
                update: new (Laya[_0x5c21("0x5fb", "CvOU")])(this, _0x42aa08 => {
                    this["followObj"] && this[_0x5c21("0x5d2", "8&%b")][_0x5c21("0x5fc", "ggF#")] && (_0x55e091["WPPwv"](1, _0x559273) ? this[_0x5c21("0x5fd", "9GG)")]["transform"]["rotate"](new (Laya[_0x5c21("0x5fe", "Yd[7")])(0, _0x55e091[_0x5c21("0x5ff", "nnjN")](-_0xf586d5, this[_0x5c21("0x600", "Uv]h")]), 0), !1, !1) : this[_0x5c21("0x601", "jQ6r")]["transform"][_0x5c21("0x602", "rvGE")](new Laya["Vector3"](0, _0xf586d5 / this[_0x5c21("0x603", "CvOU")], 0), !1, !1), 
                    0);
                })
            }, Math[_0x5c21("0x604", "oM#F")](_0x5cbf5e[_0x5c21("0x605", "nnjN")](1e3, this["perFrame"]) / 60), Laya["Ease"][_0x5c21("0x606", "hOwa")], new (Laya[_0x5c21("0x607", "[GWR")])(this, () => {}), 0, !0, !0);
        }
        [_0x5c21("0x608", "NTNj")]() {
            this["tw"] && Laya[_0x5c21("0x609", "t@qE")][_0x5c21("0x60a", "&D4Y")](this["tw"]), 
            this["isAutoCorrect"] = !1;
        }
        ["continueCameraMove"](_0x189433) {
            _0x189433 && (this[_0x5c21("0x60b", ")RsM")]["transform"]["localPosition"] = _0x189433), 
            this["isAutoCorrect"] = !0, this[_0x5c21("0x60c", "UOab")] && this[_0x5c21("0x60d", "jQ6r")][_0x5c21("0x60e", "(LPe")] || (this["camera"][_0x5c21("0x60f", "hOwa")] = !0);
        }
    }
    class _0x3c390a extends Laya["AnimatorStateScript"] {
        constructor() {
            super();
        }
        ["init"](_0x4086d7) {
            this[_0x5c21("0x610", "m[2Q")] = _0x4086d7;
        }
        [_0x5c21("0x611", "bi^r")]() {}
        [_0x5c21("0x612", "iAvi")]() {}
        [_0x5c21("0x613", "bBqT")]() {
            this[_0x5c21("0x614", "*$CX")][_0x5c21("0x615", "GLHs")]();
        }
    }
    !function(_0x546d75) {
        _0x546d75[_0x5c21("0x616", ")RsM")] = _0x5c21("0x617", "CvOU"), _0x546d75[_0x5c21("0x618", "2^mQ")] = _0x5cbf5e["IYsuA"], 
        _0x546d75["Dance"] = _0x5cbf5e["EWeGE"], _0x546d75["Gang"] = _0x5cbf5e[_0x5c21("0x619", "MjE8")], 
        _0x546d75[_0x5c21("0x61a", "2CMv")] = _0x5cbf5e[_0x5c21("0x61b", "Uv]h")], _0x546d75["Eat"] = _0x5cbf5e[_0x5c21("0x61c", "TOp9")];
    }(_0xd1f1d2 || (_0xd1f1d2 = {}));
    class _0x1848f7 extends Laya[_0x5c21("0x61d", "Uf[4")] {
        constructor() {
            super(), this[_0x5c21("0x61e", "hOwa")] = .04, this[_0x5c21("0x61f", "JzeF")] = !1, 
            this["bodyLevel"] = 0, this[_0x5c21("0x620", "m[2Q")] = [], this[_0x5c21("0x621", "8&%b")] = [], 
            this[_0x5c21("0x622", "bi^r")] = null, this[_0x5c21("0x623", "hOwa")] = new Laya["Vector3"](0, 0, 0);
        }
        [_0x5c21("0x624", "al%z")]() {
            this[_0x5c21("0x625", "omJG")] = this[_0x5c21("0x626", "8&%b")][_0x5c21("0x627", "[GWR")];
            for (let _0x679ce5 = 1; _0x679ce5 < 6; _0x679ce5++) {
                let _0x122279 = this[_0x5c21("0x628", "t@qE")][_0x5c21("0x629", "ikmV")](_0x5c21("0x62a", "ggF#") + _0x679ce5);
                this["playerArr"][_0x5c21("0x62b", "4E!&")](_0x122279), _0x122279[_0x5c21("0x62c", "oM#F")] = !1;
            }
            this["gameScene"] = this[_0x5c21("0x62d", "JzeF")][_0x5c21("0x62e", "t@qE")][_0x5c21("0x629", "ikmV")](_0x5c21("0x62f", "NTNj")), 
            this["camera"] = _0x3c1d73[_0x5c21("0x630", "9GG)")][_0x5c21("0x631", "t@qE")]["MainCamera"], 
            this["cameraCtrl"] = this["camera"]["getComponent"](_0x7ecc3a), this[_0x5c21("0x632", "gT6R")] = !1, 
            this[_0x5c21("0x633", "ikmV")](), this["playAni"](_0xd1f1d2[_0x5c21("0x634", "TOp9")]);
        }
        [_0x5c21("0x635", "([2%")]() {
            this[_0x5c21("0x636", "NYmF")] = this["playerArr"][this[_0x5c21("0x637", "iAvi")]], 
            this[_0x5c21("0x638", "([2%")]["active"] = !0, this["_curTrans"] = this[_0x5c21("0x639", "AQRo")][_0x5c21("0x52e", "al%z")], 
            this["_curAni"] = _0x6e184f[_0x5c21("0x63a", "TOp9")](Laya[_0x5c21("0x63b", "%9(3")], this[_0x5c21("0x63c", "TOp9")]), 
            this["_curAni"]["getControllerLayer"](0)[_0x5c21("0x63d", "efPG")](_0xd1f1d2[_0x5c21("0x63e", "bBqT")])["addScript"](_0x3c390a)["init"](this), 
            this[_0x5c21("0x63f", "AQRo")][_0x5c21("0x640", "CvOU")] = new (Laya[_0x5c21("0x641", "[GWR")])(0, .05, 0), 
            this[_0x5c21("0x642", "bBqT")][_0x5c21("0x643", "al%z")] = new (Laya[_0x5c21("0x644", "m*dV")])(0, 0, 0), 
            this[_0x5c21("0x645", "(b*P")][_0x5c21("0x646", "fIRP")](new (Laya[_0x5c21("0x647", "TOp9")])(1, 1, 1)), 
            this[_0x5c21("0x648", "iAvi")] && this["lastBody"] != this[_0x5c21("0x649", "ggF#")] && (this[_0x5c21("0x64a", "Uf[4")]["active"] = !1, 
            this[_0x5c21("0x64b", "4yM]")][_0x5c21("0x64c", "iAvi")]["setWorldLossyScale"](new Laya["Vector3"](1, 1, 1))), 
            this[_0x5c21("0x64d", "AQRo")] = this[_0x5c21("0x64e", "rvGE")];
            let _0x153e80 = _0x6e184f["m_FindChildsByName"](_0x5cbf5e["ClynZ"], this[_0x5c21("0x64f", "[GWR")]);
            this["phcPonit"] = _0x153e80[0], this[_0x5c21("0x650", "4E!&")]["length"] = 0, this[_0x5c21("0x651", "2CMv")] = _0x6e184f["m_FindChildsByName"](_0x5c21("0x652", "iAvi"), this[_0x5c21("0x653", ")RsM")]);
        }
        [_0x5c21("0x654", "nnjN")]() {
            this[_0x5c21("0x655", "ikmV")]["z"] = this[_0x5c21("0x656", "rvGE")];
        }
        [_0x5c21("0x657", "rvGE")]() {
            this[_0x5c21("0x658", "TOp9")]["x"] = this[_0x5c21("0x659", "2^mQ")]["z"] = 0;
        }
        [_0x5c21("0x65a", "oM#F")]() {
            this[_0x5c21("0x65b", "UOab")] = 0, this[_0x5c21("0x65c", "omJG")](), this[_0x5c21("0x65d", "9T1Q")](_0xd1f1d2["Idle"]), 
            this[_0x5c21("0x65e", "jQ6r")] = !1;
        }
        ["playAni"](_0x71072e) {
            this[_0x5c21("0x65f", "hOwa")][_0x5c21("0x660", "2^mQ")](_0x71072e, .01, 0), this[_0x5c21("0x661", "&D4Y")] = _0x71072e;
        }
        [_0x5c21("0x662", "LDjf")]() {
            this["playAni"](_0xd1f1d2[_0x5c21("0x663", "NTNj")]);
        }
        ["onTriggerEnter"](_0x5849fb) {
            if (!this["isStop"]) switch (this["curState"] == _0xd1f1d2[_0x5c21("0x664", "AQRo")] ? this[_0x5c21("0x665", "NTNj")]() : this[_0x5c21("0x666", "oZew")] == _0xd1f1d2[_0x5c21("0x667", "2CMv")] && this[_0x5c21("0x668", "rvGE")](), 
            Laya["SoundManager"]["playSound"](_0x5cbf5e[_0x5c21("0x669", "TOp9")]), _0x5849fb[_0x5c21("0x66a", "m[2Q")][_0x5c21("0x66b", "9T1Q")]) {
              case 8:
                _0x5cbf5e[_0x5c21("0x66c", "gT6R")](_0x5cbf5e[_0x5c21("0x66d", "JzeF")], _0x5849fb["owner"][_0x5c21("0x66e", "rvGE")]) || _0x5cbf5e["SrSDd"] == _0x5849fb["owner"][_0x5c21("0x66f", "m[2Q")] ? _0x3c1d73[_0x5c21("0x670", "Uf[4")][_0x5c21("0x671", "([2%")][_0x5c21("0x672", "hOwa")](1) : _0x5cbf5e[_0x5c21("0x673", "m[2Q")](_0x5cbf5e[_0x5c21("0x674", "JzeF")], _0x5849fb["owner"][_0x5c21("0x675", "2(Lk")]) && _0x3c1d73[_0x5c21("0x676", "2CMv")][_0x5c21("0x677", "efPG")][_0x5c21("0x678", "bi^r")](3), 
                this[_0x5c21("0x679", "fIRP")](_0x5849fb[_0x5c21("0x67a", "(b*P")][_0x5c21("0x4fe", "([2%")][_0x5c21("0x67b", "gT6R")], "+1"), 
                this["bodyLevel"] += 1, this[_0x5c21("0x67c", "(LPe")] >= 5 ? (this[_0x5c21("0x67d", "gT6R")] = 4, 
                this["playAni"](_0xd1f1d2[_0x5c21("0x67e", "efPG")]), _0x5849fb["owner"]["active"] = !1) : (_0x5849fb["owner"][_0x5c21("0x67f", "ikmV")] = !1, 
                Laya["Tween"]["to"](this[_0x5c21("0x680", "9GG)")], {
                    localScaleX: 1.25,
                    localScaleZ: 1.25
                }, 100, Laya[_0x5c21("0x681", "ggF#")][_0x5c21("0x682", "Uf[4")], Laya[_0x5c21("0x683", "(LPe")]["create"](this, () => {
                    this[_0x5c21("0x684", "NYmF")](), this[_0x5c21("0x685", "jQ6r")](_0xd1f1d2[_0x5c21("0x686", "NTNj")]);
                })));
                break;

              case 9:
                _0x5cbf5e[_0x5c21("0x687", "al%z")](_0x5c21("0x688", "omJG"), _0x5849fb["owner"][_0x5c21("0x689", "ikmV")]) || _0x5c21("0x68a", "NTNj") == _0x5849fb["owner"]["name"] ? _0x3c1d73[_0x5c21("0x68b", "(b*P")][_0x5c21("0x68c", "Yd[7")][_0x5c21("0x68d", "t@qE")](0) : _0x5cbf5e[_0x5c21("0x68e", "jQ6r")] == _0x5849fb[_0x5c21("0x68f", "oZew")]["name"] && _0x3c1d73[_0x5c21("0x690", "r#o%")][_0x5c21("0x691", "NYmF")]["sethitEffect"](2), 
                this[_0x5c21("0x692", "9GG)")](_0x5849fb[_0x5c21("0x693", "(LPe")][_0x5c21("0x4c6", "bi^r")][_0x5c21("0x50c", "GLHs")], "-1"), 
                this[_0x5c21("0x694", "Yd[7")] -= 1, this[_0x5c21("0x695", "2CMv")] <= -1 ? (this[_0x5c21("0x696", "4E!&")] = 0, 
                this[_0x5c21("0x697", "hOwa")](_0xd1f1d2[_0x5c21("0x698", "jQ6r")]), _0x5849fb[_0x5c21("0x699", ")RsM")]["active"] = !1) : (_0x5849fb[_0x5c21("0x69a", "jQ6r")][_0x5c21("0x502", "dZ3i")] = !1, 
                Laya["Tween"]["to"](this[_0x5c21("0x69b", "4E!&")], {
                    localScaleX: .75,
                    localScaleZ: .75
                }, 100, Laya[_0x5c21("0x69c", "2CMv")]["linearNone"], Laya[_0x5c21("0x69d", "t@qE")]["create"](this, () => {
                    this[_0x5c21("0x69e", "r#o%")](), this[_0x5c21("0x69f", "r#o%")](_0xd1f1d2[_0x5c21("0x6a0", "dZ3i")]);
                })));
                break;

              case 10:
                this[_0x5c21("0x6a1", "CvOU")](_0xd1f1d2[_0x5c21("0x6a2", "bBqT")]);
                let _0x1ff3b5 = _0x3f5234[_0x5c21("0x6a3", "al%z")]()[_0x5c21("0x6a4", "oM#F")](_0x5849fb[_0x5c21("0x6a5", "[GWR")][_0x5c21("0x43c", "al%z")]);
                this[_0x5c21("0x6a6", "*$CX")][_0x5c21("0x6a7", "CvOU")](_0x1ff3b5), _0x1ff3b5[_0x5c21("0x6a8", "MjE8")][_0x5c21("0x6a9", "nnjN")] = new (Laya[_0x5c21("0x5fe", "Yd[7")])(0, .03, 0), 
                this[_0x5c21("0x6aa", "fIRP")]["localPosition"] = new Laya["Vector3"](0, .2, 0), 
                _0x5849fb[_0x5c21("0x62d", "JzeF")][_0x5c21("0x502", "dZ3i")] = !1;
                break;

              case 11:
                this["playAni"](_0xd1f1d2[_0x5c21("0x6ab", "dZ3i")]);
                for (let _0xc283d7 = 0; _0x5cbf5e["iQphq"](_0xc283d7, this[_0x5c21("0x6ac", "4yM]")][_0x5c21("0x6ad", "m[2Q")]); _0xc283d7++) {
                    let _0x5578fe = _0x3f5234["getIns"]()[_0x5c21("0x6ae", "al%z")](_0x5849fb[_0x5c21("0x6af", "2^mQ")]["name"]);
                    this["ponitArr"][_0xc283d7][_0x5c21("0x6b0", "([2%")](_0x5578fe), _0x5578fe["transform"]["localPosition"] = new Laya["Vector3"](0, -.05, 0);
                }
                _0x5849fb[_0x5c21("0x6b1", "9GG)")][_0x5c21("0x6b2", "Uv]h")] = !1;
            }
        }
        [_0x5c21("0x6b3", "4yM]")](_0x3a6553) {
            let _0x36af2f = _0x3a6553[_0x5c21("0x6b4", "TOp9")][_0x5c21("0x6b5", "nnjN")];
            Laya["Tween"]["to"](_0x3a6553[_0x5c21("0x531", "9GG)")], {
                localPositionX: _0x5cbf5e[_0x5c21("0x6b6", "8&%b")](_0x36af2f["x"], 2),
                localPositionY: _0x36af2f["y"] + 8,
                localPositionZ: _0x5cbf5e[_0x5c21("0x6b7", "jQ6r")](_0x36af2f["z"], 5)
            }, 500, Laya[_0x5c21("0x6b8", "Uv]h")][_0x5c21("0x6b9", "oM#F")], Laya[_0x5c21("0x6ba", "NTNj")][_0x5c21("0x6bb", "UOab")](this, () => {
                _0x3a6553[_0x5c21("0x6bc", "UOab")] = !1;
            }));
        }
        [_0x5c21("0x6bd", "LDjf")]() {
            if (!_0x14063c["IsStart"] || _0x14063c["IsPause"] || this[_0x5c21("0x6be", "9T1Q")]) return;
            this[_0x5c21("0x6bf", "9T1Q")][_0x5c21("0x6c0", "AQRo")](this[_0x5c21("0x6c1", "NYmF")]), 
            this["cameraCtrl"][_0x5c21("0x6c2", "8&%b")]();
            let _0x5a501f = _0x5cbf5e[_0x5c21("0x6c3", "fIRP")](_0x5cbf5e[_0x5c21("0x6c4", "4E!&")](_0x3c1d73[_0x5c21("0x6c5", "fIRP")]["gameCtrll"][_0x5c21("0x6c6", "Yd[7")]["z"], this[_0x5c21("0x6c7", "4E!&")]["position"]["z"]), _0x3c1d73[_0x5c21("0xcd", "Yd[7")][_0x5c21("0x6c8", "CvOU")][_0x5c21("0x6c9", "nnjN")]);
            _0x3c1d73[_0x5c21("0x6ca", "NTNj")]["GetUI"](_0x574ca6[_0x5c21("0x6cb", "Uv]h")][_0x5c21("0x6cc", "t@qE")])[_0x5c21("0x6cd", "AQRo")][_0x5c21("0x6ce", "2(Lk")] = _0x5cbf5e[_0x5c21("0x6cf", "UOab")](1, _0x5a501f), 
            _0x3c1d73[_0x5c21("0x6d0", "(LPe")][_0x5c21("0x6d1", "[GWR")](_0x574ca6["UIType"][_0x5c21("0x6d2", "omJG")])[_0x5c21("0x6d3", "([2%")]["x"] = _0x5cbf5e["LLNfe"](334 * (1 - _0x5a501f), 216), 
            _0x5cbf5e[_0x5c21("0x6d4", "hOwa")](_0x5a501f, 0) && (this[_0x5c21("0x6d5", "MjE8")] == _0xd1f1d2["PHC"] ? this[_0x5c21("0x6d6", "oM#F")]() : _0x5cbf5e[_0x5c21("0x6d7", "NYmF")](this["curState"], _0xd1f1d2["Gang"]) && this["dropGane"](), 
            this["isStop"] = !0, this[_0x5c21("0x6d8", "(LPe")](!0), this[_0x5c21("0x6d9", "m[2Q")][_0x5c21("0x6da", "*$CX")] = new (Laya[_0x5c21("0x6db", "(LPe")])(0, 0, this[_0x5c21("0x6dc", "([2%")]["position"]["z"]), 
            this[_0x5c21("0x622", "bi^r")][_0x5c21("0x57c", "2^mQ")][_0x5c21("0x6dd", "hOwa")] = new (Laya[_0x5c21("0x6de", "NYmF")])(0, .2, 0), 
            1 == _0x420221[_0x5c21("0x6df", "nnjN")]()[_0x5c21("0x301", "r#o%")]["open_tempGame"] ? _0x3c1d73[_0x5c21("0x6e0", "m[2Q")][_0x5c21("0x691", "NYmF")][_0x5c21("0x6e1", "LDjf")](this["bodyLevel"]) : (this[_0x5c21("0x6e2", "NTNj")](), 
            _0x3c1d73[_0x5c21("0x6e3", "dZ3i")][_0x5c21("0x6e4", "nnjN")]["setCaiDai"]()), this[_0x5c21("0x6e5", "Yd[7")](_0xd1f1d2[_0x5c21("0x6e6", "2(Lk")]));
        }
        [_0x5c21("0x6e7", "([2%")]() {
            Laya[_0x5c21("0x51a", "[GWR")]["to"](this[_0x5c21("0x6e8", "JzeF")][_0x5c21("0x598", "t@qE")], {
                localRotationY: 180
            }, 1e3, Laya[_0x5c21("0x6e9", "jQ6r")]["linearNone"], Laya[_0x5c21("0x6ea", "2CMv")][_0x5c21("0x6eb", "Uv]h")](this, () => {}));
        }
        [_0x5c21("0x6ec", "r#o%")](_0x1090c7) {
            _0x1090c7 ? _0x5cbf5e["VgWWH"](1, _0x420221["getIns"]()[_0x5c21("0x6ed", "%9(3")]["open_tempGame"]) ? _0x14063c[_0x5c21("0x6ee", "(b*P")](_0x1090c7, 4e3) : _0x14063c["gameOver"](_0x1090c7, 1500) : _0x14063c[_0x5c21("0x6ef", "m*dV")](_0x1090c7, 10), 
            this[_0x5c21("0x6f0", "jQ6r")]();
        }
        [_0x5c21("0x6f1", "efPG")](_0x41863e, _0x4e4a62) {
            var _0x22d6a8 = new (Laya[_0x5c21("0x6f2", "CvOU")])();
            this[_0x5c21("0x4f9", "(b*P")][_0x5c21("0x6f3", "bBqT")]["project"](_0x41863e, this[_0x5c21("0x50a", "m*dV")][_0x5c21("0x6f4", "ikmV")], _0x22d6a8), 
            _0x3678cc["SetTips"](new (Laya[_0x5c21("0x6f5", "2CMv")])(_0x22d6a8["x"], _0x22d6a8["y"]), _0x4e4a62);
        }
        [_0x5c21("0x6f6", "ggF#")]() {
            this[_0x5c21("0x6f7", "bi^r")]["localPosition"] = new Laya["Vector3"](0, .05, 0), 
            this[_0x5c21("0x6f8", "JzeF")](_0xd1f1d2[_0x5c21("0x6f9", "[GWR")]);
            let _0x23094a = this["phcPonit"]["getChildAt"](0);
            _0x23094a && (this[_0x5c21("0x6fa", "ggF#")]["addChild"](_0x23094a), _0x23094a[_0x5c21("0x6fb", "nnjN")] = !1);
        }
        [_0x5c21("0x6fc", "NTNj")]() {
            this[_0x5c21("0x6fd", "iAvi")](_0xd1f1d2["Walk"]);
            for (let _0x479ed3 = 0; _0x5cbf5e[_0x5c21("0x6fe", "AQRo")](_0x479ed3, this[_0x5c21("0x6ff", "2(Lk")]["length"]); _0x479ed3++) {
                let _0x2ec638 = this[_0x5c21("0x700", "bBqT")][_0x479ed3][_0x5c21("0x701", "r#o%")](0);
                _0x2ec638 && (this["gameScene"]["addChild"](_0x2ec638), _0x2ec638[_0x5c21("0x702", "TOp9")] = !1);
            }
        }
    }
    var _0x12a30a = Laya[_0x5c21("0x703", ")RsM")][_0x5c21("0x704", "UOab")]["wx"];
    class _0x5aac59 extends Laya[_0x5c21("0x705", "&D4Y")] {
        constructor() {
            super(), this[_0x5c21("0x706", "m*dV")] = [], this[_0x5c21("0x707", "TOp9")] = 4, 
            this[_0x5c21("0x708", "t@qE")] = !1, this["_startTouchPt"] = new (Laya[_0x5c21("0x709", ")RsM")])(), 
            this[_0x5c21("0x70a", "2CMv")] = 0, this["isInitPlayer"] = !1, this["dir"] = 1, 
            this[_0x5c21("0x70b", "omJG")] = !1, this["isMouseMove"] = !1, this["videoBarrier"] = [], 
            this["videoIcon"] = [];
        }
        [_0x5c21("0x70c", "LDjf")]() {
            this["colorArr"] = [ _0x5cbf5e["wQUDW"], _0x5c21("0x70d", "LDjf"), _0x5cbf5e[_0x5c21("0x70e", "2CMv")], _0x5cbf5e["OFlfp"] ], 
            this[_0x5c21("0x70f", "UOab")](), this[_0x5c21("0x710", "m[2Q")](_0x36ffa1[_0x5c21("0x711", "2CMv")][_0x5c21("0x712", "2^mQ")] > 10 ? _0x36ffa1[_0x5c21("0x713", "8&%b")][_0x5c21("0x714", "omJG")] % 10 : _0x36ffa1["Data"][_0x5c21("0x715", "JzeF")]), 
            _0x12a30a ? this[_0x5c21("0x716", "GLHs")]() : this[_0x5c21("0x717", "NTNj")]();
        }
        [_0x5c21("0x718", ")RsM")]() {
            this[_0x5c21("0x719", "al%z")] = this[_0x5c21("0x71a", "rvGE")][_0x5c21("0x71b", "m*dV")](new Laya["Scene3D"]()), 
            this["sceneMap"] = this["newScene"][_0x5c21("0x71c", "gT6R")](new Laya["Sprite3D"]("map"));
            var _0x36240f = this[_0x5c21("0x71d", "%9(3")];
            _0x36240f[_0x5c21("0x71e", "Uf[4")] = 0, _0x36240f[_0x5c21("0x71f", "4E!&")] = new (Laya[_0x5c21("0x720", "bBqT")])(.5, .5, .5), 
            this["DirectionLight"] ? (this[_0x5c21("0x721", "fIRP")][_0x5c21("0x722", "bi^r")] = new (Laya[_0x5c21("0x723", "al%z")])(1, 1, 1), 
            this["DirectionLight"]["transform"]["rotationEuler"] = new Laya["Vector3"](50, 150, 0), 
            this[_0x5c21("0x724", "Uf[4")][_0x5c21("0x725", "jQ6r")] = .8) : (this[_0x5c21("0x721", "fIRP")] = _0x36240f[_0x5c21("0x726", "jQ6r")](new (Laya[_0x5c21("0x727", "t@qE")])()), 
            this[_0x5c21("0x728", "bi^r")][_0x5c21("0x729", "(b*P")] = new (Laya[_0x5c21("0x72a", "oM#F")])(1, 1, 1), 
            this[_0x5c21("0x72b", "MjE8")]["transform"]["rotationEuler"] = new Laya["Vector3"](-54, 30, 0), 
            this["DirectionLight"][_0x5c21("0x72c", ")RsM")] = 1, this[_0x5c21("0x72d", "bBqT")]["shadowMode"] = 0, 
            this[_0x5c21("0x72e", "GLHs")][_0x5c21("0x72f", "9GG)")] = 100, this["DirectionLight"]["shadowCascadesMode"] = 2, 
            this[_0x5c21("0x730", "(b*P")]["shadowResolution"] = 2048), this["cameraRoot"] = this["newScene"][_0x5c21("0x731", "2CMv")](new (Laya[_0x5c21("0x732", "4yM]")])("cameraRoot")), 
            this[_0x5c21("0x733", ")RsM")][_0x5c21("0x5db", "Uv]h")][_0x5c21("0x734", "m[2Q")] = new (Laya[_0x5c21("0x735", "%9(3")])(0, 180, 0), 
            this[_0x5c21("0x736", "r#o%")] || (this[_0x5c21("0x737", "AQRo")] = new (Laya[_0x5c21("0x738", "gT6R")])(0, .1, 150), 
            this[_0x5c21("0x739", "t@qE")][_0x5c21("0x73a", "9GG)")](this["MainCamera"]), this["newScene"][_0x5c21("0x73b", "GLHs")] = this[_0x5c21("0x73c", "oZew")], 
            this[_0x5c21("0x73d", "ikmV")][_0x5c21("0x73e", "dZ3i")][_0x5c21("0x4cc", "8&%b")] = new Laya["Vector3"](0, 3.5, -5.5), 
            this[_0x5c21("0x73f", "4E!&")]["transform"][_0x5c21("0x643", "al%z")] = new (Laya[_0x5c21("0x5b5", "&D4Y")])(-15, 180, 0), 
            this["MainCamera"][_0x5c21("0x740", "jQ6r")] = Laya["CameraClearFlags"][_0x5c21("0x741", "4yM]")], 
            this[_0x5c21("0x742", "9T1Q")][_0x5c21("0x743", "%9(3")] = new Laya["Vector4"](_0x5cbf5e[_0x5c21("0x744", "2^mQ")](149, 255), _0x5cbf5e["kteSN"](205, 255), _0x5cbf5e[_0x5c21("0x745", "%9(3")](254, 255), 0), 
            this[_0x5c21("0x746", "&D4Y")][_0x5c21("0x747", "bBqT")] = !1), _0x36240f[_0x5c21("0x748", "8&%b")] = !1, 
            _0x36240f[_0x5c21("0x749", "(b*P")] = new (Laya[_0x5c21("0x74a", "Uv]h")])(_0x5cbf5e[_0x5c21("0x74b", "m[2Q")](149, 255), 205 / 255, 254 / 255), 
            _0x36240f[_0x5c21("0x74c", "[GWR")] = 10, _0x36240f["fogRange"] = 100, this[_0x5c21("0x74d", "rvGE")] = this[_0x5c21("0x74e", "9T1Q")][_0x5c21("0x74f", "r#o%")](_0x3f5234[_0x5c21("0x750", "2CMv")]()[_0x5c21("0x751", "[GWR")](_0x5c21("0x752", "omJG"))), 
            this[_0x5c21("0x753", "gT6R")][_0x5c21("0x754", "m[2Q")]["rotationEuler"] = new Laya["Vector3"](this[_0x5c21("0x755", "al%z")]["transform"]["rotationEuler"]["x"], _0x5cbf5e["LLNfe"](this[_0x5c21("0x756", "jQ6r")]["transform"][_0x5c21("0x757", "bBqT")]["y"], 180), this["playerSp"][_0x5c21("0x5b4", "9T1Q")][_0x5c21("0x758", "JzeF")]["z"]), 
            this[_0x5c21("0x737", "AQRo")]["addComponent"](_0x7ecc3a)[_0x5c21("0x759", "rvGE")](this["playerSp"], this[_0x5c21("0x736", "r#o%")], this[_0x5c21("0x75a", "4yM]")]), 
            this["playerSp"][_0x5c21("0x75b", "hOwa")][_0x5c21("0x75c", "t@qE")] = this[_0x5c21("0x75d", "Uv]h")]["transform"][_0x5c21("0x75e", "NTNj")], 
            this[_0x5c21("0x75f", "[GWR")] = this["playerSp"][_0x5c21("0x760", "CvOU")](_0x1848f7), 
            this[_0x5c21("0x761", "NTNj")]();
        }
        ["loadWxSub"]() {
            const _0x540a03 = this;
            _0x12a30a[_0x5c21("0x762", "omJG")]({
                name: _0x5c21("0x763", "al%z"),
                success: function(_0x5e512c) {
                    _0x540a03[_0x5c21("0x764", "&D4Y")]();
                },
                fail: function(_0x128103) {
                    console["log"](_0x5cbf5e["bBWMm"]);
                }
            });
        }
        [_0x5c21("0x765", "TOp9")]() {
            Laya[_0x5c21("0x766", "omJG")][_0x5c21("0x767", "hOwa")]([ _0x5cbf5e["aCebN"], _0x5c21("0x768", "8&%b"), _0x5c21("0x769", "AQRo"), _0x5cbf5e[_0x5c21("0x76a", "gT6R")] ], Laya[_0x5c21("0x76b", "omJG")][_0x5c21("0x50e", "2CMv")](this, () => {
                for (let _0x40ae59 = 2; _0x40ae59 < 6; _0x40ae59++) {
                    let _0x2c767a = "Other4M2/LayaScene_Body/Conventional/player0" + _0x40ae59 + ".lh", _0x2a4d65 = Laya[_0x5c21("0x76c", "9GG)")][_0x5c21("0x76d", "ggF#")](_0x2c767a);
                    _0x2a4d65[_0x5c21("0x76e", "omJG")] = !1, this[_0x5c21("0x755", "al%z")][_0x5c21("0x71b", "m*dV")](_0x2a4d65);
                }
                this[_0x5c21("0x76f", "*$CX")][_0x5c21("0x770", "GLHs")](), this["isInitPlayer"] = !0;
            }));
        }
        [_0x5c21("0x771", "[GWR")](_0x33a6dd) {
            let _0x320bec;
            _0x33a6dd = 0 == _0x33a6dd ? 1 : _0x33a6dd, _0x320bec = window["wx"] ? _0x5cbf5e[_0x5c21("0x772", "r#o%")](_0x5cbf5e["LLNfe"](_0x4aecda, _0x1478e6), _0x5c21("0x773", "nnjN") + _0x33a6dd + _0x5c21("0x774", "*$CX")) : _0x5c21("0x775", "2(Lk") + _0x33a6dd + ".json", 
            Laya[_0x5c21("0x776", "(b*P")][_0x5c21("0x777", "AQRo")](_0x320bec, Laya["Handler"][_0x5c21("0x778", "ggF#")](this, _0x2e131d => {
                this["createMap"](_0x2e131d);
            }));
        }
        ["createMap"](_0x5e7143) {
            let _0x42ade7 = _0x5e7143["SceneItems"], _0x170704 = _0x5e7143["Items"];
            for (let _0x5e7143 in _0x42ade7) {
                let _0x258b78 = _0x3f5234["getIns"]()["getModelCloneByName"](_0x42ade7[_0x5e7143][_0x5c21("0x779", "CvOU")]);
                this[_0x5c21("0x77a", "jQ6r")][_0x5c21("0x77b", "&D4Y")](_0x258b78);
                let _0xbb3264 = _0x258b78["getComponent"](_0x4696aa);
                _0xbb3264 ? _0xbb3264[_0x5c21("0x77c", "&D4Y")](_0x42ade7[_0x5e7143], !1) : _0x258b78[_0x5c21("0x77d", "8&%b")](_0x4696aa)[_0x5c21("0x77c", "&D4Y")](_0x42ade7[_0x5e7143], !1), 
                _0x5cbf5e["hPWYm"](_0x5c21("0x77e", "iAvi"), _0x42ade7[_0x5e7143]["ModelName"]) && (this[_0x5c21("0x77f", "Yd[7")] = _0x258b78);
            }
            for (let _0x5e7143 in _0x170704) {
                if (_0x5c21("0x780", "[GWR") == _0x170704[_0x5e7143]["ModelName"]) {
                    let _0x1a4cbe = Math[_0x5c21("0x781", "m*dV")]();
                    _0x170704[_0x5e7143]["ModelName"] = _0x1a4cbe < .5 ? _0x5c21("0x782", "bi^r") : _0x5cbf5e[_0x5c21("0x783", "4yM]")](_0x1a4cbe, .8) ? "Plane002" : _0x5c21("0x784", "oZew");
                }
                let _0xcae789 = _0x3f5234[_0x5c21("0x785", "oM#F")]()[_0x5c21("0x786", "4E!&")](_0x170704[_0x5e7143]["ModelName"]);
                this["sceneMap"][_0x5c21("0x787", "*$CX")](_0xcae789);
                let _0x28742c = _0xcae789[_0x5c21("0x788", "Uf[4")](_0x4696aa);
                _0x28742c ? _0x28742c["init"](_0x170704[_0x5e7143], !0) : _0xcae789[_0x5c21("0x789", "9T1Q")](_0x4696aa)[_0x5c21("0x78a", "TOp9")](_0x170704[_0x5e7143], !0);
            }
            _0x5e7143[_0x5c21("0x78b", "ggF#")] ? (this[_0x5c21("0x78c", "AQRo")][_0x5c21("0x78d", "omJG")][_0x5c21("0x78e", "9GG)")] = new (Laya[_0x5c21("0x78f", "iAvi")])(_0x5e7143["KeyPointData"][0]["posX"], _0x5e7143[_0x5c21("0x790", "t@qE")][0][_0x5c21("0x791", "ikmV")], _0x5e7143["KeyPointData"][0]["posZ"]), 
            this["successPos"] = new (Laya[_0x5c21("0x792", "JzeF")])(_0x5e7143[_0x5c21("0x793", "MjE8")][1][_0x5c21("0x794", "nnjN")], _0x5e7143[_0x5c21("0x795", "LDjf")][1]["posY"], _0x5e7143[_0x5c21("0x796", "(LPe")][1][_0x5c21("0x797", "MjE8")]), 
            this[_0x5c21("0x798", "al%z")] = _0x5cbf5e[_0x5c21("0x799", "Yd[7")](_0x5e7143["KeyPointData"][1][_0x5c21("0x79a", "jQ6r")], _0x5e7143[_0x5c21("0x79b", "bBqT")][0][_0x5c21("0x79c", "(LPe")])) : this[_0x5c21("0x79d", "GLHs")] = new (Laya[_0x5c21("0x6de", "NYmF")])(0, _0x5cbf5e[_0x5c21("0x79e", "m*dV")](this["endPos"]["y"], 4), this["endPos"]["z"] + 20), 
            this[_0x5c21("0x79f", "TOp9")] && (this[_0x5c21("0x7a0", "(LPe")][_0x5c21("0x50b", "oZew")]["position"] = this["cameraRoot"][_0x5c21("0x4fa", "2CMv")][_0x5c21("0x494", "9T1Q")]), 
            _0x3c1d73["Inst"][_0x5c21("0x7a1", "(LPe")]["visible"] = !1;
        }
        ["initEffect"]() {
            this["hitEffect"] = _0x3f5234[_0x5c21("0x7a2", "JzeF")]()[_0x5c21("0x7a3", "iAvi")](_0x5cbf5e[_0x5c21("0x7a4", "Uv]h")]), 
            this[_0x5c21("0x7a5", "GLHs")][_0x5c21("0x7a6", "hOwa")](this[_0x5c21("0x7a7", "GLHs")]), 
            this[_0x5c21("0x7a7", "GLHs")]["transform"][_0x5c21("0x7a8", "dZ3i")] = new (Laya[_0x5c21("0x5fe", "Yd[7")])(0, 1, 1), 
            this[_0x5c21("0x7a9", "NTNj")]["active"] = !0, this[_0x5c21("0x7aa", "2^mQ")] = this[_0x5c21("0x7ab", "ikmV")]["getChildByName"](_0x5cbf5e["HMhCY"])["getChildByName"](_0x5c21("0x7ac", "LDjf"))[_0x5c21("0x7ad", "UOab")], 
            this[_0x5c21("0x7ae", "(b*P")] = _0x3f5234["getIns"]()[_0x5c21("0x455", "fIRP")](_0x5cbf5e[_0x5c21("0x7af", "NYmF")]), 
            this[_0x5c21("0x7b0", "(b*P")][_0x5c21("0x4d9", "9T1Q")](this[_0x5c21("0x7b1", "dZ3i")]), 
            this[_0x5c21("0x7b2", "efPG")][_0x5c21("0x7b3", "NTNj")] = !1;
        }
        [_0x5c21("0x7b4", "omJG")](_0x494800) {
            this[_0x5c21("0x77f", "Yd[7")][_0x5c21("0x7b5", "omJG")](_0x4696aa)[_0x5c21("0x7b6", "*$CX")](this[_0x5c21("0x7b7", "al%z")], _0x494800, () => {
                this["playCtrl"]["rotatePlayer"](), this[_0x5c21("0x7b8", "nnjN")]();
            });
        }
        [_0x5c21("0x7b9", "Uf[4")]() {
            this[_0x5c21("0x7ba", "nnjN")][_0x5c21("0x7bb", "[GWR")] = !0, this[_0x5c21("0x7bc", "&D4Y")]["transform"]["position"] = new (Laya[_0x5c21("0x7bd", "GLHs")])(this[_0x5c21("0x7be", "8&%b")][_0x5c21("0x7bf", "&D4Y")][_0x5c21("0x4fc", "([2%")]["x"], this["finishObj"][_0x5c21("0x73e", "dZ3i")][_0x5c21("0x7c0", "oZew")]["y"], _0x5cbf5e[_0x5c21("0x7c1", "al%z")](this["finishObj"]["transform"]["position"]["z"], 2));
        }
        [_0x5c21("0x7c2", "2(Lk")](_0x436fc0) {
            this[_0x5c21("0x7ab", "ikmV")][_0x5c21("0x7c3", "Uf[4")] = !1, this[_0x5c21("0x7c4", "Uf[4")][_0x5c21("0x76e", "omJG")] = !0, 
            this[_0x5c21("0x7c5", "Yd[7")][_0x5c21("0x7c6", "oZew")]();
            let _0x2874ca = _0x6e184f["getStrColorToRbg"](this[_0x5c21("0x7c7", "4E!&")][_0x436fc0]);
            this["hitEffectPart"][_0x5c21("0x7c8", "*$CX")] = _0x2874ca, Laya[_0x5c21("0x7c9", "m*dV")][_0x5c21("0x25d", "CvOU")](1e3, this, () => {
                this[_0x5c21("0x7ca", "gT6R")]["stop"]();
            });
        }
        [_0x5c21("0x7cb", "8&%b")]() {
            if (_0x14063c["IsStart"], _0x420221[_0x5c21("0x7cc", "jQ6r")]()[_0x5c21("0x7cd", "fIRP")]["open_game_video"]) for (var _0xdf2e5b in this[_0x5c21("0x7ce", "8&%b")]) if (this["videoBarrier"][_0xdf2e5b] && this["videoIcon"][_0xdf2e5b]) {
                let _0x1ab66f = this["v3ToV2"](this[_0x5c21("0x7cf", "r#o%")][_0xdf2e5b][_0x5c21("0x5d9", "CvOU")][_0x5c21("0x7d0", "UOab")]);
                this["videoIcon"][_0xdf2e5b]["x"] = _0x1ab66f["x"], this[_0x5c21("0x7d1", "(LPe")][_0xdf2e5b]["y"] = _0x1ab66f["y"] - _0x5cbf5e[_0x5c21("0x7d2", "CvOU")](_0x5cbf5e[_0x5c21("0x7d3", "NTNj")](_0x5cbf5e["kteSN"](_0x1ab66f["y"], Laya[_0x5c21("0x7d4", "%9(3")][_0x5c21("0x7d5", "TOp9")]), 1.5), 50), 
                this[_0x5c21("0x7d6", "hOwa")][_0xdf2e5b]["scaleX"] = this[_0x5c21("0x7d7", "r#o%")][_0xdf2e5b][_0x5c21("0x7d8", "GLHs")] = _0x5cbf5e[_0x5c21("0x7d9", "m[2Q")](_0x5cbf5e[_0x5c21("0x7da", "&D4Y")](_0x1ab66f["y"], Laya[_0x5c21("0x7db", "&D4Y")][_0x5c21("0x7dc", "oM#F")]), .5), 
                this["videoIcon"][_0xdf2e5b][_0x5c21("0x7dd", "&D4Y")] = this[_0x5c21("0x7de", "rvGE")][_0xdf2e5b]["active"];
            }
        }
        [_0x5c21("0x7df", "omJG")]() {
            this[_0x5c21("0x7e0", "gT6R")] = !0, this[_0x5c21("0x7e1", "2^mQ")](), this[_0x5c21("0x7e2", "dZ3i")][_0x5c21("0x7e3", ")RsM")]();
        }
        ["m_gameOver"]() {
            this[_0x5c21("0x7e4", "NYmF")](), this[_0x5c21("0x7e5", "nnjN")] = !1, this[_0x5c21("0x7e6", "Uv]h")][_0x5c21("0x7e7", "LDjf")]();
        }
        [_0x5c21("0x7e8", "dZ3i")]() {
            for (let _0x1d6036 = 0; _0x1d6036 < this[_0x5c21("0x7e9", "efPG")][_0x5c21("0x7ea", "([2%")]; _0x1d6036++) this["recoverIcon"](this[_0x5c21("0x7e9", "efPG")][_0x1d6036]);
            this[_0x5c21("0x7eb", "oZew")][_0x5c21("0x7ec", "9T1Q")] = this[_0x5c21("0x7ed", "2CMv")][_0x5c21("0x1fe", "Yd[7")] = 0;
            for (let _0x18d00f = 0; _0x5cbf5e[_0x5c21("0x7ee", "4E!&")](_0x18d00f, this["sceneMap"][_0x5c21("0x47e", "hOwa")]); _0x18d00f++) this["sceneMap"][_0x5c21("0x7ef", "hOwa")](_0x18d00f)[_0x5c21("0x7f0", "oM#F")](_0x4696aa) && (this[_0x5c21("0x7f1", "Uv]h")]["getChildAt"](_0x18d00f)[_0x5c21("0x7f2", "9T1Q")](_0x4696aa)[_0x5c21("0x7f3", "9T1Q")](), 
            _0x3f5234[_0x5c21("0x7f4", "LDjf")]()[_0x5c21("0x7f5", "*$CX")](this[_0x5c21("0x7f6", "oZew")][_0x5c21("0x7f7", "%9(3")](_0x18d00f)));
            this["sceneMap"][_0x5c21("0x7f8", "MjE8")](0, this["sceneMap"][_0x5c21("0x7f9", "UOab")]), 
            this[_0x5c21("0x7fa", "4E!&")]["transform"]["position"] = new (Laya[_0x5c21("0x7fb", "4yM]")])(0, 0, 0), 
            this[_0x5c21("0x7fc", "efPG")]["transform"]["localPosition"] = new (Laya[_0x5c21("0x6de", "NYmF")])(0, 0, 0), 
            this["cameraRoot"][_0x5c21("0x49d", "efPG")][_0x5c21("0x7fd", "Yd[7")] = new (Laya[_0x5c21("0x6db", "(LPe")])(0, 180, 0), 
            this[_0x5c21("0x7fe", "Yd[7")][_0x5c21("0x7ff", "9GG)")](), this["loadMapConfig"](_0x36ffa1[_0x5c21("0x800", "9GG)")][_0x5c21("0x801", "efPG")] > 10 ? _0x5cbf5e[_0x5c21("0x802", "omJG")](_0x36ffa1[_0x5c21("0x803", "ggF#")]["level"], 10) : _0x36ffa1[_0x5c21("0x713", "8&%b")]["level"]), 
            this[_0x5c21("0x804", "%9(3")][_0x5c21("0x6b2", "Uv]h")] = !1;
        }
        ["registerEvent"]() {
            Laya[_0x5c21("0x7db", "&D4Y")]["on"](Laya["Event"][_0x5c21("0x805", "8&%b")], this, this[_0x5c21("0x806", "([2%")]), 
            Laya["stage"]["on"](Laya[_0x5c21("0x807", "hOwa")][_0x5c21("0x808", "JzeF")], this, this["mouseType"]), 
            Laya[_0x5c21("0x809", "9T1Q")]["on"](Laya["Event"][_0x5c21("0x80a", "4yM]")], this, this["mouseType"]), 
            Laya[_0x5c21("0x80b", "AQRo")]["on"](Laya["Event"][_0x5c21("0x80c", "2CMv")], this, this["mouseType"]);
        }
        ["cancelEvent"]() {
            Laya[_0x5c21("0x251", "al%z")][_0x5c21("0x80d", "al%z")](Laya[_0x5c21("0x80e", "bBqT")]["MOUSE_DOWN"], this, this["mouseType"]), 
            Laya[_0x5c21("0x24e", "rvGE")]["off"](Laya["Event"][_0x5c21("0x80f", "AQRo")], this, this[_0x5c21("0x810", "ggF#")]), 
            Laya[_0x5c21("0x811", "2(Lk")][_0x5c21("0x812", "2(Lk")](Laya[_0x5c21("0x813", "*$CX")]["MOUSE_UP"], this, this["mouseType"]), 
            Laya[_0x5c21("0x814", "([2%")][_0x5c21("0x815", "4yM]")](Laya[_0x5c21("0x816", "r#o%")][_0x5c21("0x817", "jQ6r")], this, this[_0x5c21("0x818", "Uf[4")]);
        }
        ["mouseType"](_0xbda27c) {
            if (!_0x14063c[_0x5c21("0x819", "4E!&")]) switch (_0xbda27c["type"]) {
              case Laya["Event"][_0x5c21("0x81a", "Yd[7")]:
                this["isMouseDown"] = !0, this[_0x5c21("0x81b", "ikmV")] = new Laya["Vector2"](_0xbda27c[_0x5c21("0x81c", "[GWR")], _0xbda27c[_0x5c21("0x81d", "omJG")]), 
                !_0x14063c[_0x5c21("0x81e", "rvGE")] && this[_0x5c21("0x81f", "r#o%")] && (_0x14063c[_0x5c21("0x820", "iAvi")](), 
                this[_0x5c21("0x821", "UOab")][_0x5c21("0x822", "rvGE")](_0x5cbf5e[_0x5c21("0x823", "ggF#")]), 
                _0x3c1d73[_0x5c21("0x824", "m*dV")][_0x5c21("0x825", "%9(3")](_0x574ca6["UIType"][_0x5c21("0x826", "efPG")])[_0x5c21("0x827", "([2%")][_0x5c21("0x828", "Uf[4")] = !1, 
                _0x420221[_0x5c21("0x829", "4yM]")]()[_0x5c21("0x82a", "%9(3")](_0x36ffa1["Data"][_0x5c21("0x82b", "Uv]h")], _0x5cbf5e[_0x5c21("0x82c", "NTNj")]("第" + _0x36ffa1["Data"]["level"], "关")));
                break;

              case Laya["Event"][_0x5c21("0x82d", "UOab")]:
                if (this[_0x5c21("0x82e", "MjE8")]) {
                    let _0x263150 = _0x5cbf5e[_0x5c21("0x82f", "GLHs")](_0xbda27c[_0x5c21("0x830", "LDjf")], this[_0x5c21("0x831", "2^mQ")]["x"]);
                    (this[_0x5c21("0x832", "2CMv")]["_tras"][_0x5c21("0x7d0", "UOab")]["x"] < -1.5 && _0x263150 < 0 || this["playCtrl"]["_tras"][_0x5c21("0x833", "2(Lk")]["x"] > 1.5 && _0x5cbf5e[_0x5c21("0x834", "Uf[4")](_0x263150, 0)) && (_0x263150 = 0), 
                    this[_0x5c21("0x835", "ikmV")][_0x5c21("0x836", "fIRP")][_0x5c21("0x837", "oM#F")](new (Laya[_0x5c21("0x838", "gT6R")])(-.007 * _0x263150, 0, 0)), 
                    this[_0x5c21("0x839", "oZew")] = !0;
                }
                this[_0x5c21("0x83a", "bBqT")]["x"] = Math[_0x5c21("0x83b", "fIRP")](_0xbda27c[_0x5c21("0x83c", "AQRo")]);
                break;

              case Laya["Event"]["MOUSE_UP"]:
              case Laya["Event"][_0x5c21("0x83d", "bi^r")]:
                this[_0x5c21("0x83e", "%9(3")] = !1, this[_0x5c21("0x83f", "iAvi")] = !1, this[_0x5c21("0x840", "NTNj")][_0x5c21("0x841", "UOab")]["x"] = 0;
            }
        }
        ["initVideo"]() {
            let _0x13a11f = _0x420221[_0x5c21("0x842", "Uf[4")]()["config"]["video_num"] || 2;
            this[_0x5c21("0x843", "&D4Y")] = _0x420221[_0x5c21("0x844", "9T1Q")]()["getRandomArrayElements"](this[_0x5c21("0x845", "dZ3i")], _0x13a11f);
            for (let _0x3b7620 in this[_0x5c21("0x846", "fIRP")]) {
                this["videoBarrier"][_0x3b7620][_0x5c21("0x847", "iAvi")](_0x4696aa)[_0x5c21("0x848", "9T1Q")] = !0;
                let _0x9967bf = this["SetTips"]();
                this["videoIcon"][_0x5c21("0x849", "r#o%")](_0x9967bf);
            }
        }
        [_0x5c21("0x84a", "GLHs")](_0x3bf3fd) {
            var _0x14a9d1 = new (Laya[_0x5c21("0x84b", "LDjf")])();
            return this[_0x5c21("0x84c", "Uf[4")]["viewport"][_0x5c21("0x84d", "JzeF")](_0x3bf3fd, this[_0x5c21("0x84c", "Uf[4")][_0x5c21("0x84e", "MjE8")], _0x14a9d1), 
            new (Laya[_0x5c21("0x5be", "Uv]h")])(_0x14a9d1["x"], _0x14a9d1["y"]);
        }
        [_0x5c21("0x84f", "MjE8")](_0x5879d4) {
            _0x5879d4["removeSelf"](), Laya[_0x5c21("0x850", "*$CX")][_0x5c21("0x851", "NTNj")](_0x5cbf5e["fuxyV"], _0x5879d4);
        }
        [_0x5c21("0x852", "omJG")]() {
            let _0x2c6089 = new (Laya[_0x5c21("0x853", "rvGE")])();
            _0x2c6089[_0x5c21("0x854", "gT6R")] = Laya[_0x5c21("0x855", "dZ3i")][_0x5c21("0x856", "omJG")](_0x5cbf5e[_0x5c21("0x857", "bBqT")]);
            let _0x218b2e = Laya[_0x5c21("0x858", "m[2Q")]["getItemByCreateFun"](_0x5cbf5e[_0x5c21("0x859", "%9(3")], _0x2c6089["create"], _0x2c6089);
            return _0x3c1d73[_0x5c21("0x85a", "omJG")][_0x5c21("0x85b", "oM#F")](_0x574ca6[_0x5c21("0x85c", "NYmF")][_0x5c21("0x85d", "TOp9")])[_0x5c21("0x85e", "hOwa")]["addChild"](_0x218b2e), 
            _0x218b2e;
        }
    }
    var _0x3c81f2, _0x5e41aa = Laya[_0x5c21("0x85f", "t@qE")][_0x5c21("0x704", "UOab")]["wx"];
    class _0x3c1d73 extends _0x27b03e[_0x5c21("0x860", "[GWR")][_0x5c21("0x861", "bBqT")] {
        constructor() {
            super(), this[_0x5c21("0x862", "MjE8")] = 0, this[_0x5c21("0x863", "r#o%")] = new Map(), 
            this[_0x5c21("0x864", "4E!&")] = 0, this[_0x5c21("0x865", "&D4Y")] = [], this["gameBannerBox"] = [], 
            _0x3c1d73[_0x5c21("0x866", "Yd[7")] = this, this;
        }
        ["onAwake"]() {
            this[_0x5c21("0x867", "%9(3")] = _0x420221[_0x5c21("0x868", "omJG")]()[_0x5c21("0x1b7", "oZew")]["game_process"] || [ 1, 5, 2, 4, 3, 6 ], 
            _0x420221["getIns"]()["config"][_0x5c21("0x869", "fIRP")] = 1, this[_0x5c21("0x86a", ")RsM")] = 0, 
            this[_0x5c21("0x86b", "efPG")] = new Map(), 1 == _0x420221[_0x5c21("0x86c", "CvOU")]()[_0x5c21("0x86d", "hOwa")][_0x5c21("0x86e", "t@qE")] && _0x4176cc[_0x5c21("0x86f", "4yM]")][_0x5c21("0x870", "MjE8")](_0x420221["getIns"]()[_0x5c21("0x255", "NTNj")][_0x5c21("0x871", "hOwa")], _0x420221["getIns"]()[_0x5c21("0x220", "&D4Y")][_0x5c21("0x872", ")RsM")]), 
            this[_0x5c21("0x873", "Uf[4")] = this[_0x5c21("0x874", "UOab")]["getComponent"](_0x5aac59), 
            this["initCity"](), this[_0x5c21("0x875", "nnjN")]();
        }
        ["playBg"]() {
            var _0x7116f3 = {
                PAQFH: _0x5c21("0x876", "4E!&")
            };
            if (_0x5e41aa) {
                _0x5e41aa[_0x5c21("0x877", "2^mQ")]({
                    name: _0x5c21("0x878", "2(Lk"),
                    success: function(_0x512c65) {
                        Laya[_0x5c21("0x879", "Uf[4")][_0x5c21("0x87a", "fIRP")]("Music/" + _0x5cbf5e[_0x5c21("0x87b", "2CMv")](_0x36ffa1["Data"]["level"], 2) + _0x5c21("0x87c", "nnjN"), 0);
                    },
                    fail: function(_0x18003f) {
                        console["log"](_0x7116f3[_0x5c21("0x87d", "%9(3")]);
                    }
                });
                _0x5e41aa[_0x5c21("0xd8", "rvGE")](() => {
                    Laya[_0x5c21("0x87e", "4E!&")][_0x5c21("0x87f", "ikmV")]("Music/" + _0x36ffa1[_0x5c21("0x880", "bi^r")][_0x5c21("0x881", "AQRo")] % 2 + _0x5c21("0x882", "NYmF"), 0);
                });
            } else Laya[_0x5c21("0x883", "t@qE")]["playMusic"]("Music/" + _0x5cbf5e[_0x5c21("0x884", "bBqT")](_0x36ffa1[_0x5c21("0x885", "GLHs")][_0x5c21("0x886", "gT6R")], 2) + ".mp3", 0);
        }
        [_0x5c21("0x887", "oZew")]() {
            this[_0x5c21("0x888", "9GG)")] = !1, this[_0x5c21("0x889", "hOwa")] = !1, this["beforeGameUI"] = !0, 
            this[_0x5c21("0x88a", "al%z")] = !1;
            let _0x132b1f = _0x420221[_0x5c21("0x88b", "ikmV")]()[_0x5c21("0x88c", "Uf[4")][_0x5c21("0x88d", "CvOU")] || _0x5c21("0x88e", "oZew");
            for (let _0x3e8399 in _0x420221[_0x5c21("0x88f", "9GG)")]()[_0x5c21("0x890", "GLHs")][_0x5c21("0x891", "r#o%")]) _0x132b1f[_0x5c21("0x892", "9T1Q")](_0x420221[_0x5c21("0x893", "m*dV")]()[_0x5c21("0x894", "2CMv")][_0x5c21("0x895", "m[2Q")][_0x3e8399]) > 0 && (this[_0x5c21("0x896", "2(Lk")] = !0);
            for (let _0x118fb6 in _0x420221[_0x5c21("0x897", "GLHs")]()[_0x5c21("0x220", "&D4Y")][_0x5c21("0x898", "bBqT")]) _0x5cbf5e["GCYPd"](_0x132b1f[_0x5c21("0x899", "jQ6r")](_0x420221["getIns"]()["config"][_0x5c21("0x89a", "jQ6r")][_0x118fb6]), 0) && (this[_0x5c21("0x89b", "ggF#")] = !0);
            if (_0x5cbf5e[_0x5c21("0x89c", "CvOU")](1, _0x420221[_0x5c21("0x89d", "gT6R")]()[_0x5c21("0x89e", "bi^r")][_0x5c21("0x89f", "NYmF")])) if (_0x5cbf5e["WTiXc"](0, _0x420221[_0x5c21("0x8a0", ")RsM")]()[_0x5c21("0x8a1", "gT6R")][_0x5c21("0x8a2", "r#o%")])) _0x420221["getIns"]()[_0x5c21("0x8a3", "4yM]")][_0x5c21("0x8a4", "hOwa")] = 0, 
            _0x420221[_0x5c21("0x8a5", "UOab")]()[_0x5c21("0x8a6", "m*dV")][_0x5c21("0x8a7", "NTNj")] = 0, 
            _0x420221[_0x5c21("0x6a3", "al%z")]()["config"][_0x5c21("0x8a8", "Yd[7")] = 0; else if (_0x5cbf5e[_0x5c21("0x8a9", "Uv]h")]("全国", _0x420221[_0x5c21("0x88b", "ikmV")]()[_0x5c21("0x229", "NYmF")][_0x5c21("0x8aa", "(LPe")])) this[_0x5c21("0x8ab", "2^mQ")] = !0; else for (let _0x3315be in _0x420221[_0x5c21("0x8a0", ")RsM")]()[_0x5c21("0x294", "[GWR")][_0x5c21("0x8ac", "4yM]")]) _0x5cbf5e["GCYPd"](_0x132b1f[_0x5c21("0x8ad", "ikmV")](_0x420221[_0x5c21("0x8ae", "%9(3")]()[_0x5c21("0x301", "r#o%")][_0x5c21("0x8af", "oZew")][_0x3315be]), 0) && (this[_0x5c21("0x8b0", "(b*P")] = !0);
        }
        [_0x5c21("0x8b1", "NTNj")]() {
            if (_0x5cbf5e[_0x5c21("0x8b2", "oM#F")](8, this["game_process"][this["showIdx"]])) if (this[_0x5c21("0x8b3", "bi^r")] = _0x574ca6["processUI"][this[_0x5c21("0x8b4", "t@qE")][this[_0x5c21("0x8b5", "9T1Q")]]], 
            this[_0x5c21("0x8b6", "(b*P")] += 1, _0x5cbf5e[_0x5c21("0x8b7", "t@qE")](this["showIdx"], this[_0x5c21("0x8b8", "2^mQ")]["length"]) && (this[_0x5c21("0x8b9", "LDjf")] = 0, 
            this["afterGameUI"] = !1), _0x5cbf5e["WYaJJ"](null, this[_0x5c21("0x8ba", "9GG)")])) {
                if (_0x5cbf5e[_0x5c21("0x8bb", "NTNj")](this[_0x5c21("0x8bc", "oZew")], _0x574ca6[_0x5c21("0x414", "hOwa")][_0x5c21("0x8bd", "9GG)")])) _0x3c1d73[_0x5c21("0x8be", "LDjf")][_0x5c21("0x245", ")RsM")] = !1, 
                this[_0x5c21("0x8bf", "gT6R")] = !0; else if (this[_0x5c21("0x8c0", "iAvi")] == _0x574ca6[_0x5c21("0x8c1", "GLHs")][_0x5c21("0x8c2", "bBqT")]) _0x5cbf5e[_0x5c21("0x8c3", "oM#F")](1, _0x420221[_0x5c21("0x8c4", "NTNj")]()[_0x5c21("0x233", ")RsM")][_0x5c21("0x8c5", "Yd[7")]) && (this[_0x5c21("0x8c6", "[GWR")][this[_0x5c21("0x8c7", "bi^r")] - 1] = null); else if (_0x5cbf5e[_0x5c21("0x8c8", "JzeF")]("hitBoxUI", this[_0x5c21("0x8c9", "fIRP")])) return void this[_0x5c21("0x8ca", "JzeF")]();
                _0x3c1d73[_0x5c21("0x8cb", "([2%")][_0x5c21("0x8cc", "Uf[4")] && _0x3c1d73[_0x5c21("0x417", "Uv]h")]["before_pass_limit_export"] && ("gameExport3" == this[_0x5c21("0x8cd", "jQ6r")] || _0x5cbf5e[_0x5c21("0x8ce", "[GWR")] == this["nexUI"]) ? (console[_0x5c21("0x8cf", "(b*P")]("地区限制关卡前的导出关闭"), 
                this["showNextUI"]()) : this[_0x5c21("0x8d0", "omJG")](this[_0x5c21("0x8d1", "GLHs")])[_0x5c21("0x8d2", "CvOU")]();
            } else this[_0x5c21("0x8d3", "gT6R")](); else _0x420221[_0x5c21("0x7cc", "jQ6r")]()[_0x5c21("0x8d4", "(b*P")](() => {
                this[_0x5c21("0x8d5", "CvOU")] += 1, this[_0x5c21("0x8d6", "9T1Q")]();
            }, _0x420221["getIns"]()[_0x5c21("0x2f8", "oM#F")]["auto_video_percent"]);
        }
        static get [_0x5c21("0x8d7", "iAvi")]() {
            return _0x3c1d73[_0x5c21("0x8d8", "&D4Y")];
        }
        [_0x5c21("0x8d9", "rvGE")](_0x199ff0, _0x2fcaa3, _0x26a67a) {
            switch (_0x199ff0) {
              case 1:
                this[_0x5c21("0x8da", "Uf[4")](_0x574ca6[_0x5c21("0x8db", "2^mQ")][_0x5c21("0x8dc", "rvGE")])["Show"](_0x2fcaa3, _0x26a67a);
                break;

              case 2:
                this[_0x5c21("0x8dd", "t@qE")](_0x574ca6["UIType"]["gameExport3"])[_0x5c21("0x8de", "2CMv")](_0x2fcaa3, _0x26a67a);
                break;

              default:
                _0x26a67a && _0x26a67a();
            }
        }
        ["onGameOverClickCancel"](_0x19a7cf) {
            var _0x483f06 = {
                peLAw: function _0x44989e(_0x4cfba3) {
                    return _0x4cfba3();
                }
            };
            var _0x280bc2 = 1;
            null != _0x420221[_0x5c21("0x8df", "bi^r")]()[_0x5c21("0x2f8", "oM#F")][_0x5c21("0x8e0", "&D4Y")] && (_0x280bc2 = _0x420221[_0x5c21("0x6df", "nnjN")]()[_0x5c21("0x294", "[GWR")][_0x5c21("0x8e1", "m[2Q")]), 
            this["ShowGameView"](_0x280bc2, !1, () => {
                _0x19a7cf && _0x483f06[_0x5c21("0x8e2", "hOwa")](_0x19a7cf);
            });
        }
        [_0x5c21("0x8e3", "fIRP")]() {
            this[_0x5c21("0x8e4", ")RsM")](_0x574ca6["UIType"][_0x5c21("0x8e5", "4E!&")])["Show"]();
        }
        [_0x5c21("0x8e6", "8&%b")](_0xda8a86, _0x46c0cb) {
            _0x3c1d73[_0x5c21("0x8e7", "9T1Q")][_0x5c21("0x8e8", "JzeF")][_0x5c21("0x8e9", "(LPe")](_0xda8a86, _0x46c0cb);
        }
        [_0x5c21("0x8da", "Uf[4")](_0x1d791f) {
            return _0x3c1d73["Inst"][_0x5c21("0x8ea", "nnjN")][_0x5c21("0x8eb", "hOwa")](_0x1d791f);
        }
        ["onOpenChest"]() {
            1 == _0x420221[_0x5c21("0x7a2", "JzeF")]()[_0x5c21("0x1f2", "nnjN")][_0x5c21("0x8ec", "TOp9")] ? this[_0x5c21("0x8ed", "AQRo")](_0x574ca6["UIType"]["hitBoxUI1"])[_0x5c21("0x8ee", "m*dV")](() => {}) : 2 == _0x420221[_0x5c21("0x7f4", "LDjf")]()["config"][_0x5c21("0x8ef", "4yM]")] ? this["GetUI"](_0x574ca6[_0x5c21("0x8f0", ")RsM")]["hitBoxUI2"])[_0x5c21("0x8f1", "MjE8")](() => {}) : this[_0x5c21("0x8f2", "nnjN")]();
        }
    }
    class _0x16d180 extends Laya[_0x5c21("0x8f3", "(LPe")] {
        constructor() {
            super(), this["isBanner"] = !0, this[_0x5c21("0x8f4", "GLHs")] = !0;
        }
        ["onAwake"]() {
            this[_0x5c21("0x8f5", "efPG")]();
        }
        ["initUI"]() {
            this[_0x5c21("0x8f6", "TOp9")] = 1, _0x3c1d73[_0x5c21("0x676", "2CMv")][_0x5c21("0x8f7", "4yM]")] += 1, 
            this[_0x5c21("0x8f8", "Uv]h")] = null, _0x3c1d73[_0x5c21("0x68b", "(b*P")][_0x5c21("0x86a", ")RsM")] > 6 && _0x3c1d73[_0x5c21("0x8f9", "bBqT")][_0x5c21("0x8fa", "oM#F")](), 
            this[_0x5c21("0x8fb", "AQRo")] = !0;
        }
        [_0x5c21("0x8fc", "4yM]")](_0x5dadc7 = !1, _0x21df8c = null) {
            switch (_0x3c1d73["Inst"][_0x5c21("0x8fd", "iAvi")](_0x574ca6[_0x5c21("0x8fe", "%9(3")]["likeExport"]) && _0x3c1d73[_0x5c21("0x8ff", "JzeF")][_0x5c21("0x900", "4yM]")](_0x574ca6["UIType"][_0x5c21("0x901", "(b*P")])[_0x5c21("0x902", "ikmV")](), 
            this["owner"][_0x5c21("0x7dd", "&D4Y")] = !0, this[_0x5c21("0x903", "fIRP")]) {
              case 0:
                _0x420221["getIns"]()["hideBanner"]();
                break;

              case 1:
                _0x420221["getIns"]()[_0x5c21("0x904", "UOab")](this["moveBtn"], _0x3c1d73["Inst"][_0x5c21("0x8e3", "fIRP")]);
                break;

              case 2:
                _0x3c1d73[_0x5c21("0x905", "MjE8")]["showLikeList"](), _0x420221[_0x5c21("0x906", "ggF#")]()[_0x5c21("0x907", "Uf[4")](this[_0x5c21("0x908", "jQ6r")]);
            }
            window["wx"] && 1 == _0x420221[_0x5c21("0x33e", "dZ3i")]()[_0x5c21("0x1b7", "oZew")][_0x5c21("0x909", "UOab")] && (this[_0x5c21("0x90a", "[GWR")] ? _0x4176cc[_0x5c21("0x6ca", "NTNj")][_0x5c21("0x90b", "hOwa")]() : _0x4176cc["Inst"][_0x5c21("0x90c", "omJG")]());
        }
        [_0x5c21("0x90d", "Uf[4")]() {
            this[_0x5c21("0x626", "8&%b")][_0x5c21("0x90e", "gT6R")] = !1, _0x420221["getIns"]()[_0x5c21("0x90f", "MjE8")](), 
            _0x420221[_0x5c21("0x910", "(b*P")]()[_0x5c21("0x911", "bi^r")]();
        }
        [_0x5c21("0x912", "9T1Q")](_0x2f5a68) {}
    }
    class _0x5ba43a extends _0x16d180 {
        constructor() {
            super(), _0x3c81f2 = this;
        }
        ["initUI"]() {
            var _0xb8e631 = {
                dOvHM: _0x5cbf5e[_0x5c21("0x913", "omJG")]
            };
            _0x3c1d73[_0x5c21("0x8d7", "iAvi")][_0x5c21("0x914", "m*dV")](_0x574ca6[_0x5c21("0x915", "*$CX")]["homeUI"], this), 
            super[_0x5c21("0x916", "gT6R")](), this[_0x5c21("0x917", "NYmF")] = this["owner"][_0x5c21("0x918", "Uf[4")](_0x5cbf5e[_0x5c21("0x919", "MjE8")]), 
            this["moreGameBtn"]["y"] = _0x5cbf5e[_0x5c21("0x91a", "efPG")](_0x5cbf5e["NcDWW"](Laya[_0x5c21("0x91b", "UOab")][_0x5c21("0x91c", "hOwa")], _0x5cbf5e[_0x5c21("0x91d", "2CMv")](135, _0x420221[_0x5c21("0x868", "omJG")]()[_0x5c21("0x91e", "rvGE")])), 50), 
            _0x14063c["onBtnFunction"](this["moreGameBtn"], Laya["Event"]["CLICK"], () => {
                _0x3c1d73[_0x5c21("0x91f", "ggF#")][_0x5c21("0x920", "ggF#")](_0x420221["getIns"]()["config"]["home_moreGameCliCk_showBox"], !1, () => {
                    this[_0x5c21("0x921", "([2%")]();
                });
            }), this[_0x5c21("0x922", "jQ6r")][_0x5c21("0x923", "UOab")] = _0x420221[_0x5c21("0x142", "rvGE")]()[_0x5c21("0x924", "8&%b")][_0x5c21("0x925", "jQ6r")] && _0x5cbf5e[_0x5c21("0x926", "GLHs")](_0x420221["getIns"]()[_0x5c21("0x927", "CvOU")][_0x5c21("0x928", "GLHs")], 0), 
            this[_0x5c21("0x929", "UOab")] = this["owner"][_0x5c21("0x92a", "9T1Q")]("left"), 
            this["rightItem"] = this[_0x5c21("0x92b", "Uv]h")]["getChildByName"](_0x5cbf5e[_0x5c21("0x92c", "omJG")]), 
            this[_0x5c21("0x92d", "oZew")]["y"] = this[_0x5c21("0x92e", "9GG)")]["y"] = _0x5cbf5e[_0x5c21("0x92f", "GLHs")](_0x5cbf5e["IadUb"](Laya[_0x5c21("0x930", ")RsM")][_0x5c21("0x931", "m*dV")], 140 * _0x420221[_0x5c21("0x932", "TOp9")]()[_0x5c21("0x933", "m*dV")]), 200), 
            this["listItem"] = [];
            for (var _0xa137e7 = 0; _0xa137e7 < this[_0x5c21("0x934", "Uv]h")][_0x5c21("0x935", "*$CX")]; _0xa137e7++) this["listItem"][_0x5c21("0x936", "oZew")](this[_0x5c21("0x937", "4yM]")]["getChildAt"](_0xa137e7)), 
            this["listItem"]["push"](this[_0x5c21("0x938", "nnjN")][_0x5c21("0x939", "AQRo")](_0xa137e7));
            this["listGameExportData"] = _0x420221["getIns"]()["config"][_0x5c21("0x93a", "jQ6r")];
            for (_0xa137e7 = 0; _0x5cbf5e["YVAeQ"](_0xa137e7, this[_0x5c21("0x93b", "gT6R")][_0x5c21("0x93c", "ggF#")]); ++_0xa137e7) this["listItem"][_0xa137e7][_0x5c21("0x93d", "[GWR")] = _0x420221[_0x5c21("0x93e", "fIRP")]()[_0x5c21("0x303", "TOp9")]["floatad_cancel_click_cz"] > -1, 
            this[_0x5c21("0x93f", "oM#F")][_0xa137e7]["on"](Laya[_0x5c21("0x940", "gT6R")][_0x5c21("0x941", "&D4Y")], this, function(_0x590621) {
                _0x590621 < this["listRand"][_0x5c21("0x942", "oZew")] && _0x420221["getIns"]()[_0x5c21("0x943", ")RsM")](this[_0x5c21("0x944", "UOab")][this["listRand"][_0x590621]], null, function() {
                    _0x3c1d73[_0x5c21("0x945", "nnjN")][_0x5c21("0x946", "*$CX")](_0x420221[_0x5c21("0x8a0", ")RsM")]()[_0x5c21("0x231", "jQ6r")]["floatad_cancel_click_cz"], !1, () => {
                        _0x3c81f2[_0x5c21("0x947", "GLHs")]();
                    });
                }, _0xb8e631[_0x5c21("0x948", "iAvi")]);
            }, [ _0xa137e7 ]);
            1 == _0x420221["getIns"]()[_0x5c21("0x8a3", "4yM]")][_0x5c21("0x949", "2^mQ")] && this[_0x5c21("0x94a", "NTNj")]["length"] > 0 ? (this[_0x5c21("0x94b", "r#o%")](), 
            Laya[_0x5c21("0x94c", "4E!&")][_0x5c21("0x94d", "9T1Q")](3e3, this, this["m_randItem"])) : this[_0x5c21("0x94e", "&D4Y")]["visible"] = this[_0x5c21("0x94f", "CvOU")]["visible"] = !1, 
            _0x3c1d73[_0x5c21("0x950", "AQRo")][_0x5c21("0x951", "dZ3i")] && (console["log"](_0x5cbf5e["LOaMh"]), 
            this[_0x5c21("0x952", "2CMv")]["visible"] = this["rightItem"]["visible"] = !1), 
            this[_0x5c21("0x953", "JzeF")] = _0x420221[_0x5c21("0x954", "r#o%")]()[_0x5c21("0x890", "GLHs")]["homeUI_showExport"], 
            this[_0x5c21("0x955", "al%z")] = this["owner"]["getChildByName"](_0x5c21("0x956", "TOp9")), 
            this[_0x5c21("0x957", "hOwa")]["on"](Laya[_0x5c21("0x958", "AQRo")][_0x5c21("0x959", "rvGE")], this, this[_0x5c21("0x95a", "AQRo")]), 
            this[_0x5c21("0x95b", "efPG")]["y"] = _0x5cbf5e[_0x5c21("0x95c", "jQ6r")](Laya[_0x5c21("0x251", "al%z")]["height"] - 140 * _0x420221[_0x5c21("0x910", "(b*P")]()["PixY"] - 50, 100), 
            this[_0x5c21("0x95d", "bi^r")](), this[_0x5c21("0x95e", "([2%")]();
        }
        [_0x5c21("0x95f", "nnjN")]() {
            super["Show"]();
        }
        ["Hide"]() {
            super[_0x5c21("0x960", "r#o%")]();
        }
        ["onStartGame"]() {
            _0x3c1d73[_0x5c21("0x8e7", "9T1Q")][_0x5c21("0x961", "(b*P")][_0x5c21("0x962", "m[2Q")] && (this[_0x5c21("0x963", "al%z")](), 
            _0x3c1d73[_0x5c21("0x964", "TOp9")][_0x5c21("0x965", "MjE8")]());
        }
        [_0x5c21("0x966", "m[2Q")]() {
            this[_0x5c21("0x967", "4yM]")] = [];
            for (var _0x12084b = 0; _0x12084b < this[_0x5c21("0x968", "2CMv")]["length"]; _0x12084b++) {
                var _0x1c041a = _0x420221[_0x5c21("0x969", "oZew")]()["ranInt"](0, _0x5cbf5e[_0x5c21("0x96a", "ggF#")](this[_0x5c21("0x96b", "bBqT")][_0x5c21("0x96c", "ikmV")], 1));
                -1 != this[_0x5c21("0x96d", "9T1Q")]["indexOf"](_0x1c041a) && _0x5cbf5e["GCYPd"](this[_0x5c21("0x96e", "2^mQ")][_0x5c21("0x96f", "AQRo")], this[_0x5c21("0x970", "4yM]")][_0x5c21("0x1fb", "CvOU")]) ? _0x12084b -= 1 : this[_0x5c21("0x971", "MjE8")][_0x5c21("0x972", "hOwa")](_0x1c041a);
            }
            for (_0x12084b = 0; _0x12084b < this[_0x5c21("0x973", "m[2Q")][_0x5c21("0x974", "fIRP")]; ++_0x12084b) this["m_SetItemPic"](_0x12084b, this["listGameExportData"][this[_0x5c21("0x975", "*$CX")][_0x12084b]]), 
            this[_0x5c21("0x976", "MjE8")](_0x12084b);
        }
        [_0x5c21("0x977", "2^mQ")](_0x36a3c0, _0x41a311) {
            var _0x56484c = this["listItem"][_0x36a3c0];
            _0x56484c[_0x5c21("0x4ca", "%9(3")](_0x5cbf5e[_0x5c21("0x978", "MjE8")])[_0x5c21("0x979", "Uv]h")] = _0x41a311[_0x5c21("0x97a", "Yd[7")], 
            9 == _0x41a311[_0x5c21("0x97b", "(b*P")] && (_0x56484c[_0x5c21("0x97c", "Yd[7")](_0x5cbf5e["LflRg"])["clipX"] = 3, 
            _0x56484c["getChildByName"](_0x5cbf5e[_0x5c21("0x97d", "&D4Y")])["clipY"] = 3, _0x56484c["getChildByName"](_0x5cbf5e[_0x5c21("0x97e", "2(Lk")])["autoPlay"] = !0, 
            _0x56484c[_0x5c21("0x97f", "m[2Q")](_0x5cbf5e[_0x5c21("0x980", "jQ6r")])[_0x5c21("0x981", "gT6R")] = 500);
        }
        ["m_Tween"](_0x428b7b) {
            Laya[_0x5c21("0x982", "jQ6r")]["to"](this[_0x5c21("0x983", "9GG)")][_0x428b7b], {
                rotation: -10
            }, 100, Laya["Ease"][_0x5c21("0x984", "GLHs")], Laya[_0x5c21("0x985", "hOwa")][_0x5c21("0x986", "efPG")](this, function(_0x3dc49c) {
                Laya[_0x5c21("0x987", "9T1Q")]["to"](this[_0x5c21("0x988", "oZew")][_0x3dc49c], {
                    rotation: 10
                }, 150, Laya["Ease"][_0x5c21("0x989", "LDjf")], Laya["Handler"][_0x5c21("0x98a", "jQ6r")](this, function(_0x1b87e6) {
                    Laya["Tween"]["to"](this[_0x5c21("0x98b", "r#o%")][_0x1b87e6], {
                        rotation: 0
                    }, 100, Laya["Ease"]["linearNone"], Laya[_0x5c21("0x98c", "AQRo")]["create"](this, function(_0x3e850a) {}, [ _0x1b87e6 ]));
                }, [ _0x3dc49c ]));
            }, [ _0x428b7b ]), 0);
        }
        [_0x5c21("0x98d", "NTNj")]() {
            if (this[_0x5c21("0x98e", "MjE8")][_0x5c21("0x923", "UOab")]) {
                let _0x560ec1 = Laya[_0x5c21("0x609", "t@qE")]["to"](this[_0x5c21("0x98f", "8&%b")], {
                    scaleX: 1.1,
                    scaleY: 1.1
                }, 500, Laya["Ease"][_0x5c21("0x517", "9T1Q")], Laya[_0x5c21("0x990", "jQ6r")]["create"](this, () => {
                    Laya["Tween"][_0x5c21("0x991", "al%z")](_0x560ec1), this[_0x5c21("0x992", "UOab")]();
                }));
            }
        }
        ["smallTween"]() {
            if (this[_0x5c21("0x993", "omJG")]["visible"]) {
                let _0xde9e32 = Laya[_0x5c21("0x994", "hOwa")]["to"](this[_0x5c21("0x995", "Yd[7")], {
                    scaleX: .9,
                    scaleY: .9
                }, 500, Laya[_0x5c21("0x996", "bBqT")]["linearNone"], Laya[_0x5c21("0x997", "UOab")][_0x5c21("0x998", "bi^r")](this, () => {
                    Laya["Tween"][_0x5c21("0x999", "dZ3i")](_0xde9e32), this[_0x5c21("0x99a", "CvOU")]();
                }));
            }
        }
    }
    class _0x2e5964 extends _0x16d180 {
        constructor() {
            super();
        }
        [_0x5c21("0x99b", "m[2Q")]() {
            _0x3c1d73[_0x5c21("0x99c", "[GWR")]["RegUI"](_0x574ca6["UIType"]["gameUI"], this), 
            super[_0x5c21("0x99d", "[GWR")](), this["Hide"](), this[_0x5c21("0x99e", "9GG)")] = this[_0x5c21("0x6af", "2^mQ")]["getChildByName"](_0x5c21("0x99f", "Uv]h")), 
            this["playTip"] = this["owner"][_0x5c21("0x9a0", "Uv]h")](_0x5c21("0x9a1", "m[2Q")), 
            this[_0x5c21("0x9a2", "oM#F")]["y"] = 900 / 1334 * Laya[_0x5c21("0x9a3", "efPG")][_0x5c21("0x9a4", "ggF#")], 
            this["gameProess"] = this[_0x5c21("0x9a5", "efPG")]["getChildByName"](_0x5cbf5e[_0x5c21("0x9a6", "([2%")]), 
            this[_0x5c21("0x9a7", "m*dV")] = this[_0x5c21("0x9a8", "MjE8")][_0x5c21("0x9a9", "2(Lk")](_0x5cbf5e[_0x5c21("0x9aa", "rvGE")]);
        }
        [_0x5c21("0x9ab", "efPG")]() {
            super[_0x5c21("0x9ac", "al%z")](), this["playTip"]["x"] = 170, this["playTip"][_0x5c21("0x9ad", "NTNj")] = !0, 
            this[_0x5c21("0x9ae", "iAvi")]["value"] = _0x36ffa1[_0x5c21("0x9af", "Uf[4")]["level"], 
            this[_0x5c21("0x9b0", "gT6R")][_0x5c21("0x9b1", "JzeF")] = 0, this[_0x5c21("0x9b2", "&D4Y")]["x"] = 216, 
            this[_0x5c21("0x9b3", "(b*P")](), _0x3c1d73[_0x5c21("0x630", "9GG)")]["gameCtrll"][_0x5c21("0x9b4", "fIRP")]();
        }
        [_0x5c21("0x90d", "Uf[4")]() {
            super["Hide"]();
        }
        [_0x5c21("0x9b5", "dZ3i")]() {
            this[_0x5c21("0x9b6", "gT6R")][_0x5c21("0x9b7", "al%z")] ? Laya[_0x5c21("0x9b8", "m*dV")]["to"](this["playTip"], {
                x: 0
            }, 1500, Laya[_0x5c21("0x9b9", ")RsM")][_0x5c21("0x528", "nnjN")], Laya["Handler"][_0x5c21("0x9ba", "gT6R")](this, () => {
                this[_0x5c21("0x9bb", "%9(3")]();
            })) : Laya[_0x5c21("0x524", "2CMv")]["clearAll"](this["playTip"]);
        }
        [_0x5c21("0x9bc", "rvGE")]() {
            this[_0x5c21("0x9bd", "al%z")][_0x5c21("0x9be", "AQRo")] ? Laya[_0x5c21("0x9bf", "LDjf")]["to"](this[_0x5c21("0x9c0", "fIRP")], {
                x: 175
            }, 1500, Laya[_0x5c21("0x9c1", "efPG")][_0x5c21("0x59f", "AQRo")], Laya["Handler"]["create"](this, () => {
                this[_0x5c21("0x9c2", "rvGE")]();
            })) : Laya[_0x5c21("0x9c3", "omJG")][_0x5c21("0x9c4", "(LPe")](this["playTip"]);
        }
    }
    class _0x5d3213 extends _0x16d180 {
        constructor() {
            super();
        }
        [_0x5c21("0x9c5", "dZ3i")]() {
            _0x3c1d73[_0x5c21("0x244", "gT6R")]["RegUI"](_0x574ca6[_0x5c21("0x9c6", "2CMv")]["resultUI"], this), 
            super[_0x5c21("0x9c7", "Yd[7")](), this[_0x5c21("0x9c8", "JzeF")] = 0, this[_0x5c21("0x9c9", "hOwa")] = this["owner"]["getChildByName"](_0x5c21("0x9ca", "fIRP")), 
            this[_0x5c21("0x9cb", "LDjf")]["y"] = Laya["stage"][_0x5c21("0xed", "r#o%")] / 2, 
            this["bottomUI"] = this[_0x5c21("0x9a8", "MjE8")][_0x5c21("0x4de", "iAvi")](_0x5cbf5e[_0x5c21("0x9cc", "9GG)")]), 
            this[_0x5c21("0x9cd", "2(Lk")]["y"] = _0x5cbf5e[_0x5c21("0x9ce", "&D4Y")](Laya["stage"][_0x5c21("0x9cf", "[GWR")] - _0x420221[_0x5c21("0x9d0", "&D4Y")]()["bannerheight"] * _0x420221[_0x5c21("0x6a3", "al%z")]()[_0x5c21("0x9d1", "NTNj")], 30), 
            this["topUI"] = this[_0x5c21("0x9d2", "([2%")]["getChildByName"](_0x5cbf5e[_0x5c21("0x9d3", "bBqT")]), 
            this["nextBtn"] = this[_0x5c21("0x9d4", "2CMv")][_0x5c21("0x9d5", "9GG)")](_0x5c21("0x9d6", "t@qE")), 
            this[_0x5c21("0x9d7", "nnjN")] = _0x420221[_0x5c21("0x9d8", "NYmF")]()[_0x5c21("0x241", "2^mQ")][_0x5c21("0x9d9", "gT6R")], 
            this[_0x5c21("0x9da", "omJG")] = this[_0x5c21("0x9db", "Uf[4")][_0x5c21("0x9dc", "(b*P")](_0x5c21("0x9dd", "ikmV")), 
            this[_0x5c21("0x9de", "rvGE")] = this[_0x5c21("0x9df", "nnjN")]["getChildByName"](_0x5cbf5e[_0x5c21("0x9e0", "CvOU")]), 
            this[_0x5c21("0x9e1", "%9(3")][_0x5c21("0x9e2", "fIRP")] = 2, this[_0x5c21("0x9de", "rvGE")][_0x5c21("0x9e3", "2CMv")] = 2, 
            this[_0x5c21("0x9e4", "(LPe")][_0x5c21("0x9e5", "MjE8")] = new (Laya[_0x5c21("0x607", "[GWR")])(this, this["render"]), 
            this["list"]["array"] = this[_0x5c21("0x9e6", "[GWR")], _0x14063c["onBtnFunction"](this[_0x5c21("0x9e7", "m[2Q")], Laya[_0x5c21("0x9e8", "al%z")][_0x5c21("0x9e9", "gT6R")], () => {
                this[_0x5c21("0x9ea", "rvGE")]();
            }), this[_0x5c21("0x9eb", "GLHs")] = _0x420221["getIns"]()[_0x5c21("0x8a6", "m*dV")][_0x5c21("0x9ec", "[GWR")], 
            this[_0x5c21("0x9ed", "UOab")] = this[_0x5c21("0x9ee", "JzeF")];
        }
        [_0x5c21("0x9ef", "iAvi")](_0x3ca25d, _0x53eba3) {
            _0x3ca25d["getChildByName"](_0x5cbf5e[_0x5c21("0x9f0", "8&%b")])[_0x5c21("0x9f1", "r#o%")] = this[_0x5c21("0x9f2", "Uf[4")][this["showIdex"]]["name"], 
            _0x3ca25d[_0x5c21("0x4e0", "oM#F")](_0x5cbf5e["LflRg"])[_0x5c21("0x9f3", "MjE8")] = this[_0x5c21("0x9f4", "8&%b")][this[_0x5c21("0x9f5", "CvOU")]][_0x5c21("0x9f6", "jQ6r")], 
            9 == this["listGameExportData"][this[_0x5c21("0x9f7", "Uv]h")]][_0x5c21("0x9f8", "bBqT")] ? (_0x3ca25d["getChildByName"](_0x5c21("0x9f9", "LDjf"))[_0x5c21("0x9fa", ")RsM")] = 3, 
            _0x3ca25d["getChildByName"](_0x5cbf5e[_0x5c21("0x9fb", "2CMv")])["clipY"] = 3, _0x3ca25d["getChildByName"](_0x5cbf5e[_0x5c21("0x9fc", "8&%b")])[_0x5c21("0x9fd", "MjE8")] = !0, 
            _0x3ca25d[_0x5c21("0x97f", "m[2Q")](_0x5cbf5e[_0x5c21("0x9fe", "JzeF")])[_0x5c21("0x9ff", "m*dV")] = 500) : (_0x3ca25d[_0x5c21("0xa00", "GLHs")](_0x5cbf5e[_0x5c21("0xa01", "al%z")])[_0x5c21("0xa02", "([2%")] = 0, 
            _0x3ca25d[_0x5c21("0xa03", "*$CX")](_0x5cbf5e[_0x5c21("0xa04", "t@qE")])[_0x5c21("0xa05", "2^mQ")] = 0, 
            _0x3ca25d["getChildByName"](_0x5cbf5e["LflRg"])[_0x5c21("0xa06", "LDjf")] = !1), 
            _0x5cbf5e["ZsLjQ"](1, _0x420221[_0x5c21("0xa07", "(LPe")]()["config"][_0x5c21("0xa08", "JzeF")]) && _0x5cbf5e["PXDFK"](Math[_0x5c21("0x781", "m*dV")](), .5) && (_0x3ca25d[_0x5c21("0xa09", "r#o%")](_0x5c21("0xa0a", "8&%b"))["visible"] = !0), 
            _0x3ca25d["offAll"](Laya[_0x5c21("0xa0b", "fIRP")]["CLICK"]), _0x3ca25d["on"](Laya[_0x5c21("0x9e8", "al%z")][_0x5c21("0xa0c", "4E!&")], this, function() {
                _0x420221[_0x5c21("0x9d8", "NYmF")]()["AldingRecord"]("结束游戏的盒子-icon点击"), _0x420221[_0x5c21("0x142", "rvGE")]()[_0x5c21("0xa0d", "nnjN")](this[_0x5c21("0xa0e", "bi^r")][this[_0x5c21("0x9f7", "Uv]h")]], null, function() {
                    _0x3c1d73[_0x5c21("0xa0f", "GLHs")][_0x5c21("0xa10", "MjE8")](() => {
                        _0x420221["getIns"]()[_0x5c21("0xe3", "rvGE")](this[_0x5c21("0xa11", "(LPe")], _0x3c1d73[_0x5c21("0xa12", "2(Lk")]["showLikeList"]);
                    }), this[_0x5c21("0xa13", "LDjf")](_0x3ca25d);
                }[_0x5c21("0xa14", "(LPe")](this), _0x5cbf5e["Bgqok"]);
            }), this["showIdex"] += 1, this["showIdex"] >= this[_0x5c21("0xa15", "ggF#")]["length"] && (this["showIdex"] = 0);
        }
        [_0x5c21("0xa16", "2CMv")](_0x2a9282) {
            this[_0x5c21("0xa17", "%9(3")] += 1, this[_0x5c21("0xa18", "ggF#")] >= this["listGameExportData"][_0x5c21("0x7ea", "([2%")] && (this[_0x5c21("0xa19", "&D4Y")] = 0), 
            _0x2a9282["getChildByName"](_0x5cbf5e[_0x5c21("0xa1a", "oZew")])["text"] = this["listGameExportData"][this[_0x5c21("0xa1b", "al%z")]][_0x5c21("0x66e", "rvGE")], 
            _0x2a9282[_0x5c21("0x4de", "iAvi")](_0x5c21("0xa1c", "2CMv"))["skin"] = this["listGameExportData"][this[_0x5c21("0x9f5", "CvOU")]]["images"], 
            9 == this["listGameExportData"][this["showIdex"]]["frame"] ? (_0x2a9282["getChildByName"](_0x5cbf5e["LflRg"])[_0x5c21("0xa1d", "t@qE")] = 3, 
            _0x2a9282[_0x5c21("0xa1e", ")RsM")]("Pic")[_0x5c21("0xa1f", "8&%b")] = 3, _0x2a9282[_0x5c21("0xa20", "4yM]")](_0x5cbf5e["LflRg"])["autoPlay"] = !0, 
            _0x2a9282[_0x5c21("0xa21", "TOp9")](_0x5cbf5e[_0x5c21("0xa22", "(LPe")])[_0x5c21("0xa23", "iAvi")] = 500) : (_0x2a9282[_0x5c21("0x92a", "9T1Q")](_0x5c21("0xa24", "bi^r"))[_0x5c21("0xa25", "4yM]")] = 0, 
            _0x2a9282[_0x5c21("0xa26", "&D4Y")]("Pic")["clipY"] = 0, _0x2a9282[_0x5c21("0x9a9", "2(Lk")](_0x5cbf5e[_0x5c21("0xa27", "ggF#")])[_0x5c21("0xa28", "bBqT")] = !1), 
            _0x2a9282[_0x5c21("0xa29", "nnjN")](Laya[_0x5c21("0xa2a", "Uv]h")][_0x5c21("0xa2b", "%9(3")]), 
            _0x2a9282["on"](Laya[_0x5c21("0xa2c", "t@qE")]["CLICK"], this, function() {
                _0x420221[_0x5c21("0x8ae", "%9(3")]()[_0x5c21("0xa2d", ")RsM")](_0x5c21("0xa2e", "JzeF")), 
                _0x420221[_0x5c21("0xa2f", "AQRo")]()[_0x5c21("0xa30", "(b*P")](this[_0x5c21("0x94a", "NTNj")][this[_0x5c21("0xa31", "gT6R")]], null, function() {
                    _0x3c1d73[_0x5c21("0x945", "nnjN")]["onGameOverClickCancel"](() => {
                        _0x420221[_0x5c21("0x8a5", "UOab")]()[_0x5c21("0xa32", "*$CX")](this[_0x5c21("0x9cd", "2(Lk")], _0x3c1d73[_0x5c21("0xa33", "jQ6r")][_0x5c21("0xa34", "UOab")]);
                    }), this["refreshBox"](_0x2a9282);
                }[_0x5c21("0xa35", "&D4Y")](this), _0x5c21("0xa36", "2(Lk"));
            });
        }
        [_0x5c21("0xa37", "Uf[4")](_0x1952c4) {
            _0x574ca6["curUI"] = _0x574ca6["UIType"][_0x5c21("0xa38", "iAvi")], _0x420221[_0x5c21("0x86c", "CvOU")]()[_0x5c21("0xa39", "2^mQ")](this[_0x5c21("0xa3a", "LDjf")]), 
            this[_0x5c21("0xa3b", "8&%b")] = 0, this["list"][_0x5c21("0xa3c", "(LPe")] = this[_0x5c21("0xa3d", "oM#F")], 
            this["list"][_0x5c21("0xa3e", "JzeF")](), Laya[_0x5c21("0xa3f", "LDjf")][_0x5c21("0xa40", "efPG")](this), 
            Laya["timer"]["loop"](3e3, this, () => {
                this[_0x5c21("0xa41", "m*dV")]["refresh"]();
            }), _0x14063c["IsSuccess"] ? (this["logo"]["skin"] = _0x5cbf5e["MRztR"], _0x36ffa1["Data"][_0x5c21("0xa42", "nnjN")] += 1) : this[_0x5c21("0x9da", "omJG")][_0x5c21("0xa43", "4E!&")] = _0x5cbf5e["jYEMv"], 
            _0x36ffa1[_0x5c21("0xa44", "iAvi")](), _0x3c1d73["Inst"][_0x5c21("0xa45", "hOwa")][_0x5c21("0xa46", "AQRo")](), 
            super["Show"](), 1 == _0x420221[_0x5c21("0xa47", "[GWR")]()[_0x5c21("0xa48", "bBqT")][_0x5c21("0xa49", "LDjf")] ? this[_0x5c21("0xa4a", "Uv]h")]() : this[_0x5c21("0xa4b", "gT6R")][_0x5c21("0xa4c", "m[2Q")] = !1;
        }
        [_0x5c21("0xa4d", "nnjN")]() {
            Laya["timer"][_0x5c21("0xa4e", "al%z")](this), super[_0x5c21("0xa4f", ")RsM")](), 
            _0x3c1d73[_0x5c21("0xa50", "efPG")]["showNextUI"](), Laya[_0x5c21("0xa51", "(b*P")][_0x5c21("0xa52", "al%z")](_0x5c21("0xa53", "efPG") + _0x36ffa1[_0x5c21("0xa54", "AQRo")][_0x5c21("0xa55", "GLHs")] % 2 + _0x5c21("0xa56", "jQ6r"), 0);
        }
        [_0x5c21("0xa57", "r#o%")]() {
            for (var _0x4b8791 in this[_0x5c21("0xa58", "omJG")]["x"] = -500, this[_0x5c21("0xa59", "AQRo")]["cells"]) this[_0x5c21("0xa5a", "Uv]h")][_0x5c21("0xa5b", "UOab")][_0x4b8791][_0x5c21("0xa5c", "efPG")] = -180, 
            Laya[_0x5c21("0xa5d", "oM#F")]["to"](this[_0x5c21("0xa5e", "efPG")]["cells"][_0x4b8791], {
                rotation: 0
            }, 500, Laya[_0x5c21("0x6e9", "jQ6r")][_0x5c21("0xa5f", "bBqT")], null);
            Laya[_0x5c21("0xa60", "*$CX")]["to"](this[_0x5c21("0xa61", "4E!&")], {
                x: 68
            }, 500, Laya[_0x5c21("0xa62", "9GG)")][_0x5c21("0xa63", "al%z")], null);
        }
    }
    var _0x4193f4, _0xcfe09e, _0x4e2584, _0x202161 = Laya["Browser"]["window"]["wx"];
    class _0x526149 extends Laya[_0x5c21("0xa64", "iAvi")] {
        constructor() {
            super(), this[_0x5c21("0xa65", "&D4Y")] = !1, this[_0x5c21("0xa66", "bBqT")] = 0, 
            _0x4193f4 = this;
        }
        ["onEnable"]() {
            _0x3c1d73["Inst"][_0x5c21("0xa67", "TOp9")](_0x574ca6["UIType"][_0x5c21("0xa68", "9GG)")], this), 
            this["clickCount"] = 0, this[_0x5c21("0xa69", "bi^r")] = this[_0x5c21("0xa6a", "ggF#")][_0x5c21("0xa6b", "fIRP")](_0x5cbf5e[_0x5c21("0xa6c", "NYmF")]), 
            this[_0x5c21("0xa6d", "Yd[7")] = this["page1"][_0x5c21("0x4ca", "%9(3")](_0x5c21("0xa6e", "([2%")), 
            this["chest"]["y"] = _0x5cbf5e["UgQLk"](700, 1624) * Laya[_0x5c21("0xa6f", "Yd[7")]["height"], 
            this[_0x5c21("0xa70", "ggF#")] = this["owner"][_0x5c21("0xa71", "hOwa")](_0x5cbf5e[_0x5c21("0xa72", "MjE8")])["getChildByName"](_0x5cbf5e[_0x5c21("0xa73", "al%z")]), 
            this[_0x5c21("0xa74", "m*dV")]["y"] = 700 / 1624 * Laya["stage"]["height"], this[_0x5c21("0x85e", "hOwa")][_0x5c21("0xa75", "NYmF")](_0x5cbf5e[_0x5c21("0xa76", "oZew")])["getChildByName"](_0x5cbf5e[_0x5c21("0xa77", "9T1Q")])["y"] = 200 / 1624 * Laya[_0x5c21("0xa78", "8&%b")][_0x5c21("0xa79", "8&%b")], 
            this[_0x5c21("0xa7a", "CvOU")] = this[_0x5c21("0xa7b", "NYmF")]["getChildByName"](_0x5cbf5e[_0x5c21("0xa7c", "4yM]")])[_0x5c21("0xa7d", "LDjf")]("hitbox1bottom")[_0x5c21("0x4de", "iAvi")](_0x5c21("0xa7e", "oZew")), 
            this["Btn_Click"] = this["owner"][_0x5c21("0xa7f", "4E!&")](_0x5c21("0xa80", "hOwa"))[_0x5c21("0xa81", "ggF#")]("hitbox1bottom")[_0x5c21("0xa00", "GLHs")](_0x5c21("0x50", "2^mQ")), 
            this[_0x5c21("0xa82", "dZ3i")][_0x5c21("0xa83", "omJG")](_0x5cbf5e[_0x5c21("0xa84", "([2%")])["getChildByName"](_0x5cbf5e[_0x5c21("0xa85", "nnjN")])["y"] = Laya[_0x5c21("0xa86", "NTNj")]["height"], 
            _0x14063c[_0x5c21("0xa87", "oZew")](this[_0x5c21("0xa88", "gT6R")], Laya[_0x5c21("0x807", "hOwa")][_0x5c21("0xa89", "Uf[4")], () => {
                this[_0x5c21("0xa8a", "LDjf")]();
            }), Laya[_0x5c21("0xa8b", "[GWR")]["onWeiXin"], this[_0x5c21("0xa8c", "GLHs")] = _0x420221[_0x5c21("0x954", "r#o%")]()[_0x5c21("0xa8d", "AQRo")][_0x5c21("0xa8e", "9T1Q")] / 60 || 1;
        }
        [_0x5c21("0xa8f", "efPG")]() {
            this[_0x5c21("0xa90", "9GG)")] && (this[_0x5c21("0xa91", "[GWR")]["rotation"] += 2), 
            _0x5cbf5e[_0x5c21("0xa92", "ggF#")](this["Pro_Value"][_0x5c21("0xa93", "GLHs")], 0) && (this[_0x5c21("0xa94", "iAvi")] -= this[_0x5c21("0xa95", "ggF#")], 
            this[_0x5c21("0xa96", "&D4Y")][_0x5c21("0xa97", "rvGE")] -= this[_0x5c21("0xa98", "MjE8")] / 100);
        }
        [_0x5c21("0xa99", "(LPe")]() {}
        ["Show"](_0x466e5e, _0x176721 = !0) {
            if (_0x574ca6["curUI"] = _0x574ca6["UIType"][_0x5c21("0xa9a", "ggF#")], _0x4193f4[_0x5c21("0xa9b", "UOab")] = _0x176721, 
            _0x4193f4[_0x5c21("0xa9c", "iAvi")] = _0x466e5e, 0 == _0x420221[_0x5c21("0x93e", "fIRP")]()["config"][_0x5c21("0xa9d", "[GWR")]) return _0x4193f4["isSuc"] && (_0x4193f4[_0x5c21("0xa9e", "([2%")](), 
            _0x4193f4[_0x5c21("0xa9f", "4E!&")] = null), void (_0x4193f4[_0x5c21("0xaa0", "4E!&")] && _0x3c1d73[_0x5c21("0xaa1", "UOab")]["showNextUI"]());
            _0x4193f4[_0x5c21("0xa7b", "NYmF")][_0x5c21("0xaa2", "9T1Q")] = !0, _0x4193f4[_0x5c21("0xaa3", "efPG")]["visible"] = !0, 
            _0x4193f4[_0x5c21("0xaa4", "*$CX")][_0x5c21("0xaa5", "9GG)")] = 0, _0x4193f4["clickCount"] = 0, 
            _0x4193f4[_0x5c21("0xaa6", "CvOU")] = !1, _0xcfe09e = _0x420221["getIns"]()[_0x5c21("0xaa7", "(b*P")][_0x5c21("0xaa8", "bBqT")] || 2e3, 
            _0x4e2584 = _0x420221[_0x5c21("0xaa9", "2^mQ")]()[_0x5c21("0x274", "ikmV")][_0x5c21("0xaaa", "UOab")] || 30, 
            _0x5cbf5e[_0x5c21("0xaab", "4E!&")](null, _0x202161) && _0x420221[_0x5c21("0x910", "(b*P")]()[_0x5c21("0xaac", "2(Lk")](), 
            _0x4193f4[_0x5c21("0xaad", "NTNj")]["height"] = Laya[_0x5c21("0xaae", "r#o%")][_0x5c21("0x931", "m*dV")], 
            _0x4193f4[_0x5c21("0x68f", "oZew")][_0x5c21("0xaaf", "NTNj")](_0x5c21("0xab0", "2(Lk"))[_0x5c21("0xab1", "bi^r")] = Laya[_0x5c21("0xab2", "t@qE")][_0x5c21("0xab3", "jQ6r")], 
            _0x4193f4[_0x5c21("0x66a", "m[2Q")][_0x5c21("0xa03", "*$CX")](_0x5cbf5e[_0x5c21("0xab4", "fIRP")])[_0x5c21("0x9dc", "(b*P")]("hitbox1bottom")["anchorY"] = 1, 
            _0x4193f4[_0x5c21("0xab5", "bi^r")][_0x5c21("0xa75", "NYmF")](_0x5cbf5e[_0x5c21("0xab6", "GLHs")])[_0x5c21("0xab7", "CvOU")](_0x5c21("0xab8", "(LPe"))["y"] = Laya["stage"][_0x5c21("0xab9", "oZew")];
        }
        [_0x5c21("0xaba", "jQ6r")]() {
            Laya[_0x5c21("0x51a", "[GWR")]["to"](this[_0x5c21("0xabb", "4yM]")], {
                value: this[_0x5c21("0xabc", "jQ6r")] / 200
            }, 10, null);
        }
        [_0x5c21("0xabd", "Uf[4")]() {
            this["m_Click"](), Laya[_0x5c21("0xabe", "([2%")]["to"](this[_0x5c21("0xabf", "AQRo")], {
                scaleX: .8,
                scaleY: .8
            }, 10, Laya[_0x5c21("0xac0", "AQRo")]["strongOut"], Laya["Handler"]["create"](this, function() {
                this[_0x5c21("0xac1", "m[2Q")][_0x5c21("0xac2", "Uv]h")] = 1, this[_0x5c21("0xac3", ")RsM")][_0x5c21("0xac4", "bi^r")] = 1;
            }));
        }
        [_0x5c21("0xac5", "UOab")]() {
            this[_0x5c21("0xac6", "fIRP")] += _0x420221["getIns"]()[_0x5c21("0xac7", "LDjf")][_0x5c21("0xac8", "(LPe")] || 20, 
            this[_0x5c21("0xac9", "%9(3")](), this["shakechest"](), _0x5cbf5e["MBGCA"](0, this[_0x5c21("0xaca", "AQRo")]) && this[_0x5c21("0xacb", "al%z")] >= _0x4e2584 && (this["isbannerShow"] = !0, 
            _0x5cbf5e[_0x5c21("0xacc", "al%z")](null, _0x202161) && _0x420221["getIns"]()["bannershow"](), 
            Laya["timer"][_0x5c21("0xacd", "ggF#")](_0xcfe09e, _0x4193f4, function() {
                _0x4193f4["owner"]["visible"] = !1, _0x420221[_0x5c21("0xace", "m[2Q")]()[_0x5c21("0xacf", "NTNj")](), 
                _0x4193f4["isSuc"] && (_0x4193f4[_0x5c21("0xad0", "gT6R")](), _0x4193f4[_0x5c21("0xad1", "r#o%")] = null), 
                _0x4193f4[_0x5c21("0xad2", "bi^r")] && _0x3c1d73["Inst"][_0x5c21("0x965", "MjE8")]();
            }));
        }
        ["shakechest"]() {
            Laya[_0x5c21("0x5fa", "Uv]h")]["to"](this["chest"], {
                rotation: 10
            }, 30, Laya["Ease"][_0x5c21("0xad3", "Yd[7")], Laya[_0x5c21("0x6ba", "NTNj")]["create"](this, function() {
                Laya[_0x5c21("0xad4", "dZ3i")]["to"](this[_0x5c21("0xad5", "omJG")], {
                    rotation: -10
                }, 50, Laya[_0x5c21("0x9c1", "efPG")][_0x5c21("0xad6", "gT6R")], Laya[_0x5c21("0x5a0", "4yM]")]["create"](this, function() {
                    Laya[_0x5c21("0xad7", "bi^r")]["to"](this["chest"], {
                        rotation: 0
                    }, 50, Laya["Ease"][_0x5c21("0xad8", "(b*P")], null, null, !1);
                }));
            }));
        }
    }
    var _0x47752c, _0x18b3a2, _0x4b6275, _0x9db51e = Laya["Browser"][_0x5c21("0xad9", ")RsM")]["wx"];
    class _0x43cfb5 extends Laya[_0x5c21("0xada", "fIRP")] {
        constructor() {
            super(), this["isNext"] = !1, this[_0x5c21("0xadb", "Yd[7")] = 0, _0x47752c = this;
        }
        [_0x5c21("0xadc", "ikmV")]() {
            _0x3c1d73[_0x5c21("0xa33", "jQ6r")]["RegUI"](_0x574ca6["UIType"][_0x5c21("0xadd", "9GG)")], this), 
            this[_0x5c21("0xade", "Yd[7")] = 0, this[_0x5c21("0xadf", "Uf[4")] = this[_0x5c21("0x9d2", "([2%")][_0x5c21("0xae0", "nnjN")](_0x5c21("0xae1", "CvOU")), 
            this[_0x5c21("0xae2", "NYmF")] = this["page1"][_0x5c21("0xa75", "NYmF")](_0x5cbf5e[_0x5c21("0xae3", "Uv]h")]), 
            this[_0x5c21("0xae4", "MjE8")]["y"] = _0x5cbf5e["lpfAU"](_0x5cbf5e[_0x5c21("0xae5", "rvGE")](700, 1624), Laya["stage"][_0x5c21("0xae6", "efPG")]), 
            this[_0x5c21("0xae7", "*$CX")] = this[_0x5c21("0x544", "r#o%")]["getChildByName"](_0x5cbf5e[_0x5c21("0xa6c", "NYmF")])["getChildByName"](_0x5cbf5e["TutDp"]), 
            this[_0x5c21("0xae8", "8&%b")]["y"] = _0x5cbf5e[_0x5c21("0xae9", "TOp9")](700 / 1624, Laya["stage"][_0x5c21("0x11e", "(LPe")]), 
            this[_0x5c21("0x66a", "m[2Q")][_0x5c21("0x9dc", "(b*P")](_0x5c21("0xae1", "CvOU"))[_0x5c21("0xa71", "hOwa")](_0x5cbf5e[_0x5c21("0xaea", "[GWR")])["y"] = _0x5cbf5e["pjFAl"](1050, 1624) * Laya[_0x5c21("0xaeb", "JzeF")][_0x5c21("0x123", "nnjN")], 
            this[_0x5c21("0xaec", "Yd[7")][_0x5c21("0xaed", "(LPe")](_0x5cbf5e[_0x5c21("0xaee", "nnjN")])[_0x5c21("0xa00", "GLHs")]("title")["y"] = 200 / 1624 * Laya["stage"][_0x5c21("0x91c", "hOwa")], 
            this[_0x5c21("0xaef", "Yd[7")] = this["owner"][_0x5c21("0xaf0", "al%z")](_0x5cbf5e["UmhpI"])["getChildByName"](_0x5cbf5e[_0x5c21("0xaf1", "efPG")]), 
            this["Pro_Value"]["y"] = 950 / 1624 * Laya["stage"]["height"], this["Btn_Click"] = this[_0x5c21("0xaf2", "CvOU")][_0x5c21("0xaf3", "oZew")](_0x5c21("0xaf4", "al%z"))[_0x5c21("0xaf5", "bBqT")](_0x5c21("0xaf6", "m[2Q"))[_0x5c21("0xaf7", "rvGE")](_0x5cbf5e["ToITf"]), 
            this["owner"][_0x5c21("0xa20", "4yM]")](_0x5c21("0xaf8", "r#o%"))[_0x5c21("0xa7f", "4E!&")](_0x5cbf5e[_0x5c21("0xaf9", "Uv]h")])["y"] = Laya[_0x5c21("0xafa", "bBqT")]["height"], 
            _0x14063c["onBtnFunction"](this[_0x5c21("0xafb", "iAvi")], Laya["Event"]["CLICK"], () => {
                this[_0x5c21("0xafc", "*$CX")]();
            }), Laya[_0x5c21("0xafd", "m*dV")][_0x5c21("0xafe", "t@qE")], this[_0x5c21("0xaff", "&D4Y")] = _0x420221["getIns"]()[_0x5c21("0x2f8", "oM#F")]["chest_click_sub_percent"] / 60 || 1;
        }
        ["onUpdate"]() {
            this[_0x5c21("0xb00", "&D4Y")] && (this[_0x5c21("0xb01", "omJG")][_0x5c21("0xb02", "2(Lk")] += 2), 
            _0x5cbf5e[_0x5c21("0xb03", "bi^r")](this[_0x5c21("0xb04", "m*dV")][_0x5c21("0xa97", "rvGE")], 0) && (this[_0x5c21("0xb05", "(LPe")] -= this["subNum"], 
            this["Pro_Value"][_0x5c21("0xb06", "(LPe")] -= this["subNum"] / 100);
        }
        [_0x5c21("0xb07", "AQRo")]() {}
        [_0x5c21("0xb08", "oZew")](_0x440426, _0x4a389e = !0) {
            if (_0x574ca6[_0x5c21("0xb09", "nnjN")] = _0x574ca6[_0x5c21("0xb0a", "4E!&")][_0x5c21("0xb0b", "(b*P")], 
            this[_0x5c21("0xb0c", "[GWR")]["skin"] = _0x5c21("0xb0d", "r#o%") + _0x5cbf5e[_0x5c21("0xb0e", "Uv]h")](Math["round"](_0x5cbf5e[_0x5c21("0xb0f", "Uv]h")](3, Math[_0x5c21("0xb10", "al%z")]())), 1) + ".png", 
            _0x47752c[_0x5c21("0xb11", "ggF#")] = _0x440426, _0x47752c["isNext"] = _0x4a389e, 
            _0x5cbf5e[_0x5c21("0xb12", "9GG)")](0, _0x420221[_0x5c21("0xaa9", "2^mQ")]()["config"][_0x5c21("0xb13", "gT6R")])) return _0x47752c[_0x5c21("0xad0", "gT6R")] && (_0x47752c["isSuc"](), 
            _0x47752c[_0x5c21("0xa9f", "4E!&")] = null), void (_0x47752c["isNext"] && _0x3c1d73[_0x5c21("0x85a", "omJG")][_0x5c21("0x8fa", "oM#F")]());
            _0x47752c[_0x5c21("0xb14", "LDjf")][_0x5c21("0xb15", "LDjf")] = !0, _0x47752c[_0x5c21("0xb16", "UOab")]["visible"] = !0, 
            _0x47752c["Pro_Value"]["value"] = 0, _0x47752c[_0x5c21("0xb17", "rvGE")] = 0, _0x47752c[_0x5c21("0xb18", "oM#F")] = !1, 
            _0x18b3a2 = _0x420221[_0x5c21("0x785", "oM#F")]()[_0x5c21("0x2fa", "Yd[7")][_0x5c21("0xb19", "hOwa")] || 2e3, 
            _0x4b6275 = _0x420221[_0x5c21("0x750", "2CMv")]()[_0x5c21("0xaa7", "(b*P")][_0x5c21("0xb1a", "jQ6r")] || 30, 
            null != _0x9db51e && _0x420221[_0x5c21("0x8df", "bi^r")]()[_0x5c21("0xb1b", "r#o%")](), 
            _0x47752c["owner"][_0x5c21("0x931", "m*dV")] = Laya[_0x5c21("0xb1c", "dZ3i")][_0x5c21("0xb1d", "GLHs")], 
            _0x47752c[_0x5c21("0xb1e", "2CMv")][_0x5c21("0xa20", "4yM]")](_0x5cbf5e[_0x5c21("0xa84", "([2%")])[_0x5c21("0xb1f", "fIRP")] = Laya[_0x5c21("0xb20", "TOp9")][_0x5c21("0xae6", "efPG")], 
            _0x47752c["owner"][_0x5c21("0x4e0", "oM#F")](_0x5cbf5e[_0x5c21("0xaee", "nnjN")])[_0x5c21("0x9a9", "2(Lk")](_0x5cbf5e[_0x5c21("0xb21", "TOp9")])[_0x5c21("0xb22", "8&%b")] = 1, 
            _0x47752c[_0x5c21("0x6a5", "[GWR")][_0x5c21("0xb23", "m*dV")](_0x5cbf5e[_0x5c21("0xb24", "iAvi")])[_0x5c21("0xb25", "([2%")](_0x5cbf5e["tWkcm"])["y"] = Laya["stage"]["height"];
        }
        [_0x5c21("0xb26", "(b*P")]() {
            Laya["Tween"]["to"](this["Pro_Value"], {
                value: this[_0x5c21("0xb27", "omJG")] / 100
            }, 10, null);
        }
        ["onClick_Click"]() {
            this[_0x5c21("0xb28", "dZ3i")](), Laya[_0x5c21("0xb29", "MjE8")]["to"](this[_0x5c21("0xb2a", "*$CX")], {
                scaleX: .8,
                scaleY: .8
            }, 100, Laya[_0x5c21("0xb2b", "8&%b")]["strongOut"], Laya[_0x5c21("0xb2c", "Uf[4")][_0x5c21("0x98a", "jQ6r")](this, function() {
                this[_0x5c21("0xafb", "iAvi")][_0x5c21("0xb2d", "9GG)")] = 1, this[_0x5c21("0xb2e", "([2%")][_0x5c21("0xb2f", "oZew")] = 1;
            }));
        }
        [_0x5c21("0xb30", "MjE8")]() {
            this["clickCount"] += _0x420221[_0x5c21("0x8ae", "%9(3")]()["config"][_0x5c21("0xb31", "t@qE")] || 20, 
            this[_0x5c21("0xb32", "nnjN")](), this[_0x5c21("0xb33", "Yd[7")](), 0 == this[_0x5c21("0xaa6", "CvOU")] && this["clickCount"] >= _0x4b6275 && (this[_0x5c21("0xb34", "MjE8")] = !0, 
            _0x420221["getIns"]()[_0x5c21("0xb35", "GLHs")](_0x5cbf5e["DihWl"]), _0x5cbf5e["EvCIv"](null, _0x9db51e) && _0x420221["getIns"]()[_0x5c21("0xb36", "Uf[4")](), 
            Laya[_0x5c21("0xd6", "*$CX")][_0x5c21("0xb37", "al%z")](_0x18b3a2, _0x47752c, function() {
                _0x47752c[_0x5c21("0x92b", "Uv]h")][_0x5c21("0xb38", "t@qE")] = !1, _0x420221[_0x5c21("0x8a5", "UOab")]()["hideBanner"](), 
                _0x47752c[_0x5c21("0xb39", "m[2Q")] && (_0x47752c[_0x5c21("0xb3a", "Uf[4")](), _0x47752c[_0x5c21("0xb3b", "fIRP")] = null), 
                _0x47752c["isNext"] && _0x3c1d73["Inst"][_0x5c21("0xb3c", "jQ6r")]();
            }));
        }
        [_0x5c21("0xb3d", "bi^r")]() {
            Laya[_0x5c21("0xb3e", "2(Lk")]["to"](this[_0x5c21("0xb3f", "%9(3")], {
                rotation: 10
            }, 30, Laya[_0x5c21("0xb40", "gT6R")][_0x5c21("0xb41", "omJG")], Laya["Handler"][_0x5c21("0x778", "ggF#")](this, function() {
                Laya[_0x5c21("0xb42", "2^mQ")]["to"](this[_0x5c21("0xb43", "fIRP")], {
                    rotation: -10
                }, 50, Laya[_0x5c21("0x69c", "2CMv")][_0x5c21("0x984", "GLHs")], Laya[_0x5c21("0x76b", "omJG")]["create"](this, function() {
                    Laya[_0x5c21("0xa5d", "oM#F")]["to"](this["chest"], {
                        rotation: 0
                    }, 50, Laya[_0x5c21("0xb44", "dZ3i")][_0x5c21("0xb45", "4E!&")], null, null, !1);
                }));
            }));
        }
    }
    var _0x1b15e5, _0x1815ac, _0x4805c9 = 0;
    class _0x1a6198 extends _0x16d180 {
        constructor() {
            super(), this[_0x5c21("0xb46", "2(Lk")] = [], this[_0x5c21("0xb47", "(LPe")] = !1, 
            this[_0x5c21("0xb48", "omJG")] = [], _0x1b15e5 = this;
        }
        [_0x5c21("0xb49", "2CMv")]() {
            for (var _0x3a74bb in _0x3c1d73[_0x5c21("0x6c5", "fIRP")]["RegUI"](_0x574ca6[_0x5c21("0xb4a", "[GWR")][_0x5c21("0xb4b", "AQRo")], this), 
            this[_0x5c21("0xb4c", "jQ6r")] = this[_0x5c21("0xb4d", "TOp9")][_0x5c21("0xb4e", "NTNj")](_0x420221[_0x5c21("0x6a3", "al%z")]()["config"][_0x5c21("0xb4f", "TOp9")]), 
            this["listGameExportData"]) this[_0x5c21("0xb50", "oM#F")][_0x3a74bb] = Number(_0x3a74bb);
            this[_0x5c21("0xb51", ")RsM")] = _0x420221["getIns"]()["getRandomArrayElements"](this["fingerAray"], 5), 
            this[_0x5c21("0xb52", "ggF#")] = this[_0x5c21("0x62d", "JzeF")][_0x5c21("0x92a", "9T1Q")](_0x5cbf5e["EVjAe"]), 
            this[_0x5c21("0xb53", "([2%")]["y"] = Laya["stage"]["height"] - 20, this[_0x5c21("0xb54", "NTNj")] = this[_0x5c21("0x9a8", "MjE8")]["getChildByName"](_0x5cbf5e[_0x5c21("0xb55", "NYmF")]), 
            this[_0x5c21("0xb56", "LDjf")][_0x5c21("0xb57", "Uf[4")] = _0x5cbf5e[_0x5c21("0xb58", "[GWR")](Laya[_0x5c21("0xa6f", "Yd[7")]["height"] - 150, _0x5cbf5e[_0x5c21("0xb59", "4yM]")](_0x420221[_0x5c21("0xb5a", "Uv]h")]()["bannerheight"], _0x420221[_0x5c21("0x954", "r#o%")]()[_0x5c21("0xb5b", "2(Lk")])), 
            this[_0x5c21("0xb5c", "UOab")][_0x5c21("0xb5d", "LDjf")][_0x5c21("0xb5e", "bBqT")] = !0, 
            this["list"]["repeatY"] = this[_0x5c21("0xb5f", "NYmF")][_0x5c21("0xb60", "LDjf")] / 2, 
            this["list"]["renderHandler"] = new (Laya[_0x5c21("0x985", "hOwa")])(this, this[_0x5c21("0xb61", "LDjf")]), 
            this[_0x5c21("0xa59", "AQRo")][_0x5c21("0xb62", "efPG")] = this[_0x5c21("0xb4c", "jQ6r")], 
            _0x14063c[_0x5c21("0xb63", "t@qE")](this["nextBtn"], Laya[_0x5c21("0xb64", "efPG")][_0x5c21("0xb65", "efPG")], () => {
                this[_0x5c21("0xb66", "jQ6r")](), this[_0x5c21("0xb67", "m[2Q")] && this[_0x5c21("0xb68", "Uf[4")](), 
                this[_0x5c21("0xb69", "efPG")] && _0x3c1d73["Inst"]["showNextUI"]();
            }), this[_0x5c21("0xb6a", "oM#F")] = null, this[_0x5c21("0xb6b", "gT6R")](), super["initUI"](), 
            this[_0x5c21("0xb6c", "(b*P")] = this["nextBtn"], this[_0x5c21("0xb6d", "rvGE")] = !1;
        }
        ["render"](_0xf04554, _0x2d883c) {
            _0xf04554["getChildByName"](_0x5cbf5e[_0x5c21("0xb6e", "r#o%")])[_0x5c21("0xb6f", "LDjf")] = this[_0x5c21("0xb70", "fIRP")][_0x2d883c][_0x5c21("0xb71", "9GG)")], 
            _0xf04554[_0x5c21("0xae0", "nnjN")](_0x5c21("0xb72", "NTNj"))[_0x5c21("0xb73", "gT6R")] = this[_0x5c21("0xb74", "m*dV")][_0x2d883c]["images"], 
            this[_0x5c21("0xb75", "8&%b")][_0x5c21("0xb76", "JzeF")](_0x2d883c, 0) > -1 && _0x5cbf5e["MBGCA"](1, _0x420221[_0x5c21("0x6df", "nnjN")]()[_0x5c21("0x1ef", "dZ3i")]["open_ad_finger"]) && (_0xf04554["getChildByName"](_0x5cbf5e[_0x5c21("0xb77", "rvGE")])["visible"] = !0), 
            _0x5cbf5e[_0x5c21("0xb78", "JzeF")](9, this[_0x5c21("0xb79", "9GG)")][_0x2d883c][_0x5c21("0xb7a", "(LPe")]) ? (_0xf04554[_0x5c21("0xaaf", "NTNj")](_0x5cbf5e[_0x5c21("0xb7b", "Yd[7")])[_0x5c21("0xb7c", "jQ6r")] = 3, 
            _0xf04554["getChildByName"](_0x5c21("0xb7d", "r#o%"))[_0x5c21("0xb7e", "4yM]")] = 3, 
            _0xf04554[_0x5c21("0xb7f", "[GWR")]("Pic")[_0x5c21("0xb80", "t@qE")] = !0, _0xf04554["getChildByName"](_0x5c21("0xb81", "t@qE"))["interval"] = 500) : (_0xf04554["getChildByName"](_0x5cbf5e["LflRg"])["clipX"] = 0, 
            _0xf04554[_0x5c21("0xb82", "2CMv")](_0x5c21("0xb83", "hOwa"))[_0x5c21("0xa1f", "8&%b")] = 0, 
            _0xf04554[_0x5c21("0x9a9", "2(Lk")](_0x5c21("0xb84", "&D4Y"))[_0x5c21("0xb85", "iAvi")] = !1), 
            _0xf04554[_0x5c21("0xb86", "ikmV")](Laya["Event"]["CLICK"]), _0xf04554["on"](Laya[_0x5c21("0xb87", ")RsM")]["CLICK"], this, function() {
                _0x420221[_0x5c21("0x8df", "bi^r")]()["AldingRecord"](_0x5c21("0xb88", "ikmV")), 
                _0x420221[_0x5c21("0x88b", "ikmV")]()["openMiniGame"](this[_0x5c21("0xa3a", "LDjf")][_0x2d883c], null, function() {
                    _0x420221["getIns"]()[_0x5c21("0xb89", "GLHs")](_0x1b15e5[_0x5c21("0xb5f", "NYmF")]), 
                    _0x1b15e5[_0x5c21("0xb8a", "4yM]")]["array"] = _0x1b15e5["listGameExportData"], 
                    _0x1b15e5["list"]["refresh"]();
                }, _0x5cbf5e["UMkwX"]);
            });
        }
        [_0x5c21("0x95f", "nnjN")](_0x259bae = !0, _0x304128) {
            _0x1b15e5[_0x5c21("0xb8b", "CvOU")] = _0x304128, this["isNext"] = _0x259bae, 1 == _0x420221[_0x5c21("0xb8c", "2(Lk")]()[_0x5c21("0x924", "8&%b")][_0x5c21("0xb8d", "hOwa")] ? (_0x574ca6[_0x5c21("0xb8e", "ikmV")] = _0x574ca6[_0x5c21("0x8db", "2^mQ")][_0x5c21("0xb8f", ")RsM")], 
            super[_0x5c21("0xb90", "&D4Y")](), _0x420221[_0x5c21("0x868", "omJG")]()["shuffleArray"](_0x1b15e5["listGameExportData"]), 
            _0x1b15e5[_0x5c21("0xb91", "nnjN")]["array"] = _0x1b15e5["listGameExportData"], 
            _0x1b15e5[_0x5c21("0xb92", "oM#F")][_0x5c21("0xb93", "m[2Q")](), Laya[_0x5c21("0x51f", "ggF#")][_0x5c21("0xb94", "hOwa")](_0x1b15e5[_0x5c21("0xa4b", "gT6R")]), 
            Laya[_0x5c21("0xb95", "AQRo")][_0x5c21("0x22c", "m[2Q")](_0x1b15e5), _0x1b15e5[_0x5c21("0xb96", "dZ3i")](_0x1b15e5["list"], !0, 1), 
            1 == _0x420221[_0x5c21("0x8df", "bi^r")]()[_0x5c21("0x239", "iAvi")]["hotad_auto_show"] && _0x420221["getIns"]()["openMiniGame"](_0x1b15e5[_0x5c21("0xb97", "r#o%")][Math["floor"](_0x5cbf5e["JgNlV"](Math["random"](), _0x1b15e5["listGameExportData"][_0x5c21("0xb98", "oM#F")]))])) : (_0x1b15e5[_0x5c21("0xb99", "iAvi")](), 
            this[_0x5c21("0xb9a", "ikmV")] && this["closeCallBack"](), _0x259bae && _0x3c1d73[_0x5c21("0xa0f", "GLHs")]["showNextUI"]());
        }
        [_0x5c21("0xb9b", "hOwa")]() {
            super["Hide"]();
        }
        [_0x5c21("0xb9c", "t@qE")](_0x51ed32, _0x2f4796, _0x49a544) {
            var _0x5f5d37 = {
                CTyEU: function _0x1fd1be(_0x1fafb5, _0x44099a) {
                    return _0x1fafb5 >= _0x44099a;
                }
            };
            _0x51ed32["array"] && (_0x5cbf5e[_0x5c21("0xb9d", "ggF#")](null, _0x2f4796) && (_0x2f4796 = !0), 
            _0x4805c9 = _0x51ed32[_0x5c21("0xb9e", "t@qE")] + _0x49a544, _0x51ed32[_0x5c21("0xb9f", "hOwa")](_0x4805c9, 500, new (Laya[_0x5c21("0xba0", "dZ3i")])(this, function() {
                Laya["timer"]["once"](1500, this, function() {
                    _0x2f4796 ? _0x5f5d37["CTyEU"](_0x51ed32[_0x5c21("0xba1", "2(Lk")][_0x5c21("0xa93", "GLHs")], _0x51ed32[_0x5c21("0xba2", "jQ6r")][_0x5c21("0xba3", "[GWR")]) ? this[_0x5c21("0xba4", "m*dV")](_0x51ed32, !1, -2) : this[_0x5c21("0xba5", "JzeF")](_0x51ed32, !0, 2) : _0x51ed32["scrollBar"]["value"] <= _0x51ed32[_0x5c21("0xba6", "TOp9")]["min"] ? this[_0x5c21("0xb9c", "t@qE")](_0x51ed32, !0, 2) : this[_0x5c21("0xba7", "omJG")](_0x51ed32, !1, -2);
                });
            })));
        }
    }
    class _0x420632 extends _0x16d180 {
        constructor() {
            super(), this["listGameExportData1"] = [], this["isNext"] = !1, this[_0x5c21("0xba8", "bi^r")] = [], 
            _0x1815ac = this;
        }
        [_0x5c21("0xba9", "4yM]")]() {
            _0x3c1d73[_0x5c21("0xbaa", "4E!&")][_0x5c21("0xbab", "Yd[7")](_0x574ca6[_0x5c21("0xbac", "al%z")]["gameExport3"], this);
            for (let _0x5dcbfa in _0x420221[_0x5c21("0x932", "TOp9")]()[_0x5c21("0x132", "9T1Q")][_0x5c21("0xbad", "bi^r")]) this[_0x5c21("0xbae", "bi^r")]["push"](_0x420221[_0x5c21("0x8c4", "NTNj")]()[_0x5c21("0x274", "ikmV")][_0x5c21("0xbaf", "*$CX")][_0x5dcbfa]);
            for (var _0x2d1ec9 in this["listGameExportData1"]) this[_0x5c21("0xbb0", "iAvi")][_0x2d1ec9] = _0x5cbf5e[_0x5c21("0xbb1", "%9(3")](Number, _0x2d1ec9);
            this[_0x5c21("0xbb2", ")RsM")] = _0x420221[_0x5c21("0x142", "rvGE")]()[_0x5c21("0xbb3", "NYmF")](this[_0x5c21("0xbb4", "([2%")], 5), 
            this[_0x5c21("0xbb5", "9GG)")] = this[_0x5c21("0x693", "(LPe")][_0x5c21("0xa75", "NYmF")](_0x5c21("0xbb6", "2^mQ")), 
            this["list"]["height"] = _0x5cbf5e[_0x5c21("0xbb7", "r#o%")](_0x5cbf5e[_0x5c21("0xbb8", "4yM]")](_0x5cbf5e["qdeOH"](Laya["stage"][_0x5c21("0xab9", "oZew")], 115), _0x420221[_0x5c21("0xb5a", "Uv]h")]()["bannerheight"] * _0x420221["getIns"]()[_0x5c21("0xbb9", "fIRP")]), 20), 
            this["backBtn"] = this["owner"]["getChildByName"]("Btn_back"), this[_0x5c21("0xbba", "gT6R")]["y"] = Laya[_0x5c21("0xbbb", "MjE8")]["height"] - 150, 
            _0x14063c[_0x5c21("0xbbc", "CvOU")](this["backBtn"], Laya[_0x5c21("0xbbd", "NYmF")][_0x5c21("0xbbe", "oZew")], () => {
                this[_0x5c21("0xbbf", "t@qE")]();
            }), this[_0x5c21("0x9e1", "%9(3")][_0x5c21("0xbc0", "bi^r")]["hide"] = !0, this["list"][_0x5c21("0xbc1", "rvGE")] = 3, 
            this["list"]["repeatY"] = this[_0x5c21("0xbc2", "Uf[4")][_0x5c21("0x44e", "UOab")] / 3, 
            this[_0x5c21("0xbc3", "Yd[7")][_0x5c21("0xbc4", "gT6R")] = new (Laya[_0x5c21("0x5a0", "4yM]")])(this, this[_0x5c21("0xbc5", "hOwa")]), 
            this[_0x5c21("0xbb5", "9GG)")][_0x5c21("0xbc6", "9GG)")] = this["listGameExportData1"], 
            this[_0x5c21("0xbb5", "9GG)")]["on"](Laya[_0x5c21("0xa2c", "t@qE")][_0x5c21("0xbc7", "Uf[4")], this, function() {
                Laya[_0x5c21("0xbc8", "al%z")][_0x5c21("0xbc9", "m*dV")](this[_0x5c21("0xbca", "oZew")]), 
                this[_0x5c21("0xbcb", "GLHs")](this[_0x5c21("0xa41", "m*dV")], void 0, !1);
            }), this["Hide"](), super[_0x5c21("0xbcc", "bi^r")](), this["moveBtn"] = this[_0x5c21("0xbcd", "dZ3i")], 
            this[_0x5c21("0xbce", "CvOU")] = !1;
        }
        [_0x5c21("0xbcf", "GLHs")](_0x9b0a71, _0x54fc79) {
            _0x9b0a71["getChildByName"](_0x5cbf5e[_0x5c21("0xbd0", "&D4Y")])[_0x5c21("0xbd1", "JzeF")] = this[_0x5c21("0xbd2", "ikmV")][_0x54fc79]["name"], 
            _0x9b0a71[_0x5c21("0xb23", "m*dV")](_0x5c21("0xbd3", "nnjN"))[_0x5c21("0xbd4", "m*dV")] = this[_0x5c21("0xbd5", "AQRo")][_0x54fc79][_0x5c21("0xbd6", "2(Lk")], 
            _0x9b0a71["getChildByName"](_0x5cbf5e[_0x5c21("0xbd7", "efPG")])["visible"] = this["listGameExportData1"][_0x54fc79][_0x5c21("0xbd8", "omJG")], 
            9 == this["listGameExportData1"][_0x54fc79][_0x5c21("0xbd9", "m*dV")] ? (_0x9b0a71[_0x5c21("0x9a0", "Uv]h")](_0x5cbf5e["LflRg"])[_0x5c21("0xbda", "2(Lk")] = 3, 
            _0x9b0a71[_0x5c21("0xbdb", "JzeF")](_0x5c21("0xbdc", "8&%b"))[_0x5c21("0xbdd", "ikmV")] = 3, 
            _0x9b0a71["getChildByName"](_0x5cbf5e["LflRg"])["autoPlay"] = !0, _0x9b0a71[_0x5c21("0x4ca", "%9(3")](_0x5cbf5e["LflRg"])[_0x5c21("0xbde", "oM#F")] = 500) : (_0x9b0a71[_0x5c21("0xbdf", "gT6R")](_0x5c21("0xbe0", "*$CX"))["clipX"] = 0, 
            _0x9b0a71["getChildByName"](_0x5c21("0xbe1", "rvGE"))[_0x5c21("0xbe2", "GLHs")] = 0, 
            _0x9b0a71["getChildByName"](_0x5c21("0xbe3", "GLHs"))[_0x5c21("0xbe4", "UOab")] = !1), 
            this[_0x5c21("0xbe5", "dZ3i")][_0x5c21("0xbe6", "fIRP")](_0x54fc79, 0) > -1 && _0x5cbf5e[_0x5c21("0xbe7", "2CMv")](1, _0x420221[_0x5c21("0x7f4", "LDjf")]()[_0x5c21("0xa48", "bBqT")][_0x5c21("0xbe8", "efPG")]) && (_0x9b0a71["getChildByName"](_0x5cbf5e["soyag"])[_0x5c21("0x9be", "AQRo")] = !0), 
            _0x9b0a71[_0x5c21("0xbe9", "JzeF")](Laya[_0x5c21("0xbea", "rvGE")]["CLICK"]), _0x9b0a71["on"](Laya[_0x5c21("0xbeb", "omJG")][_0x5c21("0xbec", "al%z")], this, function() {
                _0x420221[_0x5c21("0x750", "2CMv")]()[_0x5c21("0xbed", "gT6R")](_0x5c21("0xbee", "&D4Y")), 
                _0x420221["getIns"]()["openMiniGame"](this[_0x5c21("0xbef", "m*dV")][_0x54fc79], null, function() {
                    _0x420221["getIns"]()[_0x5c21("0xbf0", "UOab")](_0x1815ac[_0x5c21("0xbf1", "%9(3")]), 
                    _0x1815ac["list"][_0x5c21("0xbf2", "*$CX")] = _0x1815ac["listGameExportData1"], 
                    _0x1815ac[_0x5c21("0xa5e", "efPG")][_0x5c21("0xbf3", "nnjN")]();
                }, _0x5c21("0xbf4", "4yM]"));
            });
        }
        ["Show"](_0x5d73c2 = !0, _0x12bffd) {
            _0x1815ac[_0x5c21("0xbf5", "AQRo")] = _0x12bffd, this["isNext"] = _0x5d73c2, _0x5cbf5e[_0x5c21("0xbf6", "LDjf")](1, _0x420221[_0x5c21("0xbf7", "Yd[7")]()["config"][_0x5c21("0xbf8", "(b*P")]) ? (_0x574ca6[_0x5c21("0xbf9", "[GWR")] = _0x574ca6[_0x5c21("0xbfa", "oM#F")]["gameExport3"], 
            super[_0x5c21("0xbfb", "AQRo")](), _0x420221[_0x5c21("0x844", "9T1Q")]()[_0x5c21("0xbfc", "2(Lk")](_0x1815ac[_0x5c21("0xbfd", "(b*P")]), 
            _0x1815ac[_0x5c21("0xbfe", "r#o%")][_0x5c21("0xbff", "2(Lk")] = _0x1815ac["listGameExportData1"], 
            _0x1815ac[_0x5c21("0xc00", "m[2Q")]["refresh"](), Laya[_0x5c21("0xc01", "UOab")][_0x5c21("0xc02", "NYmF")](_0x1815ac["list"]), 
            Laya[_0x5c21("0xc03", "gT6R")][_0x5c21("0xc04", "*$CX")](_0x1815ac), _0x1815ac[_0x5c21("0xc05", "al%z")](_0x1815ac[_0x5c21("0xc06", "CvOU")], !0, !1), 
            1 == _0x420221[_0x5c21("0x9d0", "&D4Y")]()["config"][_0x5c21("0xc07", "JzeF")] && _0x420221["getIns"]()[_0x5c21("0x943", ")RsM")](_0x1815ac[_0x5c21("0xc08", "Yd[7")][Math["floor"](_0x5cbf5e["OAYMm"](Math[_0x5c21("0xc09", "hOwa")](), _0x1815ac[_0x5c21("0xbd5", "AQRo")][_0x5c21("0x29d", "JzeF")]))])) : _0x1815ac[_0x5c21("0x95d", "bi^r")]();
        }
        ["Hide"]() {
            console["log"](_0x5cbf5e[_0x5c21("0xc0a", "dZ3i")]), super[_0x5c21("0x90d", "Uf[4")](), 
            this["closeCallBack"] && this[_0x5c21("0xc0b", "Uv]h")](), this["isNext"] && _0x3c1d73[_0x5c21("0xc0c", "NYmF")]["showNextUI"]();
        }
        [_0x5c21("0xc0d", "JzeF")](_0x328d4a, _0x327502, _0x22c6f9) {
            _0x328d4a[_0x5c21("0xc0e", "m[2Q")] && (_0x5cbf5e[_0x5c21("0xc0f", "NYmF")](null, _0x327502) && (_0x327502 = !0), 
            Laya["Tween"]["to"](_0x328d4a[_0x5c21("0xc10", "oM#F")], {
                value: _0x327502 ? _0x328d4a[_0x5c21("0xc11", "ggF#")]["max"] : _0x328d4a["scrollBar"][_0x5c21("0xc12", "jQ6r")]
            }, 700 * (_0x22c6f9 ? _0x328d4a["repeatX"] : _0x328d4a["repeatY"]), Laya[_0x5c21("0xc13", "NTNj")]["linearNone"], Laya[_0x5c21("0xc14", "2^mQ")][_0x5c21("0xc15", "2^mQ")](this, this[_0x5c21("0xc16", "omJG")], [ _0x328d4a, !_0x327502, _0x22c6f9 ]), 700, !0));
        }
    }
    var _0x362424 = 0;
    class _0x5a479e extends _0x16d180 {
        constructor() {
            super();
        }
        [_0x5c21("0xc17", "2^mQ")]() {
            _0x3c1d73[_0x5c21("0x91f", "ggF#")][_0x5c21("0xc18", "hOwa")](_0x574ca6[_0x5c21("0xc19", "ggF#")][_0x5c21("0xc1a", "Uv]h")], this), 
            this[_0x5c21("0xa3d", "oM#F")] = _0x420221[_0x5c21("0xc1b", "*$CX")]()["config"]["box_info"], 
            this["owner"][_0x5c21("0x4d1", "2^mQ")]("bg")["y"] = Laya[_0x5c21("0xa6f", "Yd[7")][_0x5c21("0xc1c", "gT6R")] / 2 - 100, 
            this[_0x5c21("0xc1d", "[GWR")] = this[_0x5c21("0x67a", "(b*P")][_0x5c21("0xa09", "r#o%")]("bg")[_0x5c21("0x92a", "9T1Q")]("gameExport2List"), 
            this["backBtn"] = this["owner"][_0x5c21("0xbdf", "gT6R")]("back"), _0x14063c[_0x5c21("0xc1e", "TOp9")](this[_0x5c21("0xc1f", "al%z")], Laya["Event"]["CLICK"], () => {
                this["Hide"]();
            }), this["backBtn"]["y"] = _0x5cbf5e[_0x5c21("0xc20", "hOwa")](1055 / 1334, Laya[_0x5c21("0xc21", "Uv]h")][_0x5c21("0xc22", "2^mQ")]), 
            this[_0x5c21("0xa61", "4E!&")][_0x5c21("0xc23", "dZ3i")][_0x5c21("0xc24", "UOab")] = !0, 
            this[_0x5c21("0xc25", "&D4Y")][_0x5c21("0xc26", "MjE8")] = 3, this["list"][_0x5c21("0xc27", "fIRP")] = _0x5cbf5e[_0x5c21("0xc28", "dZ3i")](this[_0x5c21("0xb97", "r#o%")]["length"], 3), 
            this[_0x5c21("0xc29", "bBqT")][_0x5c21("0xc2a", "&D4Y")] = new (Laya[_0x5c21("0xc2b", "9GG)")])(this, this[_0x5c21("0xc2c", "JzeF")]), 
            this[_0x5c21("0x9e4", "(LPe")]["array"] = this[_0x5c21("0xc2d", "(b*P")], this[_0x5c21("0xc2e", "NYmF")]["on"](Laya["Event"][_0x5c21("0xc2f", "nnjN")], this, function() {
                Laya[_0x5c21("0x9bf", "LDjf")][_0x5c21("0xc30", "rvGE")](this[_0x5c21("0xc31", "ikmV")]), 
                this[_0x5c21("0xc32", "4yM]")](this[_0x5c21("0xc33", "([2%")], void 0, !1);
            }), this["Hide"](), super["initUI"](), this["moveBtn"] = this[_0x5c21("0xc34", "r#o%")], 
            this[_0x5c21("0xc35", "LDjf")] = !1;
        }
        [_0x5c21("0xc36", "(b*P")](_0x2a74c0, _0x11b545) {
            _0x2a74c0[_0x5c21("0xa71", "hOwa")](_0x5cbf5e[_0x5c21("0xc37", "(LPe")])[_0x5c21("0xc38", "efPG")] = this["listGameExportData"][_0x11b545][_0x5c21("0xc39", "ggF#")], 
            _0x2a74c0[_0x5c21("0xa00", "GLHs")](_0x5c21("0xc3a", "NYmF"))[_0x5c21("0x9f3", "MjE8")] = this["listGameExportData"][_0x11b545][_0x5c21("0xc3b", "4E!&")], 
            9 == this[_0x5c21("0xc3c", "GLHs")][_0x11b545]["frame"] ? (_0x2a74c0[_0x5c21("0xbdf", "gT6R")](_0x5cbf5e[_0x5c21("0xc3d", "([2%")])[_0x5c21("0xc3e", "bi^r")] = 3, 
            _0x2a74c0[_0x5c21("0x9a0", "Uv]h")](_0x5c21("0xc3f", "Uf[4"))[_0x5c21("0xc40", "CvOU")] = 3, 
            _0x2a74c0[_0x5c21("0x92a", "9T1Q")]("Pic")[_0x5c21("0xc41", "hOwa")] = !0, _0x2a74c0["getChildByName"](_0x5cbf5e[_0x5c21("0xc42", "bi^r")])[_0x5c21("0xc43", "JzeF")] = 500) : (_0x2a74c0["getChildByName"]("Pic")[_0x5c21("0xc44", "MjE8")] = 0, 
            _0x2a74c0["getChildByName"](_0x5cbf5e["LflRg"])[_0x5c21("0xc45", "LDjf")] = 0, _0x2a74c0["getChildByName"]("Pic")[_0x5c21("0xc46", "Uf[4")] = !1), 
            _0x2a74c0[_0x5c21("0xc47", "GLHs")](Laya["Event"][_0x5c21("0xbbe", "oZew")]), _0x2a74c0["on"](Laya["Event"]["CLICK"], this, function() {
                _0x420221[_0x5c21("0x88b", "ikmV")]()[_0x5c21("0xc48", "NYmF")](_0x5c21("0xc49", "(b*P")), 
                _0x420221[_0x5c21("0x750", "2CMv")]()[_0x5c21("0xa0d", "nnjN")](this[_0x5c21("0xc4a", "hOwa")][_0x11b545], null, function() {}, _0x5cbf5e[_0x5c21("0xc4b", "NYmF")]);
            });
        }
        [_0x5c21("0xc4c", "2^mQ")](_0x4de2d0) {
            this["closeCallBack"] = _0x4de2d0, _0x5cbf5e[_0x5c21("0xc4d", "2^mQ")](1, _0x420221[_0x5c21("0xa47", "[GWR")]()[_0x5c21("0xc4e", "9GG)")]["open_export"]) ? (_0x574ca6[_0x5c21("0xc4f", "oZew")] = _0x574ca6["UIType"]["gameExport2"], 
            this["list"]["startIndex"] = 0, super[_0x5c21("0xc50", "[GWR")](), _0x420221["getIns"]()[_0x5c21("0xc51", "AQRo")](this[_0x5c21("0xc52", "Uv]h")]), 
            this[_0x5c21("0xc53", "TOp9")][_0x5c21("0xbf2", "*$CX")] = this[_0x5c21("0xc54", "2CMv")], 
            this[_0x5c21("0xc55", "2CMv")][_0x5c21("0xc56", "ikmV")](), this[_0x5c21("0xc57", "UOab")](this["list"], !0, !1)) : this[_0x5c21("0xc58", "&D4Y")]();
        }
        ["Hide"]() {
            super[_0x5c21("0xc59", "CvOU")](), this[_0x5c21("0xc5a", "2CMv")] && this["closeCallBack"]();
        }
        ["tweenList2"](_0x31b0b4, _0x5a64e0, _0x3e5935) {
            _0x31b0b4[_0x5c21("0xc5b", "gT6R")] && (_0x5cbf5e["ISUir"](null, _0x5a64e0) && (_0x5a64e0 = !0), 
            _0x362424 = _0x31b0b4[_0x5c21("0xc5c", "*$CX")] + _0x3e5935, _0x31b0b4["tweenTo"](_0x362424, 500, new (Laya[_0x5c21("0xba0", "dZ3i")])(this, function() {
                Laya["timer"][_0x5c21("0x258", "NTNj")](1500, this, function() {
                    _0x5a64e0 ? _0x31b0b4["scrollBar"]["value"] >= _0x31b0b4[_0x5c21("0xc5d", ")RsM")][_0x5c21("0xc5e", "jQ6r")] ? this[_0x5c21("0xc5f", "iAvi")](_0x31b0b4, !1, -2) : this["tweenList2"](_0x31b0b4, !0, 2) : _0x31b0b4[_0x5c21("0xc60", "(LPe")]["value"] <= _0x31b0b4[_0x5c21("0xc61", "[GWR")]["min"] ? this["tweenList2"](_0x31b0b4, !0, 2) : this[_0x5c21("0xb96", "dZ3i")](_0x31b0b4, !1, -2);
                });
            })));
        }
        [_0x5c21("0xc62", "jQ6r")](_0xc2a32f, _0x17f29f, _0x5c1628) {
            _0xc2a32f[_0x5c21("0xc63", "nnjN")] && (_0x5cbf5e["PKqfn"](null, _0x17f29f) && (_0x17f29f = !0), 
            Laya[_0x5c21("0xc64", "9GG)")]["to"](_0xc2a32f[_0x5c21("0xc65", "4E!&")], {
                value: _0x17f29f ? _0xc2a32f["scrollBar"]["max"] : _0xc2a32f[_0x5c21("0xc5d", ")RsM")]["min"]
            }, 1e3 * (_0x5c1628 ? _0xc2a32f[_0x5c21("0xc66", "(LPe")] : _0xc2a32f[_0x5c21("0xc67", "bBqT")]), Laya[_0x5c21("0xc68", "2(Lk")][_0x5c21("0x984", "GLHs")], Laya[_0x5c21("0xc69", "ggF#")][_0x5c21("0x44b", "m*dV")](this, this["ListRun"], [ _0xc2a32f, !_0x17f29f, _0x5c1628 ]), 1e3, !0));
        }
    }
    var _0x198f9d, _0x340ccb = 0;
    class _0x258717 extends _0x16d180 {
        constructor() {
            super();
        }
        [_0x5c21("0xc6a", "jQ6r")]() {
            _0x3c1d73[_0x5c21("0xa33", "jQ6r")][_0x5c21("0xc6b", "2^mQ")](_0x574ca6[_0x5c21("0xc6c", "gT6R")][_0x5c21("0xc6d", "jQ6r")], this), 
            super[_0x5c21("0xc6e", "ggF#")](), this["listGameExportData"] = _0x420221[_0x5c21("0x868", "omJG")]()["config"]["box_info"], 
            this[_0x5c21("0xc6f", "NTNj")] = this[_0x5c21("0x9d2", "([2%")][_0x5c21("0xa81", "ggF#")](_0x5c21("0xc70", "t@qE")), 
            this[_0x5c21("0xc71", "dZ3i")]["scrollBar"][_0x5c21("0xc72", "GLHs")] = !0, this[_0x5c21("0xc73", "t@qE")][_0x5c21("0xc74", "JzeF")] = this[_0x5c21("0xc75", "dZ3i")][_0x5c21("0xc76", "al%z")], 
            this[_0x5c21("0xc77", "oM#F")][_0x5c21("0xc78", "bi^r")] = new (Laya[_0x5c21("0xc79", "JzeF")])(this, this["render"]), 
            this[_0x5c21("0xc7a", "&D4Y")]["y"] = Laya[_0x5c21("0xc7b", "Uf[4")][_0x5c21("0x123", "nnjN")], 
            this["likeList"]["array"] = this[_0x5c21("0xc7c", "MjE8")], this[_0x5c21("0xc7d", "omJG")]["on"](Laya["Event"][_0x5c21("0xc7e", "&D4Y")], this, function() {
                this["tweenList"](this[_0x5c21("0xc7f", "Uf[4")], void 0, 1);
            }), this[_0x5c21("0xc80", "9T1Q")]["on"](Laya["Event"][_0x5c21("0xc81", "UOab")], this, function() {
                this[_0x5c21("0xc82", "4yM]")](this["likeList"], void 0, 1);
            }), this[_0x5c21("0xc83", "dZ3i")](this[_0x5c21("0xc84", "al%z")], !0);
        }
        [_0x5c21("0xc85", ")RsM")](_0x25881c, _0x251610) {
            var _0x4a1969 = {
                RSYKf: _0x5cbf5e[_0x5c21("0xc86", ")RsM")],
                SjWWb: _0x5c21("0xc87", "oZew")
            };
            _0x25881c["getChildByName"](_0x5cbf5e[_0x5c21("0xc88", "4E!&")])[_0x5c21("0xc89", "bi^r")] = this["listGameExportData"][_0x251610][_0x5c21("0xc8a", "8&%b")], 
            _0x5cbf5e["NZyBW"](9, this[_0x5c21("0xc8b", "9T1Q")][_0x251610]["frame"]) ? (_0x25881c[_0x5c21("0xbdf", "gT6R")](_0x5c21("0xc8c", "fIRP"))[_0x5c21("0xc8d", "NYmF")] = 3, 
            _0x25881c[_0x5c21("0xa03", "*$CX")](_0x5cbf5e[_0x5c21("0xc8e", "*$CX")])[_0x5c21("0xc8f", "bBqT")] = 3, 
            _0x25881c[_0x5c21("0xb23", "m*dV")](_0x5cbf5e[_0x5c21("0xc42", "bi^r")])["autoPlay"] = !0, 
            _0x25881c[_0x5c21("0xa81", "ggF#")](_0x5cbf5e[_0x5c21("0xc90", "m*dV")])[_0x5c21("0xc91", "Uf[4")] = 500) : _0x25881c[_0x5c21("0x4e0", "oM#F")](_0x5c21("0xc92", "ggF#"))[_0x5c21("0xc93", "JzeF")] = !1;
            var _0x3d5fbf = _0x25881c[_0x5c21("0x4ca", "%9(3")](_0x5c21("0xc94", "nnjN"));
            _0x3d5fbf && (_0x3d5fbf[_0x5c21("0xc95", "Uf[4")] = this[_0x5c21("0xc96", "4yM]")][_0x251610][_0x5c21("0xc97", "oM#F")]), 
            _0x25881c[_0x5c21("0xc98", "gT6R")](Laya["Event"]["CLICK"]), _0x25881c["on"](Laya["Event"][_0x5c21("0xc99", "r#o%")], this, function() {
                console[_0x5c21("0xc9a", "*$CX")](_0x5c21("0xc9b", "8&%b"), _0x251610), _0x420221[_0x5c21("0xc9c", "8&%b")]()[_0x5c21("0xc9d", "jQ6r")](_0x4a1969[_0x5c21("0xc9e", "UOab")]), 
                _0x420221[_0x5c21("0x88f", "9GG)")]()["openMiniGame"](this[_0x5c21("0xc9f", "efPG")][_0x251610], null, function() {}[_0x5c21("0xca0", "2CMv")](this), _0x4a1969[_0x5c21("0xca1", "(LPe")]);
            });
        }
        [_0x5c21("0xca2", "*$CX")]() {
            this["owner"]["y"] = Laya[_0x5c21("0x811", "2(Lk")][_0x5c21("0x7d5", "TOp9")], _0x5cbf5e[_0x5c21("0xca3", "*$CX")](1, _0x420221["getIns"]()[_0x5c21("0xca4", "efPG")]["open_export"]) && _0x420221[_0x5c21("0x88f", "9GG)")]()[_0x5c21("0xaa7", "(b*P")][_0x5c21("0xca5", "hOwa")] > -1 ? this[_0x5c21("0x54e", "Uf[4")][_0x5c21("0x923", "UOab")] = !0 : this[_0x5c21("0xa4d", "nnjN")]();
        }
        [_0x5c21("0xca6", "2CMv")]() {
            Laya[_0x5c21("0xca7", "fIRP")][_0x5c21("0xca8", "oZew")](this["likeList"]), Laya[_0x5c21("0xca9", "9T1Q")]["clearAll"](this[_0x5c21("0xcaa", "[GWR")]), 
            this[_0x5c21("0xcab", "2(Lk")]["visible"] = !1;
        }
        [_0x5c21("0xcac", "(LPe")](_0x7eb429, _0x41722e, _0x31f9dd) {
            _0x7eb429[_0x5c21("0xcad", "4E!&")] && (_0x5cbf5e[_0x5c21("0xcae", "bBqT")](null, _0x41722e) && (_0x41722e = !0), 
            _0x340ccb = _0x5cbf5e["kZWNX"](_0x7eb429["startIndex"], _0x31f9dd), _0x7eb429["tweenTo"](_0x340ccb, 500, new (Laya[_0x5c21("0x46a", "oZew")])(this, function() {
                var _0x12c760 = {
                    vihgQ: function _0x53f387(_0x33789e, _0x326fb5) {
                        return _0x33789e >= _0x326fb5;
                    }
                };
                Laya["timer"][_0x5c21("0xcaf", "8&%b")](1500, this, function() {
                    _0x41722e ? _0x12c760[_0x5c21("0xcb0", "gT6R")](_0x7eb429["scrollBar"][_0x5c21("0xcb1", "NYmF")], _0x7eb429["scrollBar"]["max"]) ? this["tweenList"](_0x7eb429, !1, -1) : this[_0x5c21("0xcb2", "ggF#")](_0x7eb429, !0, 1) : _0x7eb429["scrollBar"][_0x5c21("0xcb3", "Yd[7")] <= _0x7eb429[_0x5c21("0xc11", "ggF#")][_0x5c21("0xcb4", "Uf[4")] ? this[_0x5c21("0xcb5", "2CMv")](_0x7eb429, !0, 1) : this["tweenList"](_0x7eb429, !1, -1);
                });
            })));
        }
        [_0x5c21("0xcb6", "gT6R")](_0x9b198, _0x396c18) {
            _0x9b198[_0x5c21("0xbf2", "*$CX")] && (_0x5cbf5e["JapBH"](null, _0x396c18) && (_0x396c18 = _0x9b198[_0x5c21("0xcb7", "9GG)")]), 
            _0x396c18 ? (_0x9b198["isRightMove"] = _0x396c18, _0x9b198[_0x5c21("0xcb8", "4E!&")](_0x5cbf5e[_0x5c21("0xcb9", "LDjf")](_0x9b198["repeatX"] + 1 - Math[_0x5c21("0xcba", "(b*P")](_0x9b198[_0x5c21("0x20f", "9T1Q")] / _0x9b198["cells"][0]["width"]), _0x9b198["repeatY"]), _0x5cbf5e[_0x5c21("0xcbb", "m*dV")](1e3, _0x9b198["repeatX"] + 1), Laya["Handler"]["create"](this, this["ListRun"], [ _0x9b198, !1 ]))) : (_0x9b198["isRightMove"] = _0x396c18, 
            _0x9b198[_0x5c21("0xcbc", "(LPe")](0, 1e3 * (_0x9b198["repeatX"] + 1), Laya["Handler"][_0x5c21("0xcbd", "NYmF")](this, this[_0x5c21("0xcbe", "4E!&")], [ _0x9b198, !0 ]))));
        }
    }
    var _0x1df69a = Laya[_0x5c21("0xcbf", "omJG")][_0x5c21("0xcc0", "([2%")]["wx"];
    class _0x124675 extends _0x27b03e[_0x5c21("0xcc1", "efPG")][_0x5c21("0xcc2", "nnjN")] {
        constructor() {
            super(), _0x198f9d = this, Laya["MouseManager"][_0x5c21("0xcc3", "(b*P")] = !1;
        }
        [_0x5c21("0xcc4", "JzeF")]() {
            this[_0x5c21("0xcc5", "ggF#")] = 0;
            Laya[_0x5c21("0xcc6", "*$CX")]["create"]([ _0x5cbf5e[_0x5c21("0xcc7", "r#o%")], _0x5c21("0xcc8", "TOp9") ], null), 
            _0x5cbf5e[_0x5c21("0xcc9", "iAvi")](null, _0x1df69a) ? this[_0x5c21("0xcca", "4yM]")]() : (_0x420221[_0x5c21("0x906", "ggF#")]()[_0x5c21("0xccb", "4E!&")](), 
            _0x3f5234[_0x5c21("0x8a0", ")RsM")]()["loadModels"](() => {
                Laya["Scene"][_0x5c21("0xccc", "m*dV")](_0x5c21("0xccd", "AQRo"), !0, null, null, Laya["Handler"][_0x5c21("0xcce", "rvGE")](this, null, null, !1));
            })), _0x36ffa1[_0x5c21("0xccf", "al%z")](), this["startGame"](), this[_0x5c21("0xcd0", "Uv]h")]["y"] = Laya[_0x5c21("0x251", "al%z")]["height"] / 2;
        }
        ["loadWxSub"]() {
            var _0x4a250f = {
                zRaoF: _0x5cbf5e[_0x5c21("0xcd1", "CvOU")]
            };
            _0x1df69a[_0x5c21("0xcd2", "9T1Q")]({
                name: _0x5cbf5e[_0x5c21("0xcd3", "GLHs")],
                success: function(_0xffd6dd) {
                    console["log"]("loadWxSub success"), _0x3f5234[_0x5c21("0x897", "GLHs")]()[_0x5c21("0xcd4", "al%z")](() => {
                        Laya[_0x5c21("0xcd5", "(b*P")][_0x5c21("0xcd6", "nnjN")](_0x5c21("0xcd7", "hOwa"), !0, null, null, Laya["Handler"][_0x5c21("0xcd8", "fIRP")](this, null, null, !1));
                    });
                },
                fail: function(_0x418554) {
                    console[_0x5c21("0xae", "JzeF")](_0x4a250f[_0x5c21("0xcd9", "MjE8")]);
                }
            });
        }
        [_0x5c21("0xcda", "GLHs")]() {
            _0x198f9d[_0x5c21("0xcdb", "NYmF")](), _0x420221[_0x5c21("0xcdc", "hOwa")]()[_0x5c21("0xcdd", "gT6R")](), 
            _0x420221["getIns"]()[_0x5c21("0xcde", "oZew")](_0x1800d3 => {
                console[_0x5c21("0x5b1", "(LPe")](_0x5cbf5e[_0x5c21("0xcdf", "([2%")], _0x1800d3), 
                _0x420221[_0x5c21("0xc9c", "8&%b")]()[_0x5c21("0xce0", "rvGE")]();
            }, () => {
                console[_0x5c21("0x5b1", "(LPe")](_0x5cbf5e[_0x5c21("0xce1", "dZ3i")]);
            }), _0x420221["getIns"]()[_0x5c21("0xce2", "ggF#")](), _0x420221["getIns"]()[_0x5c21("0xce3", "(LPe")](), 
            _0x420221[_0x5c21("0xa47", "[GWR")]()[_0x5c21("0xce4", "GLHs")]();
        }
        [_0x5c21("0xce5", "oM#F")]() {
            Laya[_0x5c21("0xce6", "efPG")]["loop"](50, this, this["loadProgress2"]);
        }
        [_0x5c21("0xce7", "ggF#")]() {
            this[_0x5c21("0xce8", "CvOU")] += 10, _0x5cbf5e[_0x5c21("0xce9", "4yM]")](this[_0x5c21("0xcea", "4yM]")], 500) ? (this[_0x5c21("0xceb", "(LPe")] = 500, 
            Laya[_0x5c21("0xcec", "[GWR")][_0x5c21("0xa4e", "al%z")](this)) : this["loginprogress"][_0x5c21("0xced", "gT6R")] = this[_0x5c21("0xcee", "m[2Q")];
        }
        [_0x5c21("0xcef", "TOp9")]() {
            Laya["timer"]["clearAll"](this);
        }
    }
    class _0x86b036 {
        constructor() {}
        static [_0x5c21("0xcf0", "Yd[7")]() {
            var _0x14a9e8 = Laya[_0x5c21("0xcf1", "4yM]")][_0x5c21("0xcf2", "([2%")];
            _0x5cbf5e[_0x5c21("0xcf3", "fIRP")](_0x14a9e8, _0x5cbf5e[_0x5c21("0xcf4", "Uf[4")], _0x3c1d73), 
            _0x14a9e8(_0x5cbf5e[_0x5c21("0xcf5", "JzeF")], _0x5aac59), _0x5cbf5e[_0x5c21("0xcf6", "oZew")](_0x14a9e8, _0x5cbf5e[_0x5c21("0xcf7", "*$CX")], _0x5ba43a), 
            _0x14a9e8(_0x5c21("0xcf8", "(LPe"), _0x2e5964), _0x14a9e8("view/ResultUI.ts", _0x5d3213), 
            _0x5cbf5e["qLtlk"](_0x14a9e8, _0x5c21("0xcf9", "&D4Y"), _0x526149), _0x5cbf5e["qLtlk"](_0x14a9e8, _0x5c21("0xcfa", "TOp9"), _0x43cfb5), 
            _0x5cbf5e[_0x5c21("0xcfb", "9GG)")](_0x14a9e8, "view/gameExport1.ts", _0x1a6198), 
            _0x5cbf5e["FCdkB"](_0x14a9e8, _0x5c21("0xcfc", "9GG)"), _0x420632), _0x5cbf5e["pBshJ"](_0x14a9e8, _0x5cbf5e[_0x5c21("0xcfd", "al%z")], _0x5a479e), 
            _0x5cbf5e[_0x5c21("0xcfe", "*$CX")](_0x14a9e8, _0x5cbf5e[_0x5c21("0xcff", "*$CX")], _0x258717), 
            _0x5cbf5e[_0x5c21("0xd00", "LDjf")](_0x14a9e8, _0x5cbf5e[_0x5c21("0xd01", ")RsM")], _0x124675), 
            _0x14a9e8(_0x5c21("0xd02", "8&%b"), _0x3678cc);
        }
    }
    _0x86b036[_0x5c21("0xd03", "al%z")] = 750, _0x86b036[_0x5c21("0xc22", "2^mQ")] = 1624, 
    _0x86b036["scaleMode"] = _0x5c21("0xd04", "gT6R"), _0x86b036["screenMode"] = _0x5c21("0xd05", "AQRo"), 
    _0x86b036["alignV"] = _0x5c21("0xd06", "dZ3i"), _0x86b036["alignH"] = _0x5cbf5e[_0x5c21("0xd07", "oM#F")], 
    _0x86b036[_0x5c21("0xd08", "2^mQ")] = _0x5c21("0xd09", "NTNj"), _0x86b036[_0x5c21("0xd0a", "GLHs")] = "", 
    _0x86b036[_0x5c21("0xd0b", "2(Lk")] = !1, _0x86b036[_0x5c21("0xd0c", "2(Lk")] = !1, 
    _0x86b036[_0x5c21("0xd0d", "Uf[4")] = !1, _0x86b036[_0x5c21("0xd0e", "r#o%")] = !0, 
    _0x86b036["init"]();
    new class {
        constructor() {
            window[_0x5c21("0xd0f", "al%z")] ? Laya3D[_0x5c21("0x870", "MjE8")](_0x86b036["width"], _0x86b036[_0x5c21("0xed", "r#o%")]) : Laya["init"](_0x86b036[_0x5c21("0xd10", "[GWR")], _0x86b036[_0x5c21("0xab1", "bi^r")], Laya[_0x5c21("0xd11", "m*dV")]), 
            Laya[_0x5c21("0xd12", "fIRP")] && Laya[_0x5c21("0xd13", "2(Lk")][_0x5c21("0xd14", "TOp9")](), 
            Laya[_0x5c21("0xd15", "TOp9")] && Laya["DebugPanel"][_0x5c21("0xd16", "r#o%")](), 
            Laya["stage"][_0x5c21("0xd17", "fIRP")] = _0x86b036["scaleMode"], Laya[_0x5c21("0xd18", "*$CX")][_0x5c21("0xd19", "bi^r")] = _0x86b036[_0x5c21("0xd1a", "MjE8")], 
            Laya[_0x5c21("0xd1b", "iAvi")][_0x5c21("0xd1c", "efPG")] = _0x86b036[_0x5c21("0xd1d", "oZew")], 
            Laya["stage"][_0x5c21("0xd1e", "NYmF")] = _0x86b036[_0x5c21("0xd1f", "ikmV")], Laya[_0x5c21("0xd20", "(b*P")][_0x5c21("0xd21", "2(Lk")] = _0x86b036[_0x5c21("0xd22", "AQRo")], 
            (_0x86b036["debug"] || _0x5cbf5e[_0x5c21("0xd23", "omJG")]("true", Laya[_0x5c21("0xd24", "(LPe")]["getQueryString"](_0x5cbf5e[_0x5c21("0xd25", "al%z")]))) && Laya[_0x5c21("0xd26", "9GG)")](), 
            _0x86b036[_0x5c21("0xd27", "4E!&")] && Laya[_0x5c21("0xd28", "nnjN")] && Laya[_0x5c21("0xd29", "Uf[4")][_0x5c21("0xd2a", "omJG")](), 
            Laya[_0x5c21("0xd2b", "JzeF")](!0), Laya[_0x5c21("0xd2c", "([2%")][_0x5c21("0xd2d", "Yd[7")](_0x5c21("0xd2e", "JzeF"), Laya[_0x5c21("0x5fb", "CvOU")]["create"](this, this[_0x5c21("0xd2f", "LDjf")]), Laya[_0x5c21("0xd30", "8&%b")]["FILENAME_VERSION"]);
        }
        [_0x5c21("0xd31", "ggF#")]() {
            Laya[_0x5c21("0xd32", "NTNj")][_0x5c21("0xd33", "t@qE")](_0x5c21("0xd34", "NYmF"), Laya[_0x5c21("0xc14", "2^mQ")][_0x5c21("0xcd8", "fIRP")](this, this[_0x5c21("0xd35", "2^mQ")]));
        }
        [_0x5c21("0xd36", "bi^r")]() {
            _0x86b036["startScene"] && Laya[_0x5c21("0xd37", "2CMv")][_0x5c21("0xcd6", "nnjN")](_0x86b036[_0x5c21("0xd38", "dZ3i")]);
        }
    }();
}();

(function(_0x3ce9d7, _0x3705f4, _0x3a14a2) {
    var _0x236546 = {
        ZYsMB: function _0x3eaa94(_0x24dccf, _0x4d2093) {
            return _0x24dccf !== _0x4d2093;
        },
        oIhWJ: _0x5c21("0xd39", "oM#F"),
        iIPbI: "jsjiami.com.v5",
        EPKOZ: function _0x21d26b(_0xd5e66d, _0x505e9a) {
            return _0xd5e66d + _0x505e9a;
        }
    };
    _0x3a14a2 = "al";
    try {
        _0x3a14a2 += _0x5c21("0xd3a", "m[2Q");
        _0x3705f4 = encode_version;
        if (!(_0x236546[_0x5c21("0xd3b", "omJG")](typeof _0x3705f4, _0x236546[_0x5c21("0xd3c", "GLHs")]) && _0x3705f4 === _0x236546[_0x5c21("0xd3d", "GLHs")])) {
            _0x3ce9d7[_0x3a14a2](_0x236546[_0x5c21("0xd3e", "LDjf")]("删除", _0x5c21("0xd3f", "2(Lk")));
        }
    } catch (_0x153d5a) {
        _0x3ce9d7[_0x3a14a2]("删除版本号，js会定期弹窗");
    }
})(window);

encode_version = "jsjiami.com.v5";