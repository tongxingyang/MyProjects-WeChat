"undefined" != typeof swan && "undefined" != typeof swanGlobal ? (require("swan-game-adapter.js"), 
require("libs/laya.bdmini.js")) : "undefined" != typeof wx && (require("weapp-adapter.js"), 
require("libs/min/laya.wxmini.min.js")), window.loadLib = require, require("index.js"), 
require("utils/ald-game.js");